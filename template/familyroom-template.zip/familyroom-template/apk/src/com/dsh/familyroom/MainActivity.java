package com.dsh.familyroom;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * 家庭小屋客户�?��v1.2�? * 加�?��?�路：启动时并发探测�?有可用入口，挑最�?��那个加载
 *   1) http://127.0.0.1:8660/            �?��（手机自己跑�?服务时最�?��
 *   2) http://127.0.0.1:8660/       家里网（同一 Wi-Fi，约 30ms�? *   3) https://frp.example.com:65274/  樱花直连（约 400~600ms�? *   4) https://family.example.com/   Cloudflare 兜底�?.6~4s�? * 探测结果缓存�?SharedPreferences，下次启动先用上次最�?��，再后台复测�? */
public class MainActivity extends Activity {
  private static final String TAG = "RoomApp";
  private static final int REQ_FILE = 1001;
  private static final int REQ_PHOTO = 1002;
  private Uri photoUri = null;
  private static final String PREF = "roomapp";
  private static final String K_BEST = "best_base";
  private static final String K_LAT = "best_lat";
  private static final int PROBE_FAST_MS = 1200;   // �?��/�?域网
  private static final int PROBE_SLOW_MS = 9000;   // �?��

    // restored comment
private static final String[][] CANDS = new String[][]{
      {"http://127.0.0.1:8660/", "local"},
      {"http://127.0.0.1:8660/", "hotspot"},
      {"https://frp.example.com:65274/", "frp"},
      {"https://203.0.113.10/", "cloud"},
      {"https://203.0.113.10:16001/", "cloud2"},
      {"https://family.example.com/", "cf"}
  };

  private WebView web;
  private ValueCallback<Uri[]> fileCb;
  private SharedPreferences sp;
  private final Handler ui = new Handler(Looper.getMainLooper());
  private final Recorder rec = new Recorder();

  private String base = "";
  private int latency = -1;
  private List<String[]> ordered = new ArrayList<>();
  private int failCount = 0;
  private boolean probing = false;
  private String tokenFor = "";
  private String pendingChan = "";

  @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
  @Override
  protected void onCreate(Bundle b) {
    super.onCreate(b);
    if (Build.VERSION.SDK_INT >= 19) { WebView.setWebContentsDebuggingEnabled(true); }
    sp = getSharedPreferences(PREF, MODE_PRIVATE);

    getWindow().setStatusBarColor(Color.parseColor("#0b1116"));
    getWindow().setNavigationBarColor(Color.parseColor("#0b1116"));
    web = new WebView(this);
    web.setBackgroundColor(Color.parseColor("#0b1116"));
    setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setUseWideViewPort(true);
    s.setLoadWithOverviewMode(true);
    s.setAllowFileAccess(true);
    // v41: 页面从 assets 以 file:// 打开，需要放开跨域
    s.setAllowFileAccessFromFileURLs(true);
    s.setAllowUniversalAccessFromFileURLs(true);
    s.setCacheMode(WebSettings.LOAD_DEFAULT);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
    // static resources: cache first, API/SSE still go to network
    s.setUserAgentString(s.getUserAgentString() + " DSHFamilyRoom/1.14");

    CookieManager cm = CookieManager.getInstance();
    cm.setAcceptCookie(true);
    cm.setAcceptThirdPartyCookies(web, true);

    web.addJavascriptInterface(new Bridge(), "DSHApp");

    web.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
        Uri u = req.getUrl();
        String h = u.getHost() == null ? "" : u.getHost();
        if (isOurHost(h)) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
        return true;
      }

      @Override
      public void onPageFinished(WebView v, String url) {
        migrateToken(url);
        openPendingChannel();
        if (!autoChecked) {
          autoChecked = true;
          new Handler(Looper.getMainLooper()).postDelayed(() -> checkUpdate(true), 1800);
        }
      }

      @Override
      public void onReceivedSslError(WebView v, android.webkit.SslErrorHandler handler, android.net.http.SslError err) {
        String host = "";
        try { host = err.getUrl() == null ? "" : Uri.parse(err.getUrl()).getHost(); } catch (Throwable ignored) {}
        if (isOurHost(host)) {
          Log.w(TAG, "ssl error accepted for " + host);
          handler.proceed();
        } else {
          handler.cancel();
        }
      }

      @Override
      public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
        if (!req.isForMainFrame()) return;
        failCount++;
        Log.w(TAG, "load error on " + base + " -> fail#" + failCount);
        nextBase();
      }
    });

    web.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
        if (fileCb != null) { fileCb.onReceiveValue(null); fileCb = null; }
        fileCb = cb;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
          startActivityForResult(Intent.createChooser(i, "\u9009\u62e9\u56fe\u7247"), REQ_FILE);
          return true;
        } catch (Exception e) {
          fileCb = null;
          return false;
        }
      }

      @Override
      public void onPermissionRequest(final android.webkit.PermissionRequest request) {
        runOnUiThread(new Runnable() {
          public void run() {
            try {
              request.grant(request.getResources());
            } catch (Throwable t) {
              try { request.deny(); } catch (Throwable t2) {}
            }
          }
        });
      }
    });

    web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
      // v1.15.1: 页面里点下载一律交给系统自带浏览器
      try {
        if (url == null) return;
        if (url.startsWith("blob:") || url.startsWith("data:")) {
          toast("\u8fd9\u4e2a\u6587\u4ef6\u8bf7\u7528\u9875\u9762\u91cc\u7684\u6309\u94ae\u4fdd\u5b58");
          return;
        }
        openInBrowser(url);
      } catch (Exception e) {
        toast("\u6253\u5f00\u6d4f\u89c8\u5668\u5931\u8d25\uff1a" + e.getMessage());
      }
    });

    askNotifyPermission();
    if (b != null && web.restoreState(b) != null) { autoStartNotify(); return; }
    autoStartNotify();

    // restored comment
String last = sp.getString(K_BEST, "");
    int lastLat = sp.getInt(K_LAT, -1);
    if (last != null && last.length() > 0) {
      base = last;
      latency = lastLat;
      loadBase(base);
    }
    repick();
  }

  // ---------- 系统通知（v34） ----------
  private void askNotifyPermission() {
    try {
      if (Build.VERSION.SDK_INT >= 33) {
        if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
          requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }
      }
    } catch (Exception e) { Log.w(TAG, "perm " + e); }
  }

  private void autoStartNotify() {
    try {
      boolean on = sp.getBoolean("nb_on", false);
      String t = sp.getString("nb_token", "");
      String nb = sp.getString("nb_base", "");
      String nme = sp.getString("nb_me", "");
      if (on && t.length() > 0) NotifyService.start(this, nb, t, nme);
    } catch (Exception e) { Log.w(TAG, "autoNotify " + e); }
  }

  // ---------- 入口探测 ----------

  /** 后台并发探测�?有�?��?�，选出�?�?��用入�?*/
  private void repick() {
    if (probing) return;
    probing = true;
    new Thread(() -> {
      final List<String[]> ok = Collections.synchronizedList(new ArrayList<>());
      final CountDownLatch latch = new CountDownLatch(CANDS.length);
      for (final String[] c : CANDS) {
        new Thread(() -> {
          try {
            long t = probe(c[0]);
            if (t >= 0) ok.add(new String[]{c[0], c[1], String.valueOf(t)});
          } catch (Throwable ignored) {
          } finally {
            latch.countDown();
          }
        }).start();
      }
      try { latch.await(12, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
      probing = false;

      List<String[]> list = new ArrayList<>(ok);
    // restored comment
Collections.sort(list, new Comparator<String[]>() {
        @Override public int compare(String[] a, String[] b) {
          int ra = rank(a[0], Integer.parseInt(a[2])), rb = rank(b[0], Integer.parseInt(b[2]));
          if (ra != rb) return ra - rb;
          return Integer.parseInt(a[2]) - Integer.parseInt(b[2]);
        }
      });
      ordered = list;
      if (list.isEmpty()) {
        Log.w(TAG, "no endpoint reachable, fallback to cloud");
        if (base == null || base.isEmpty()) { base = CANDS[CANDS.length - 1][0]; loadBase(base); }
        return;
      }
      String[] best = list.get(0);
      final int bestLat = Integer.parseInt(best[2]);
      Log.i(TAG, "probe best=" + best[0] + " " + bestLat + "ms (ok=" + list.size() + ")");
      sp.edit().putString(K_BEST, best[0]).putInt(K_LAT, bestLat).apply();

      final String bestBase = best[0];
      ui.post(() -> {
        if (base == null || base.isEmpty()) {
          base = bestBase; latency = bestLat; loadBase(base);
        } else if (!bestBase.equals(base) && bestLat + 250 < latency) {
    // restored comment
toast("\u5df2\u5207\u5230\u66f4\u5feb\u5165\u53e3\uff1a" + bestLat + "ms");
          base = bestBase; latency = bestLat; loadBase(base);
        } else {
          latency = bestLat;
        }
      });
    }).start();
  }

  /** 入口优先级：0=回环（origin 稳定，登录�?�不�?�� 1=�?域网 2=�?�� */
  private static int rank(String b, int lat) {
    if (b.contains("127.0.0.1") || b.contains("localhost")) return 0;
    if (b.startsWith("http://")) return 1;
    // v-p0：https 按实测延迟分层，快的（<800ms）与局域网同级，慢的（Cloudflare）排最后
    return lat < 800 ? 1 : 2;
  }
  /** 返回 /api/who 的�?�时 ms�?1 表示不可�?*/
  private long probe(String b) {
    HttpURLConnection c = null;
    try {
      URL u = new URL(b + "api/who");
      c = (HttpURLConnection) u.openConnection();
      if (c instanceof javax.net.ssl.HttpsURLConnection) {
        javax.net.ssl.HttpsURLConnection h = (javax.net.ssl.HttpsURLConnection) c;
        try { h.setSSLSocketFactory(trustAllFactory()); } catch (Throwable ignored) {}
        h.setHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
          @Override public boolean verify(String host, javax.net.ssl.SSLSession ses) { return true; }
        });
      }
      int to = b.startsWith("http://") ? PROBE_FAST_MS : PROBE_SLOW_MS;
      c.setConnectTimeout(to);
      c.setReadTimeout(to);
      c.setInstanceFollowRedirects(true);
      c.setRequestProperty("Connection", "close");
      long t0 = SystemClock.elapsedRealtime();
      int code = c.getResponseCode();
      long dt = SystemClock.elapsedRealtime() - t0;
      if (code < 200 || code >= 500) return -1;
      InputStream in = c.getInputStream();
      byte[] buf = new byte[512];
      int n = in.read(buf);
      in.close();
      if (n <= 0) return -1;
      String body = new String(buf, 0, n, "UTF-8");
      boolean looksLikeRoom = body.indexOf("laoda") >= 0 || body.indexOf("\"name\"") >= 0
          || body.indexOf("shiqi") >= 0 || body.indexOf("ok") >= 0;
      return looksLikeRoom ? dt : -1;
    } catch (Throwable e) {
      return -1;
    } finally {
      if (c != null) try { c.disconnect(); } catch (Throwable ignored) {}
    }
  }

  /** v-p0：自签证书场景下信任所有证书（仅用于自家入口探测） */
  private static javax.net.ssl.SSLSocketFactory trustAllFactory() {
    try {
      javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
      sc.init(null, new javax.net.ssl.TrustManager[]{
          new javax.net.ssl.X509TrustManager() {
            @Override public void checkClientTrusted(java.security.cert.X509Certificate[] c, String a) {}
            @Override public void checkServerTrusted(java.security.cert.X509Certificate[] c, String a) {}
            @Override public java.security.cert.X509Certificate[] getAcceptedIssuers() {
              return new java.security.cert.X509Certificate[0];
            }
          }
      }, new java.security.SecureRandom());
      return sc.getSocketFactory();
    } catch (Throwable t) {
      return null;
    }
  }

  /** v-p0：自家入口（免证书告警/内部跳转）判断 */
  private static boolean isOurHost(String h) {
    if (h == null) return false;
    h = h.toLowerCase();
    return h.equals("127.0.0.1") || h.equals("localhost") || h.equals("203.0.113.10")
        || h.endsWith("example.com") || h.endsWith("frp-rib.com");
  }

  // v37：点通知直达对应频道（私聊/家庭）
  private void openPendingChannel() {
    try {
      Intent it = getIntent();
      String ch = (it == null) ? null : it.getStringExtra("channel");
      if (ch == null || ch.length() == 0) ch = pendingChan;
      if (ch == null || ch.length() == 0) return;
      pendingChan = "";
      if (it != null) { it.removeExtra("channel"); setIntent(it); }
      final String safe = ch.replace("'", "").replace("\"", "");
      ui.postDelayed(() -> {
        try {
          web.evaluateJavascript("try{ if(typeof openChannel==='function') openChannel('" + safe + "'); }catch(e){}", null);
        } catch (Exception ignored) { }
      }, 1200);
    } catch (Exception ignored) { }
  }

  @Override
  protected void onNewIntent(Intent it) {
    super.onNewIntent(it);
    setIntent(it);
    String ch = (it == null) ? null : it.getStringExtra("channel");
    if (ch != null && ch.length() > 0) { pendingChan = ch; openPendingChannel(); }
  }

  private static final String ASSET_PAGE = "file:///android_asset/www/index.html";

  /** v41: 页面是否已打包进 assets/www */
  private boolean hasAssetPage() {
    try { getAssets().open("www/index.html").close(); return true; } catch (Exception e) { return false; }
  }

  // v1.12.0: 拍照（页面 toolbar 的「拍照」按钮）
  private void takePhoto() {
    try {
      ContentValues cv = new ContentValues();
      cv.put(MediaStore.Images.Media.DISPLAY_NAME, "room_" + System.currentTimeMillis() + ".jpg");
      cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
      photoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
      if (photoUri == null) { toast("相册不可用"); return; }
      Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      i.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
      i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
      startActivityForResult(i, REQ_PHOTO);
    } catch (Exception e) {
      toast("打不开相机：" + e);
    }
  }

  private void onPhotoResult(int res) {
    if (res != RESULT_OK || photoUri == null) { toast("取消了"); return; }
    try {
      InputStream in = getContentResolver().openInputStream(photoUri);
      BitmapFactory.Options o = new BitmapFactory.Options();
      o.inJustDecodeBounds = true;
      BitmapFactory.decodeStream(in, null, o);
      if (in != null) in.close();
      int maxSide = Math.max(o.outWidth, o.outHeight);
      int sample = 1;
      while (maxSide / sample > 1600) sample *= 2;
      BitmapFactory.Options o2 = new BitmapFactory.Options();
      o2.inSampleSize = sample;
      InputStream in2 = getContentResolver().openInputStream(photoUri);
      Bitmap bm = BitmapFactory.decodeStream(in2, null, o2);
      if (in2 != null) in2.close();
      if (bm == null) { toast("这张照片读不出来"); return; }
      int w = bm.getWidth(), h = bm.getHeight();
      float sc = Math.min(1f, 1280f / Math.max(w, h));
      if (sc < 1f) bm = Bitmap.createScaledBitmap(bm, Math.round(w * sc), Math.round(h * sc), true);
      ByteArrayOutputStream bo = new ByteArrayOutputStream();
      bm.compress(Bitmap.CompressFormat.JPEG, 85, bo);
      String b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
      final String url = "data:image/jpeg;base64," + b64;
      runOnUiThread(() -> {
        if (web != null) web.evaluateJavascript("try{window.__photoReady&&window.__photoReady('" + url + "')}catch(e){}", null);
      });
    } catch (Exception e) {
      toast("处理照片失败：" + e);
    }
  }

  private void loadBase(String b) {
    CookieManager.getInstance().setCookie(b, "dsh_app=1; path=/");
    Log.i(TAG, "load " + b + (hasAssetPage() ? " (asset)" : ""));
    // v41: 页面内置在 APK 里，用 file:///android_asset 打开；服务器地址经 Bridge.apiBase() 注入
    if (hasAssetPage()) web.loadUrl(ASSET_PAGE);
    else web.loadUrl(b);
    requestAudioPermission();
  }

  /** v1.22: 语音输入需要麦克风运行时权限 */
  private void requestAudioPermission() {
    try {
      if (android.os.Build.VERSION.SDK_INT >= 23) {
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
          requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 1009);
        }
      }
    } catch (Throwable t) {}
  }

  /** 当前入口挂了，换下一�?*/
  private void nextBase() {
    String nxt = null;
    if (ordered != null) {
      for (String[] c : ordered) {
        if (base == null || !c[0].equals(base)) { nxt = c[0]; break; }
      }
    }
    if (nxt == null) {
      for (String[] c : CANDS) {
        if (base == null || !c[0].equals(base)) { nxt = c[0]; break; }
      }
    }
    if (nxt == null) return;
    base = nxt;
    toast("\u5207\u6362\u5165\u53e3\u2026");
    loadBase(base);
  }

  /** �?��入口（origin）之后把登录 token 迁过去，避免跳到登录�?*/
  private void migrateToken(String url) {
    if (url == null || url.equals(tokenFor)) return;
    final String nurl = url;
    final String saved = sp.getString("room_token", "");
    web.evaluateJavascript(
      "(function(){try{return localStorage.getItem('room_token')||''}catch(e){return ''}})()",
      val -> {
        String cur = unq(val);
        if (cur.length() > 0) {
          sp.edit().putString("room_token", cur).apply();
          return;
        }
        if (saved.length() == 0) return;
        String esc = saved.replace("\\", "\\\\").replace("'", "\\'");
        web.evaluateJavascript("try{localStorage.setItem('room_token','" + esc + "')}catch(e){}", null);
    // restored comment
web.reload();
      });
  }

  private static String unq(String s) {
    if (s == null) return "";
    s = s.trim();
    if (s.startsWith("\"") && s.endsWith("\"") && s.length() >= 2) s = s.substring(1, s.length() - 1);
    if (s.equals("null")) return "";
    return s;
  }
  private void toast(String m) {
    runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show());
  }

  // ---------- v33：�?查更�?----------
  private boolean autoChecked = false;

  private int myVersionCode() {
    try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; } catch (Exception e) { return 0; }
  }

  private String myVersionName() {
    try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
  }

  private static int jInt(String j, String key, int def) {
    try {
      int i = j.indexOf("\"" + key + "\"");
      if (i < 0) return def;
      int c = j.indexOf(':', i);
      int e = c + 1;
      while (e < j.length() && " \t\r\n".indexOf(j.charAt(e)) >= 0) e++;
      int s = e;
      while (e < j.length() && (Character.isDigit(j.charAt(e)) || j.charAt(e) == '-')) e++;
      if (s == e) return def;
      return Integer.parseInt(j.substring(s, e));
    } catch (Exception ex) { return def; }
  }

  private static String jStr(String j, String key, String def) {
    try {
      int i = j.indexOf("\"" + key + "\"");
      if (i < 0) return def;
      int q = j.indexOf('"', j.indexOf(':', i));
      if (q < 0) return def;
      StringBuilder sb = new StringBuilder();
      for (int k = q + 1; k < j.length(); k++) {
        char ch = j.charAt(k);
        if (ch == '\\') { k++; if (k < j.length()) sb.append(j.charAt(k)); continue; }
        if (ch == '"') break;
        sb.append(ch);
      }
      return sb.toString();
    } catch (Exception ex) { return def; }
  }

  private static String jNotes(String j) {
    List<String> out = new ArrayList<>();
    try {
      int a = j.indexOf("\"notes\"");
      if (a < 0) return "";
      int s = j.indexOf('[', a);
      int e = j.indexOf(']', s);
      if (s < 0 || e < 0) return "";
      String arr = j.substring(s + 1, e);
      int p = 0;
      while (true) {
        int q1 = arr.indexOf('"', p);
        if (q1 < 0) break;
        StringBuilder sb = new StringBuilder();
        int k = q1 + 1;
        for (; k < arr.length(); k++) {
          char ch = arr.charAt(k);
          if (ch == '\\') { k++; if (k < arr.length()) sb.append(arr.charAt(k)); continue; }
          if (ch == '"') break;
          sb.append(ch);
        }
        out.add(sb.toString());
        p = k + 1;
      }
    } catch (Exception ignored) {}
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < out.size(); i++) {
      if (i > 0) sb.append('\n');
      sb.append("· ").append(out.get(i));
    }
    return sb.toString();
  }

  private void openExternal(String u) {
    try {
      Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      startActivity(i);
    } catch (Exception e) {
      toast("\u6ca1\u6709\u6d4f\u89c8\u5668\u80fd\u6253\u5f00");
    }
  }

  private void checkUpdate(final boolean silent) {
    final String b = base;
    if (b == null || b.isEmpty()) return;
    new Thread(() -> {
      try {
        URL u = new URL(b + "/api/version?t=" + System.currentTimeMillis());
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "application/json");
        StringBuilder sb = new StringBuilder();
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
          String line;
          while ((line = r.readLine()) != null) sb.append(line);
        }
        c.disconnect();
        final String j = sb.toString();
        final int newest = jInt(j, "apkVersionCode", 0);
        final String ver = jStr(j, "apkVersion", "");
        final String rel = jStr(j, "apkUrl", "");
        final String notes = jNotes(j);
        final int mine = myVersionCode();
        if (newest > mine && !rel.isEmpty()) {
          final String full = rel.startsWith("http") ? rel : (b + rel);
          runOnUiThread(() -> new android.app.AlertDialog.Builder(MainActivity.this)
            .setTitle("\u5c0f\u5c4b\u6709\u65b0\u7248\u672c " + ver)
            .setMessage((notes.isEmpty() ? "" : (notes + "\n\n")) + "\u73b0\u5728\u88c5\u7684\u662f v" + myVersionName() + "\u3002\u65b0\u7248\u81ea\u52a8\u9009\u66f4\u5feb\u5165\u53e3\u3002\u8981\u4e0b\u8f7d\u5417\uff1f")
            .setPositiveButton("\u4e0b\u8f7d", (d, w) -> startDownload(full, ver))
            .setNeutralButton("\u7528\u6d4f\u89c8\u5668", (d, w) -> openExternal(full))
            .setNegativeButton("\u7a0d\u540e", null)
            .show());
        } else if (!silent) {
          final String m = "\u5df2\u662f\u6700\u65b0\u7248 v" + myVersionName();
          runOnUiThread(() -> toast(m));
        }
      } catch (Exception e) {
        if (!silent) {
          final String m = "\u68c0\u67e5\u66f4\u65b0\u5931\u8d25\uff1a" + e.getMessage();
          runOnUiThread(() -> toast(m));
        }
      }
    }).start();
  }

  // v35: built-in downloader (DownloadManager) -> auto install prompt
  private long dlId = -1;
  private android.content.BroadcastReceiver dlRecv;

  private void registerDlReceiver() {
    try {
      if (dlRecv != null) return;
      dlRecv = new android.content.BroadcastReceiver() {
        @Override public void onReceive(android.content.Context c, Intent it) {
          try {
            if (it == null || !DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(it.getAction())) return;
            long id = it.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (dlId <= 0 || id != dlId) return;
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Uri u = dm == null ? null : dm.getUriForDownloadedFile(id);
            if (u == null) { toast("\u4e0b\u8f7d\u5931\u8d25\uff0c\u8bd5\u8bd5\u7528\u6d4f\u89c8\u5668"); return; }
            installApk(u);
          } catch (Exception e) { toast("\u4e0b\u8f7d\u5b8c\u6210\u4f46\u6253\u4e0d\u5f00\u5b89\u88c5\u5668"); }
        }
      };
      android.content.IntentFilter f = new android.content.IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
      if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlRecv, f, android.content.Context.RECEIVER_EXPORTED);
      else registerReceiver(dlRecv, f);
    } catch (Exception e) { Log.w("RoomDl", "register failed " + e); }
  }

  private void startDownload(String url, String ver) {
    try {
      registerDlReceiver();
      DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
      String v = (ver == null || ver.isEmpty()) ? "new" : ver.replaceAll("[^0-9A-Za-z._-]", "");
      String name = "familyroom-" + v + ".apk";
      DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
      rq.setTitle("\u5c0f\u5c4b " + ver);
      rq.setDescription("\u4e0b\u8f7d\u4e2d\uff0c\u5b8c\u4e86\u4f1a\u5f39\u5b89\u88c5");
      rq.setMimeType("application/vnd.android.package-archive");
      rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
      rq.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name);
      rq.setAllowedOverMetered(true);
      rq.setAllowedOverRoaming(true);
      dlId = dm.enqueue(rq);
      toast("\u5f00\u59cb\u4e0b\u8f7d v" + ver + "\uff08\u901a\u77e5\u680f\u770b\u8fdb\u5ea6\uff09");
    } catch (Exception e) {
      toast("\u5185\u7f6e\u4e0b\u8f7d\u4e0d\u884c\uff1a" + e.getMessage() + "\uff0c\u8f6c\u6d4f\u89c8\u5668");
      openExternal(url);
    }
  }

  private void installApk(Uri u) {
    try {
      Intent i = new Intent(Intent.ACTION_VIEW);
      i.setDataAndType(u, "application/vnd.android.package-archive");
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
      startActivity(i);
    } catch (Exception e) {
      toast("\u8bf7\u5728\u4e0b\u8f7d\u91cc\u624b\u52a8\u5b89\u88c5");
    }
  }

  @Override
  protected void onActivityResult(int req, int res, Intent data) {
    if (req == REQ_PHOTO) { onPhotoResult(res); return; }
    if (req == REQ_FILE) {
      Uri[] out = null;
      if (res == RESULT_OK && data != null) {
        if (data.getData() != null) out = new Uri[]{data.getData()};
        else if (data.getClipData() != null) {
          int n = data.getClipData().getItemCount();
          out = new Uri[n];
          for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
        }
      }
      if (fileCb != null) { fileCb.onReceiveValue(out); fileCb = null; }
      return;
    }
    super.onActivityResult(req, res, data);
  }

  @Override
  public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else moveTaskToBack(true);
  }

  @Override
  protected void onSaveInstanceState(Bundle out) {
    super.onSaveInstanceState(out);
    if (web != null) web.saveState(out);
  }

  @Override
  protected void onResume() {
    super.onResume();
    // restored comment
if (failCount > 0) { failCount = 0; repick(); }
  }

  @Override
  protected void onDestroy() {
    if (web != null) { web.destroy(); web = null; }
    super.onDestroy();
  }

  // v1.15.1: 交给系统自带浏览器打开链接/下载
  private void openInBrowser(String url) {
    try {
      Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
      it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      startActivity(it);
    } catch (Exception e) {
      toast("\u6253\u5f00\u6d4f\u89c8\u5668\u5931\u8d25\uff1a" + e.getMessage());
    }
  }

  public class Bridge {
    @JavascriptInterface
    public void toast(String m) { MainActivity.this.toast(m); }

    // v1.19：进入频道时清掉该通知频道的聚合
    @JavascriptInterface
    public void clearNotify(String ch) {
      try { NotifyService.clearCh(MainActivity.this, ch); } catch (Exception e) { }
    }

    // v33: check-update bridge
@JavascriptInterface
    public int versionCode() {
      try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; } catch (Exception e) { return 0; }
    }

    @JavascriptInterface
    public String versionName() {
      try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
    }

    @JavascriptInterface
    public void openUrl(String u) {
      try {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
      } catch (Exception e) { toast("\u65e0\u6cd5\u6253\u5f00\u94fe\u63a5"); }
    }

    @JavascriptInterface
    public void checkUpdate() { MainActivity.this.checkUpdate(false); }

    @JavascriptInterface
    public void takePhoto() { runOnUiThread(() -> MainActivity.this.takePhoto()); }

    // v35: download bridges
    @JavascriptInterface
    public void downloadApk(String url, String ver) {
      if (url == null || url.isEmpty()) { toast("\u6ca1\u6709\u4e0b\u8f7d\u5730\u5740"); return; }
      MainActivity.this.startDownload(url, ver == null ? "" : ver);
    }

    @JavascriptInterface
    public void openBrowser(String url) {
      if (url == null || url.isEmpty()) return;
      MainActivity.this.openExternal(url);
    }

    @JavascriptInterface
    public boolean hasDownloader() { return false; }

    @JavascriptInterface
    public String apiBase() {
      String b = (base == null ? "" : base);
      while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
      return b;
    }

    @JavascriptInterface
    public String base() { return base == null ? "" : base; }

    @JavascriptInterface
    public int latency() { return latency; }

    @JavascriptInterface
    public String candidates() {
      StringBuilder sb = new StringBuilder("[");
      List<String[]> l = ordered == null ? new ArrayList<>() : ordered;
      for (int i = 0; i < l.size(); i++) {
        String[] c = l.get(i);
        if (i > 0) sb.append(",");
        sb.append("{\"base\":\"").append(c[0]).append("\",\"name\":\"").append(c[1])
          .append("\",\"ms\":").append(c[2]).append("}");
      }
      return sb.append("]").toString();
    }

    @JavascriptInterface
    public void repick() { MainActivity.this.repick(); }

    @JavascriptInterface
    public void startNotify(String b, String t, String me) {
      try {
        if (b == null) b = "";
        if (t == null) t = "";
        if (me == null) me = "";
        sp.edit().putString("nb_base", b).putString("nb_token", t).putString("nb_me", me).putBoolean("nb_on", true).apply();
        NotifyService.start(MainActivity.this, b, t, me);
      } catch (Exception e) { Log.w(TAG, "startNotify " + e); }
    }

    @JavascriptInterface
    public void stopNotify() {
      try {
        sp.edit().putBoolean("nb_on", false).apply();
        NotifyService.stop(MainActivity.this);
      } catch (Exception e) { }
    }

    @JavascriptInterface
    public boolean notifyOn() { return sp.getBoolean("nb_on", false); }

    @JavascriptInterface
    public String notifyState() { return sp.getBoolean("nb_on", false) ? "on" : "off"; }

    /** 本地记忆：按 key 存字符串（WebView localStorage 之外的兜底，App 卸载才丢） */
    @JavascriptInterface
    public void memPut(String key, String val) {
      try { sp.edit().putString("mem_" + key, val).apply(); } catch (Exception e) { }
    }

    @JavascriptInterface
    public String memGet(String key) {
      try { return sp.getString("mem_" + key, ""); } catch (Exception e) { return ""; }
    }

    @JavascriptInterface
    public String memKeys() {
      try {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (String k : sp.getAll().keySet()) {
          if (!k.startsWith("mem_")) continue;
          if (!first) sb.append(",");
          sb.append("\"").append(k.substring(4)).append("\"");
          first = false;
        }
        return sb.append("]").toString();
      } catch (Exception e) { return "[]"; }
    }

    @JavascriptInterface
    public String saveFile(final String name, final String mime, final String b64) {
      try {
        final byte[] data = Base64.decode(b64, Base64.DEFAULT);
        if (Build.VERSION.SDK_INT >= 29) {
          ContentValues cv = new ContentValues();
          cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
          cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
          cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/\u5bb6\u5ead\u5c0f\u5c4b");
          Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
          OutputStream os = getContentResolver().openOutputStream(uri);
          os.write(data);
          os.close();
        } else {
          File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "\u5bb6\u5ead\u5c0f\u5c4b");
          if (!dir.exists()) dir.mkdirs();
          FileOutputStream fo = new FileOutputStream(new File(dir, name));
          fo.write(data);
          fo.close();
        }
        return "ok";
      } catch (Exception e) {
        return "err:" + e.getMessage();
      }
    }

    /* ===== v1.35.0 原生录音桥：绕开 WebView getUserMedia 故障 ===== */
    @android.webkit.JavascriptInterface
    public String startStream() {
        try { return rec.startStream(); } catch (Throwable t) { return "ERR " + t; }
      }

    @JavascriptInterface
    public String takeChunk() {
        try { return rec.takeChunk(); } catch (Throwable t) { return ""; }
      }

    @JavascriptInterface
    public String stopStream() {
        try { return rec.stopStream(); } catch (Throwable t) { return "ERR " + t; }
      }
    public int recLevel() { return rec.level(); }

    @JavascriptInterface
    public String startRec() {
      if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        try { requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 1009); } catch (Throwable t) {}
        return "needperm";
      }
      try { return rec.start(); } catch (Throwable t) { return "ERR " + t; }
    }

    @JavascriptInterface
    public String stopRec() {
      try { return rec.stop(); } catch (Throwable t) { return "ERR " + t; }
    }

    @JavascriptInterface
    public boolean recBusy() { return rec.busy(); }

    @JavascriptInterface
    public String recErr() { return rec.err(); }
  }
}