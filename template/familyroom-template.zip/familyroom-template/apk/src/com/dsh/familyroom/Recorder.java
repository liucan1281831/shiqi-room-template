package com.dsh.familyroom;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Base64;

import java.io.ByteArrayOutputStream;

/** v1.35.0: 原生录音（绕开 WebView 在某些 ColorOS 机型上 getUserMedia 报 NotReadableError 的问题） */
public class Recorder {
    public static final int SR = 16000;
    private static final int SRC = MediaRecorder.AudioSource.MIC;

    private AudioRecord ar;
    private Thread th;
    private volatile boolean running;
    private ByteArrayOutputStream bos;
    private String lastErr = "";
    private volatile int level = 0;
  private volatile long dbgN = 0;
    private volatile int peakMax = 0;
    // v1.40：流式通话（把 PCM 分块交给 JS）
    private final java.io.ByteArrayOutputStream stq = new java.io.ByteArrayOutputStream();
    private volatile boolean streaming = false;

    public synchronized int peak() { return peakMax; }

    public synchronized String start() {
        if (running) return "ok";
        peakMax = 0; level = 0;
        int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min < 4096) min = 4096;
        try {
            ar = new AudioRecord(SRC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2);
        } catch (Throwable t) {
            lastErr = "ctor " + t;
            ar = null;
            return "ERR " + t;
        }
        if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
            try { ar.release(); } catch (Throwable t) {}
            ar = null;
            lastErr = "init";
            return "ERR init";
        }
        bos = new ByteArrayOutputStream();
        try {
            ar.startRecording();
        } catch (Throwable t) {
            lastErr = "start " + t;
            try { ar.release(); } catch (Throwable t2) {}
            ar = null;
            return "ERR " + t;
        }
        running = true;
        th = new Thread(new Runnable() {
            public void run() {
                byte[] buf = new byte[3200];
                AudioRecord r = ar;
                while (running && r != null) {
                    int n;
                    try {
                        n = r.read(buf, 0, buf.length);
                    } catch (Throwable t) {
                        break;
                    }
                    if (n > 0) {
                        int sum = 0, cnt = 0;
                        for (int i = 0; i + 1 < n; i += 2) {
                            int v = (short) ((buf[i] & 0xff) | (buf[i + 1] << 8));
                            sum += v * v; cnt++;
                        }
                        if (cnt > 0) {
                            double rms = Math.sqrt((double) sum / cnt);
                            // v1.37.2: 20 倍数字增益（约 +26dB），低声说话也能被 ASR 听清
                            int lv = (int) Math.round(rms * 20.0 / 32768.0 * 300.0);
                            level = lv > 100 ? 100 : lv;
                            int pk = (int) Math.round(rms * 20.0);
                            if (pk > peakMax) peakMax = pk;
                            if ((dbgN++ % 3) == 0) android.util.Log.i("DSHRec", "lvl=" + level + " rms=" + (int) rms + " peak=" + peakMax + " n=" + n);
                            for (int i = 0; i + 1 < n; i += 2) {
                                int v = (short) ((buf[i] & 0xff) | (buf[i + 1] << 8));
                                int a = v * 20;
                                if (a > 30000) a = 30000 + (a - 30000) / 8;
                                if (a < -30000) a = -30000 + (a + 30000) / 8;
                                if (a > 32767) a = 32767;
                                if (a < -32768) a = -32768;
                                buf[i] = (byte) (a & 0xff);
                                buf[i + 1] = (byte) ((a >> 8) & 0xff);
                            }
                        }
                        if (streaming) {
                            synchronized (stq) { try { stq.write(buf, 0, n); } catch (Throwable t) {} }
                        } else {
                            try { bos.write(buf, 0, n); } catch (Throwable t) { break; }
                        }
                    }
                }
            }
        });
        th.setDaemon(true);
        th.start();
        return "ok";
    }

    /** 返回 "data:audio/wav;base64,…" / "SHORT" / "ERR …" */
    public synchronized String stop() {
        if (!running && ar == null) return "ERR idle";
        running = false;
        try { if (th != null) th.join(900); } catch (Throwable t) {}
        try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable t) {}
        ar = null;
        th = null;
        byte[] pcm = new byte[0];
        try { if (bos != null) pcm = bos.toByteArray(); } catch (Throwable t) {}
        bos = null;
        if (pcm.length < SR * 2 * 3 / 10) return "SHORT";          // < 0.3 秒
        if (pcm.length > SR * 2 * 60) {                             // 最长 60 秒
            byte[] cut = new byte[SR * 2 * 60];
            System.arraycopy(pcm, 0, cut, 0, cut.length);
            pcm = cut;
        }
        return "data:audio/wav;base64," + Base64.encodeToString(wav(pcm), Base64.NO_WRAP);
    }

    /** 实时音量 0~100（不录音时为 0） */
    public int level() { return running ? level : 0; }

    public boolean busy() { return running; }
    public String err() { return lastErr; }

    // ---------------- v1.40 流式通话 ----------------
    public synchronized String startStream() {
        if (running) { streaming = true; return "ok"; }
        synchronized (stq) { stq.reset(); }
        streaming = true;
        String r = start();
        if (!"ok".equals(r)) { streaming = false; return r; }
        return "ok";
    }

    /** 取走自上次调用以来的 PCM16(16k/单声道) base64；无数据返回空串 */
    public synchronized String takeChunk() {
        if (!running) return "";
        byte[] all;
        synchronized (stq) { all = stq.toByteArray(); stq.reset(); }
        if (all.length == 0) return "";
        if (all.length > SR * 2 * 4) { byte[] c = new byte[SR * 2 * 4]; System.arraycopy(all, 0, c, 0, c.length); all = c; }
        return Base64.encodeToString(all, Base64.NO_WRAP);
    }

    public synchronized String stopStream() {
        streaming = false;
        synchronized (stq) { stq.reset(); }
        try { stop(); } catch (Throwable t) {}
        return "ok";
    }

    private static byte[] wav(byte[] pcm) {
        int n = pcm.length;
        byte[] out = new byte[44 + n];
        int[] h = new int[]{0x52, 0x49, 0x46, 0x46};                 // RIFF
        for (int i = 0; i < 4; i++) out[i] = (byte) h[i];
        putLE32(out, 4, 36 + n);
        out[8] = 'W'; out[9] = 'A'; out[10] = 'V'; out[11] = 'E';   // WAVE
        out[12] = 'f'; out[13] = 'm'; out[14] = 't'; out[15] = ' ';
        putLE32(out, 16, 16);
        putLE16(out, 20, 1);                                        // PCM
        putLE16(out, 22, 1);                                        // mono
        putLE32(out, 24, SR);
        putLE32(out, 28, SR * 2);
        putLE16(out, 32, 2);
        putLE16(out, 34, 16);
        out[36] = 'd'; out[37] = 'a'; out[38] = 't'; out[39] = 'a';
        putLE32(out, 40, n);
        System.arraycopy(pcm, 0, out, 44, n);
        return out;
    }

    private static void putLE32(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xff);
        b[off + 1] = (byte) ((v >> 8) & 0xff);
        b[off + 2] = (byte) ((v >> 16) & 0xff);
        b[off + 3] = (byte) ((v >> 24) & 0xff);
    }

    private static void putLE16(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xff);
        b[off + 1] = (byte) ((v >> 8) & 0xff);
    }
}