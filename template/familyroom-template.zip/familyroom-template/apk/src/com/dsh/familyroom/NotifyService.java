package com.dsh.familyroom;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Set;

/**
 * RoomNotifyService v34
 * Foreground service that keeps an SSE connection to the room and raises a real
 * system notification for every new message that is not mine.
 * Survives screen off / app in background (foreground service), reconnects on error.
 */
public class NotifyService extends Service {
  public static final String TAG = "RoomNotify";
  public static final String CH_SYNC = "room_sync_v2";
  public static final String CH_MSG = "room_msg_v3";
  public static final String CH_MEN = "room_mention_v1";   // 被 @
  public static final String CH_MOM = "room_moment_v1";    // 动态
  public static final String CH_DIA = "room_diary_v1";     // 日记
  public static final int ID_SYNC = 9001;
  public static final int ID_MSG_BASE = 9100;

  public static final String EXTRA_BASE = "base";
  public static final String EXTRA_TOKEN = "token";
  public static final String EXTRA_ME = "me";
  public static final String EXTRA_ON = "on";

  private volatile boolean running = false;
  private Thread worker;
  private HttpURLConnection conn;
  private final java.util.List<HttpURLConnection> conns = new java.util.ArrayList<>();
  private String base = "", token = "", me = "";
  private final Set<Long> seen = new HashSet<>();
  private int msgSeq = 0;

  // v37：私聊也要推通知（三个私聊 + 家庭频道）
  private static final String[] CHANS = { "family", "dm_laoda_shiqi", "dm_laoda_jiu", "dm_laoda_hutao" };
  private static String chanLabel(String ch) {
    if (ch == null) return "";
    if (ch.equals("dm_laoda_shiqi")) return "\u79c1\u804a\u00b7\u62fe\u67d2";
    if (ch.equals("dm_laoda_jiu")) return "\u79c1\u804a\u00b7\u7396";
    if (ch.equals("dm_laoda_hutao")) return "\u79c1\u804a\u00b7\u80e1\u6843";
    if (ch.equals("family")) return "\u5bb6\u5ead\u5c0f\u5c4b";
    return "";
  }

  public static void start(Context c, String base, String token, String me) {
    Intent i = new Intent(c, NotifyService.class);
    i.putExtra(EXTRA_BASE, base);
    i.putExtra(EXTRA_TOKEN, token);
    i.putExtra(EXTRA_ME, me);
    i.putExtra(EXTRA_ON, true);
    if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
  }

  public static void stop(Context c) {
    Intent i = new Intent(c, NotifyService.class);
    i.putExtra(EXTRA_ON, false);
    try { c.startService(i); } catch (Exception e) { }
  }

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public void onCreate() {
    super.onCreate();
    channels();
    startForeground(ID_SYNC, syncNote("\u5c0f\u5c4b\u6d88\u606f\u540c\u6b65\u4e2d"));
    startHeartbeat();
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent == null) return START_STICKY;
    boolean on = intent.getBooleanExtra(EXTRA_ON, true);
    if (!on) { stopAll(); stopSelf(); return START_NOT_STICKY; }
    base = intent.getStringExtra(EXTRA_BASE);
    token = intent.getStringExtra(EXTRA_TOKEN);
    me = intent.getStringExtra(EXTRA_ME);
    if (base == null) base = "";
    if (token == null) token = "";
    if (me == null) me = "";
    SharedPreferences sp = getSharedPreferences("roomapp", MODE_PRIVATE);
    sp.edit().putString("nb_base", base).putString("nb_token", token).putString("nb_me", me).putBoolean("nb_on", true).apply();
    startWorker();
    return START_STICKY;
  }

  @Override public void onDestroy() {
    stopAll();
    super.onDestroy();
  }

  private void stopAll() {
    running = false;
    try { if (conn != null) conn.disconnect(); } catch (Exception e) { }
    try { if (worker != null) worker.interrupt(); } catch (Exception e) { }
    worker = null;
    try { stopForeground(true); } catch (Exception e) { }
  }

  private void startWorker() {
    if (running) return;
    running = true;
    // v37：每个频道（家庭 + 三个私聊）各起一条 SSE 长连接
    for (int i = 0; i < CHANS.length; i++) {
      final String ch = CHANS[i];
      Thread t = new Thread(new Runnable() { public void run() { loop(ch); } }, "room-sse-" + ch);
      t.setDaemon(true);
      t.start();
      if (i == 0) worker = t;
    }
  }

  private void loop(String ch) {
    long backoff = 1000;
    while (running) {
      try {
        String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
        String u = base.replaceAll("/+$", "") + "/api/stream?channel=" + URLEncoder.encode(ch, "UTF-8") + "&token=" + URLEncoder.encode(token, "UTF-8");
        URL url = new URL(u);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        synchronized (conns) { conns.add(c); }
        conn = c;
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Accept", "text/event-stream");
        c.setConnectTimeout(12000);
        c.setReadTimeout(0);
        int code = c.getResponseCode();
        if (code != 200) {
          Log.i(TAG, "stream " + ch + " http " + code + " -> retry");
          try { Thread.sleep(backoff); } catch (InterruptedException e) { break; }
          backoff = Math.min(backoff * 2, 30000);
          continue;
        }
        backoff = 1000;
        updateSync("\u5df2\u8fde\u63a5");
        InputStream in = c.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        String line;
        while (running && (line = br.readLine()) != null) {
          if (!line.startsWith("data:")) continue;
          String js = line.substring(5).trim();
          if (js.startsWith("{")) onEvent(js, ch);
        }
      } catch (Exception e) {
        if (!running) break;
        Log.i(TAG, "stream " + ch + " error: " + e);
        try { Thread.sleep(backoff); } catch (InterruptedException ie) { break; }
        backoff = Math.min(backoff * 2, 30000);
      } finally {
        synchronized (conns) { for (int i = 0; i < conns.size(); i++) { try { conns.get(i).disconnect(); } catch (Exception e) { } } conns.clear(); }
        conn = null;
      }
    }
  }

  private void onEvent(String js, String ch) {
    long ts = num(js, "ts", 0);
    String who = str(js, "who", "");
    String name = str(js, "name", who);
    String text = str(js, "text", "");
    String kind = str(js, "kind", "");
    if (ts <= 0) return;
    if (who.equals(me)) return;
    synchronized (seen) {
      if (seen.contains(ts)) return;
      seen.add(ts);
      if (seen.size() > 500) seen.clear();
    }
    if (text.length() == 0 && kind.length() == 0) return;
    // v127: 免打扰时段静默（@我/私聊在服务端已标成 "m"，不会进这里）
    if (js.indexOf("\"nf\":\"q\"") >= 0) return;
    if (text.length() == 0) text = "[" + kind + "]";
    if (text.length() > 120) text = text.substring(0, 120) + "...";
    String lb = chanLabel(ch);
    String title = ch.startsWith("dm_") ? (lb.length() > 0 ? lb : name) : (lb.length() > 0 ? (name + "  " + lb) : name);
    boolean called = js.indexOf("\"\u8001\u5927\"") >= 0 && js.indexOf("mentions") >= 0;
    String chan = CH_MSG;
    if (called) chan = CH_MEN;
    else if (kind.equals("diary")) chan = CH_DIA;
    else if (kind.equals("moment")) chan = CH_MOM;
    if (chan == CH_MEN) title = "\u2744 " + title;
    else if (chan == CH_DIA) title = "\ud83d\udcd4 " + title;
    else if (chan == CH_MOM) title = "\ud83d\udcf8 " + title;
    notifyMsg(title, text, ch, chan);
    updateSync("\u6700\u65b0\uff1a" + name);
  }

  // ---- v1.19：按通知频道聚合未读 ----
  private static final java.util.LinkedHashMap<String, java.util.ArrayList<String>> LINES =
      new java.util.LinkedHashMap<String, java.util.ArrayList<String>>();

  public static void clearCh(Context c, String ch) {
    String key = (ch == null || ch.length() == 0) ? CH_MSG : ch;
    synchronized (LINES) { LINES.remove(key); }
    try {
      if (c != null) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(nidFor(key));
      }
    } catch (Exception e) { }
  }

  private static int nidFor(String key) {
    return ID_MSG_BASE + (Math.abs(String.valueOf(key).hashCode()) % 900);
  }

  private void notifyMsg(String name, String text, String ch, String chan) {
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    Intent open = new Intent(this, MainActivity.class);
    open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    open.putExtra("from_notify", true);
    if (ch != null && ch.length() > 0) open.putExtra("channel", ch);
    PendingIntent pi = PendingIntent.getActivity(this, 1, open,
        Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT);
    Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
        ? new Notification.Builder(this, (chan != null && chan.length() > 0) ? chan : CH_MSG) : new Notification.Builder(this);
    b.setSmallIcon(android.R.drawable.sym_action_chat)
     .setContentTitle(name)
     .setContentText(text)
     .setStyle(new Notification.BigTextStyle().bigText(text))
     .setAutoCancel(true)
     .setContentIntent(pi)
     .setWhen(System.currentTimeMillis())
     .setDefaults(Notification.DEFAULT_ALL)
     .setPriority(Notification.PRIORITY_HIGH)
     .setCategory(Notification.CATEGORY_MESSAGE)
     .setVisibility(Notification.VISIBILITY_PUBLIC)
     .setOnlyAlertOnce(false);
    // v1.19：同一通知频道聚合，多条用收件箱样式 + 条数角标
    String key = (chan == null || chan.length() == 0) ? CH_MSG : chan;
    java.util.ArrayList<String> lines;
    synchronized (LINES) {
      lines = LINES.get(key);
      if (lines == null) { lines = new java.util.ArrayList<String>(); LINES.put(key, lines); }
      String one = name + "\uff1a" + text;
      lines.remove(one);
      lines.add(0, one);
      while (lines.size() > 6) lines.remove(lines.size() - 1);
    }
    int cnt = lines.size();
    b.setNumber(cnt);
    if (cnt > 1) {
      String[] arr = lines.toArray(new String[0]);
      Notification.InboxStyle inb = new Notification.InboxStyle();
      inb.setBigContentTitle(name + " \u7b49 " + cnt + " \u6761");
      int cap = Math.min(arr.length, 5);
      for (int i = 0; i < cap; i++) inb.addLine(arr[i]);
      if (arr.length > cap) inb.addLine("\u2026");
      inb.setSummaryText(cnt + " \u6761\u672a\u8bfb");
      b.setStyle(inb).setSubText(cnt + " \u6761\u672a\u8bfb");
    }
    int nid = nidFor(key);
    try { nm.notify(nid, b.build()); } catch (Exception e) { Log.i(TAG, "notify fail " + e); }
  }

  private void updateSync(String s) {
    try {
      NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      nm.notify(ID_SYNC, syncNote(s));
    } catch (Exception e) { }
  }

  private Notification syncNote(String s) {
    Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
        ? new Notification.Builder(this, CH_SYNC) : new Notification.Builder(this);
    Intent open = new Intent(this, MainActivity.class);
    PendingIntent pi = PendingIntent.getActivity(this, 2, open,
        Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT);
    b.setSmallIcon(android.R.drawable.stat_notify_sync)
     .setContentTitle("\u5bb6\u5ead\u5c0f\u5c4b")
     .setContentText(s)
     .setOngoing(true)
     .setAutoCancel(false)
     .setOnlyAlertOnce(true)
     .setShowWhen(false)
     .setCategory(Notification.CATEGORY_SERVICE)
     .setVisibility(Notification.VISIBILITY_PUBLIC)
     .setContentIntent(pi);
    if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
    return b.build();
  }

  private void channels() {
    if (Build.VERSION.SDK_INT < 26) return;
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    try { nm.deleteNotificationChannel("room_msg"); } catch (Exception e) { }
    try { nm.deleteNotificationChannel("room_msg_v2"); } catch (Exception e) { }
    try { nm.deleteNotificationChannel("room_sync"); } catch (Exception e) { }
    NotificationChannel c1 = new NotificationChannel(CH_SYNC, "\u5c0f\u5c4b\u5e38\u9a7b", NotificationManager.IMPORTANCE_LOW);
    c1.setDescription("\u5e38\u9a7b\u901a\u77e5\uff1a\u540c\u6b65\u72b6\u6001\u4e0e\u6700\u65b0\u6d88\u606f\uff0c\u4e0d\u54cd\u4e0d\u9707\u52a8");
    c1.setShowBadge(false);
    c1.setSound(null, null);
    c1.enableVibration(false);
    c1.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
    NotificationChannel c2 = new NotificationChannel(CH_MSG, "\u5c0f\u5c4b\u6d88\u606f", NotificationManager.IMPORTANCE_HIGH);
    c2.setShowBadge(true);
    c2.enableVibration(true);
    c2.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
    NotificationChannel c3 = new NotificationChannel(CH_MEN, "\u5bab\u88ab@", NotificationManager.IMPORTANCE_HIGH);
    c3.setDescription("\u6709\u4eba @\u4f60"); c3.enableVibration(true);
    c3.setVibrationPattern(new long[]{0, 150, 90, 150});
    NotificationChannel c4 = new NotificationChannel(CH_MOM, "\u5bab\u52a8\u6001", NotificationManager.IMPORTANCE_HIGH);
    c4.setDescription("\u5bab\u52a8\u6001\u66f4\u65b0"); c4.enableVibration(true);
    c4.setVibrationPattern(new long[]{0, 60});
    NotificationChannel c5 = new NotificationChannel(CH_DIA, "\u5bab\u65e5\u8bb0", NotificationManager.IMPORTANCE_DEFAULT);
    c5.setDescription("\u5bab\u65e5\u8bb0\u66f4\u65b0"); c5.setSound(null, null); c5.enableVibration(true);
    c5.setVibrationPattern(new long[]{0, 40});
    nm.createNotificationChannel(c1);
    nm.createNotificationChannel(c2);
    nm.createNotificationChannel(c3);
    nm.createNotificationChannel(c4);
    nm.createNotificationChannel(c5);
  }

  private volatile boolean hbRun = false;
  private void startHeartbeat() {
    if (hbRun) return;
    hbRun = true;
    Thread t = new Thread(new Runnable() {
      public void run() {
        while (running) {
          try { postAppNotify(); } catch (Throwable e) { Log.i(TAG, "hb " + e); }
          try { Thread.sleep(60000); } catch (Throwable e) { }
        }
        hbRun = false;
      }
    }, "room-hb");
    t.setDaemon(true);
    t.start();
  }

  private void postAppNotify() {
    if (base == null || base.length() == 0) return;
    HttpURLConnection c = null;
    try {
      URL u = new URL(base.replaceAll("/+$", "") + "/api/appnotify");
      c = (HttpURLConnection) u.openConnection();
      c.setRequestMethod("POST");
      c.setConnectTimeout(8000);
      c.setReadTimeout(8000);
      c.setDoOutput(true);
      c.setRequestProperty("Content-Type", "application/json");
      if (token != null && token.length() > 0) c.setRequestProperty("Authorization", "Bearer " + token);
      c.getOutputStream().write("{\"on\":true}".getBytes("UTF-8"));
      c.getOutputStream().flush();
      c.getResponseCode();
    } catch (Throwable e) {
      Log.i(TAG, "hb fail " + e);
    } finally {
      try { if (c != null) c.disconnect(); } catch (Throwable e) { }
    }
  }

  private static String str(String js, String key, String def) {
    String k = "\"" + key + "\":";
    int i = js.indexOf(k);
    if (i < 0) return def;
    int p = i + k.length();
    while (p < js.length() && js.charAt(p) == ' ') p++;
    if (p >= js.length()) return def;
    char c = js.charAt(p);
    if (c != '"') return def;
    StringBuilder sb = new StringBuilder();
    for (int j = p + 1; j < js.length(); j++) {
      char ch = js.charAt(j);
      if (ch == '\\' && j + 1 < js.length()) {
        char n = js.charAt(j + 1);
        if (n == 'n') { sb.append('\n'); j++; }
        else if (n == 't') { sb.append('\t'); j++; }
        else if (n == 'u' && j + 5 < js.length()) {
          try { sb.append((char) Integer.parseInt(js.substring(j + 2, j + 6), 16)); j += 5; } catch (Exception e) { }
        } else { sb.append(n); j++; }
      } else if (ch == '"') break;
      else sb.append(ch);
    }
    return sb.toString();
  }

  private static long num(String js, String key, long def) {
    String k = "\"" + key + "\":";
    int i = js.indexOf(k);
    if (i < 0) return def;
    int p = i + k.length();
    StringBuilder sb = new StringBuilder();
    while (p < js.length()) {
      char c = js.charAt(p);
      if (c >= '0' && c <= '9') { sb.append(c); p++; } else break;
    }
    try { return Long.parseLong(sb.toString()); } catch (Exception e) { return def; }
  }
}