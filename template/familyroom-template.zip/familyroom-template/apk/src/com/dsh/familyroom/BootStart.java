package com.dsh.familyroom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

/** v34: restart the notification service after boot / app update. */
public class BootStart extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    try {
      String a = i == null ? "" : String.valueOf(i.getAction());
      if (!"android.intent.action.BOOT_COMPLETED".equals(a)
          && !"android.intent.action.MY_PACKAGE_REPLACED".equals(a)) return;
      SharedPreferences sp = c.getSharedPreferences("roomapp", Context.MODE_PRIVATE);
      if (!sp.getBoolean("nb_on", false)) return;
      String base = sp.getString("nb_base", "");
      String token = sp.getString("nb_token", "");
      String me = sp.getString("nb_me", "");
      if (token == null || token.length() == 0) return;
      NotifyService.start(c, base, token, me);
      Log.i("RoomNotify", "boot -> notify service started");
    } catch (Exception e) {
      Log.w("RoomNotify", "boot start failed " + e);
    }
  }
}