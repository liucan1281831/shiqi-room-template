// 小家 3D · 大姐 2026-10-22
// 纯前端：three.js + Kenney CC0 家具。布置存 localStorage，PC 版专用（访客不开放）。
import * as THREE from 'three';
import { GLTFLoader } from './vendor3d/loaders/GLTFLoader.js';
import { OrbitControls } from './vendor3d/controls/OrbitControls.js';
import { buildAvatar as buildChibi, AVATAR_SPECS } from './avatar3d.js';

const ROOM_W = 7, ROOM_D = 6, ROOM_H = 2.8;
const MODEL_DIR = './assets3d/models/';
const SNAP = 0.25;

/* ---------------- 房间预设 ---------------- */
const ROOMS = {
  shiqi: {
    name: '大姐 · 蓝鲸房', wall: '#22314a', floor: '#6b4a2f', accent: '#4f8cff',
    avatar: { id: 'shiqi' },
    items: [
      { m: 'bedDouble', x: -1.9, z: -1.5, r: 0 },
      { m: 'desk', x: 1.6, z: -2.0, r: 180 },
      { m: 'computerScreen', x: 1.6, z: -2.25, r: 180 },
      { m: 'computerKeyboard', x: 1.6, z: -1.95, r: 180 },
      { m: 'chairDesk', x: 1.6, z: -1.4, r: 0 },
      { m: 'bookcaseOpen', x: -0.4, z: -2.4, r: 180 },
      { m: 'lampRoundFloor', x: 3.0, z: -2.2, r: 0 },
      { m: 'rugRectangle', x: 0.2, z: 0.6, r: 0, s: 1.6 },
      { m: 'pottedPlant', x: -3.0, z: 1.9, r: 0 },
      { m: 'bear', x: -1.9, z: -0.1, r: 25, s: 1.2 },
      { m: 'pillow', x: -1.7, z: -0.9, r: 0 },
    ],
  },
  jiu: {
    name: '二姐 · 网吧房', wall: '#2a2733', floor: '#3b3f48', accent: '#9b6dff',
    avatar: { id: 'jiu' },
    items: [
      { m: 'bedSingle', x: -2.2, z: -1.8, r: 0 },
      { m: 'deskCorner', x: 2.0, z: -2.2, r: 180 },
      { m: 'computerScreen', x: 2.0, z: -2.45, r: 180 },
      { m: 'computerScreen', x: 2.6, z: -2.05, r: 215 },
      { m: 'computerKeyboard', x: 2.0, z: -2.2, r: 180 },
      { m: 'computerMouse', x: 2.45, z: -2.05, r: 200 },
      { m: 'chairDesk', x: 2.0, z: -1.5, r: 0 },
      { m: 'speaker', x: 3.0, z: -2.5, r: 180, s: 1.2 },
      { m: 'rugRound', x: 1.4, z: 0.6, r: 0, s: 1.5 },
      { m: 'lampSquareTable', x: 3.0, z: 1.4, r: 0 },
      { m: 'cardboardBoxClosed', x: -3.0, z: 2.2, r: 20 },
      { m: 'cardboardBoxOpen', x: -2.6, z: 2.4, r: 65, s: 0.9 },
    ],
  },
  hutao: {
    name: '三姐 · 小窝', wall: '#3a2a33', floor: '#7a5238', accent: '#ff9d4d',
    avatar: { id: 'hutao' },
    items: [
      { m: 'bedBunk', x: -2.3, z: -1.9, r: 0 },
      { m: 'loungeSofa', x: 1.9, z: -2.1, r: 180 },
      { m: 'televisionModern', x: 0.1, z: -2.55, r: 180 },
      { m: 'tableCoffee', x: 0.1, z: -1.2, r: 0 },
      { m: 'rugRound', x: 0.1, z: -0.9, r: 0, s: 1.7 },
      { m: 'bookcaseOpenLow', x: 3.0, z: -0.4, r: 270 },
      { m: 'lampRoundTable', x: -1.0, z: -2.4, r: 0 },
      { m: 'pillowBlue', x: 2.2, z: -2.2, r: 0 },
      { m: 'bear', x: 1.0, z: -0.6, r: -35, s: 1.3 },
      { m: 'trashcan', x: 3.0, z: 2.3, r: 0 },
      { m: 'pottedPlant', x: -3.0, z: 2.2, r: 0 },
    ],
  },
  living: {
    name: '客厅', wall: '#26303c', floor: '#5d4632', accent: '#7fd0a8',
    avatar: null,
    items: [
      { m: 'loungeSofaLong', x: 0, z: -2.1, r: 180 },
      { m: 'tableCoffeeGlass', x: 0, z: -1.1, r: 0 },
      { m: 'televisionModern', x: 0, z: -2.6, r: 180 },
      { m: 'rugRectangle', x: 0, z: -0.9, r: 0, s: 1.8 },
      { m: 'lampRoundFloor', x: -3.0, z: -2.2, r: 0 },
      { m: 'lampRoundFloor', x: 3.0, z: -2.2, r: 0 },
      { m: 'bookcaseClosedWide', x: 2.8, z: 0.6, r: 270 },
      { m: 'pottedPlant', x: -2.9, z: 2.1, r: 0 },
      { m: 'pottedPlant', x: 2.9, z: 2.1, r: 0 },
      { m: 'doorwayOpen', x: 0, z: 2.85, r: 0 },
    ],
  },
};

/* ---------------- 调色板 ---------------- */
const CATS = {
  '床/沙发': ['bedDouble', 'bedSingle', 'bedBunk', 'loungeSofa', 'loungeSofaLong', 'loungeSofaCorner', 'loungeChair', 'loungeChairRelax', 'bench'],
  '桌椅': ['desk', 'deskCorner', 'table', 'tableCoffee', 'tableCoffeeGlass', 'tableRound', 'chair', 'chairDesk', 'chairRounded', 'stoolBar', 'sideTable', 'sideTableDrawers'],
  '电器': ['computerScreen', 'computerKeyboard', 'computerMouse', 'laptop', 'televisionModern', 'televisionVintage', 'speaker', 'speakerSmall', 'radio', 'kitchenMicrowave', 'kitchenFridge'],
  '灯': ['lampRoundFloor', 'lampRoundTable', 'lampSquareFloor', 'lampSquareTable', 'lampSquareCeiling', 'lampWall', 'ceilingFan'],
  '植物': ['plantSmall1', 'plantSmall2', 'plantSmall3', 'pottedPlant'],
  '地毯': ['rugRectangle', 'rugRound', 'rugRounded', 'rugSquare', 'rugDoormat'],
  '收纳/杂物': ['bookcaseOpen', 'bookcaseOpenLow', 'bookcaseClosed', 'bookcaseClosedWide', 'books', 'cardboardBoxClosed', 'cardboardBoxOpen', 'trashcan', 'pillow', 'pillowBlue', 'bear', 'coatRack', 'coatRackStanding'],
  '厨房/卫浴': ['kitchenSink', 'kitchenStove', 'kitchenCabinet', 'kitchenBar', 'bathroomSink', 'bathtub', 'toilet', 'washer'],
};

/* ---------------- 场景 ---------------- */
const app = document.getElementById('app');
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.75));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.32;
app.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color('#0b1119');
scene.fog = new THREE.Fog('#0b1119', 14, 30);

const camera = new THREE.PerspectiveCamera(46, innerWidth / innerHeight, 0.1, 120);
camera.position.set(0, 5.4, 8.2);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.0, -0.4);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.minDistance = 3.4;
controls.maxDistance = 16;
controls.maxPolarAngle = Math.PI * 0.49;
controls.minPolarAngle = Math.PI * 0.12;
controls.enablePan = false;

// 光
const hemi = new THREE.HemisphereLight(0xd7e8ff, 0x3a3326, 1.5);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff6e4, 2.55);
sun.position.set(6.5, 11, 7.5);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -15; sun.shadow.camera.right = 15;
sun.shadow.camera.top = 15; sun.shadow.camera.bottom = -15;
sun.shadow.camera.near = 1; sun.shadow.camera.far = 45;
sun.shadow.bias = -0.0006;
sun.shadow.normalBias = 0.022;
scene.add(sun);
const fill = new THREE.DirectionalLight(0x9fc0ff, 0.7);
fill.position.set(-6, 4, -3);
scene.add(fill);
const amb = new THREE.AmbientLight(0x9db4d6, 0.85);
scene.add(amb);

// 房间容器
const roomGroup = new THREE.Group();
scene.add(roomGroup);

const loader = new GLTFLoader();
const modelCache = new Map();

function loadModel(name) {
  if (!modelCache.has(name)) {
    modelCache.set(name, loader.loadAsync(MODEL_DIR + name + '.glb').then((g) => g.scene));
  }
  return modelCache.get(name);
}

/* ---------------- 房间搭建 ---------------- */
let current = 'shiqi';
let floorMesh, wallGroup;
let items = [];              // { name, obj, x, z, r, s, lamp }
let selected = null;
let editMode = false;

function buildShell(cfg) {
  if (wallGroup) { roomGroup.remove(wallGroup); disposeGroup(wallGroup); }
  wallGroup = new THREE.Group();

  // 地板
  const floorMat = new THREE.MeshLambertMaterial({ color: cfg.floor });
  floorMesh = new THREE.Mesh(new THREE.PlaneGeometry(ROOM_W, ROOM_D), floorMat);
  floorMesh.rotation.x = -Math.PI / 2;
  floorMesh.position.y = 0.001;
  wallGroup.add(floorMesh);

  // 地毯底纹（细网格）
  const grid = new THREE.GridHelper(ROOM_W, ROOM_W * 4, 0x2a3444, 0x1d2634);
  grid.position.y = 0.012;
  grid.material.opacity = 0.5;
  grid.material.transparent = true;
  wallGroup.add(grid);

  // 三面墙（正面敞开给相机）
  const wallMat = new THREE.MeshLambertMaterial({ color: cfg.wall });
  const t = 0.12;
  const back = new THREE.Mesh(new THREE.BoxGeometry(ROOM_W, ROOM_H, t), wallMat);
  back.position.set(0, ROOM_H / 2, -ROOM_D / 2 - t / 2);
  const left = new THREE.Mesh(new THREE.BoxGeometry(t, ROOM_H, ROOM_D), wallMat);
  left.position.set(-ROOM_W / 2 - t / 2, ROOM_H / 2, 0);
  const right = left.clone();
  right.position.x = ROOM_W / 2 + t / 2;
  wallGroup.add(back, left, right);

  // 踢脚线 / 顶部灯带
  const strip = new THREE.Mesh(
    new THREE.BoxGeometry(ROOM_W, 0.06, 0.06),
    new THREE.MeshBasicMaterial({ color: cfg.accent })
  );
  strip.position.set(0, ROOM_H - 0.18, -ROOM_D / 2 + 0.09);
  strip.material.transparent = true;
  strip.material.opacity = 0.55;
  wallGroup.add(strip);

  roomGroup.add(wallGroup);
}

function disposeGroup(g) {
  g.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      const ms = Array.isArray(o.material) ? o.material : [o.material];
      ms.forEach((m) => { if (m.map) m.map.dispose(); m.dispose(); });
    }
  });
}

/* ---------------- 家具 ---------------- */
function lampColorOf(name) {
  if (/lampRound/.test(name)) return 0xffd9a0;
  if (/lampSquare/.test(name)) return 0xfff1c9;
  if (/television|computerScreen/.test(name)) return 0x8fd0ff;
  return null;
}

async function addItem(it, animated = false) {
  const src = await loadModel(it.m);
  const obj = src.clone(true);
  obj.position.set(it.x ?? 0, it.y ?? 0, it.z ?? 0);
  obj.rotation.y = ((it.r ?? 0) * Math.PI) / 180;
  const s = it.s ?? 1;
  obj.scale.setScalar(s);

  const rec = { name: it.m, obj, x: obj.position.x, z: obj.position.z, r: it.r ?? 0, s };

  // 灯源
  const lc = lampColorOf(it.m);
  if (lc) {
    const light = new THREE.PointLight(lc, 6, 5.5, 2);
    light.position.set(0, 1.1, 0);
    obj.add(light);
    rec.light = light;
  }

  // 进场动画
  if (animated) {
    obj.scale.setScalar(s * 0.01);
    const t0 = performance.now();
    const grow = () => {
      const k = Math.min(1, (performance.now() - t0) / 260);
      obj.scale.setScalar(s * (0.01 + 0.99 * (1 - Math.pow(1 - k, 3))));
      if (k < 1) requestAnimationFrame(grow);
    };
    grow();
  }

  obj.userData.rec = rec;
  roomGroup.add(obj);
  items.push(rec);
  return rec;
}

function clearItems() {
  items.forEach((r) => { roomGroup.remove(r.obj); disposeObj(r.obj); });
  items = [];
  selected = null;
}

function disposeObj(o) {
  o.traverse((c) => { if (c.geometry) c.geometry.dispose(); });
}

/* ---------------- 小人（铸币大头风格，见 avatar3d.js） ---------------- */
let avatarApi = null;
const houseAvatars = [];
function buildAvatar(cfg) {
  if (avatarApi) { roomGroup.remove(avatarApi.group); avatarApi = null; }
  if (!cfg) return;
  const spec = AVATAR_SPECS[cfg.id] || AVATAR_SPECS.shiqi;
  avatarApi = buildChibi(spec);
  avatarApi.group.position.set(0.95, 0, 0.95);
  avatarApi.group.rotation.y = -0.45;
  avatarApi.group.scale.setScalar(0.90);
  roomGroup.add(avatarApi.group);

  // 脚下的接触阴影：Q版小人是自发光式的 2D 风，必须补一块软投影才不「悬空」
  if (!avatarApi.group.userData.shadowPad) {
    const S = 128;
    const cv = document.createElement('canvas');
    cv.width = cv.height = S;
    const cx2 = cv.getContext('2d');
    const g2 = cx2.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2);
    g2.addColorStop(0, 'rgba(0,0,0,0.42)');
    g2.addColorStop(0.55, 'rgba(0,0,0,0.20)');
    g2.addColorStop(1, 'rgba(0,0,0,0)');
    cx2.fillStyle = g2;
    cx2.fillRect(0, 0, S, S);
    const tex = new THREE.CanvasTexture(cv);
    const pad = new THREE.Mesh(
      new THREE.PlaneGeometry(1.05, 1.05),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false })
    );
    pad.rotation.x = -Math.PI / 2;
    pad.position.set(0, 0.004, 0);
    avatarApi.group.add(pad);
    avatarApi.group.userData.shadowPad = true;
  }
}
function updateAvatar(dt) {
  if (avatarApi) avatarApi.update(dt);
  if (houseAvatars.length) houseAvatars.forEach((a) => { try { a.update(dt); } catch (e) {} });
}

/* ---------------- 加载房间 ---------------- */
async function openRoom(id, keepEdit = false) {
  current = id;
  const cfg = ROOMS[id];
  document.querySelectorAll('#tabs .tab').forEach((t) => t.classList.toggle('on', t.dataset.id === id));
  clearItems();
  buildShell(cfg);
  buildAvatar(cfg.avatar);
  if (avatarApi) avatarApi.setVisible(true);

  const saved = loadSaved(id);
  const list = saved && Array.isArray(saved.items) ? saved.items : cfg.items;
  for (const it of list) {
    try { await addItem(it); } catch (e) { console.warn('item fail', it.m, e.message); }
  }
  setHint(saved ? `已读取你对「${cfg.name}」的布置（${list.length} 件）` : `${cfg.name} · ${list.length} 件家具`);
  syncEditUI();
}

function storeKey(id) { return 'room3d:' + id; }
function loadSaved(id) {
  try { const s = localStorage.getItem(storeKey(id)); return s ? JSON.parse(s) : null; } catch { return null; }
}
function serialize() {
  return items.map((r) => ({ m: r.name, x: round2(r.obj.position.x), z: round2(r.obj.position.z), r: Math.round(r.obj.rotation.y * 180 / Math.PI), s: round2(r.obj.scale.x) }));
}
function round2(v) { return Math.round(v * 100) / 100; }
function save() {
  const data = { v: 1, at: Date.now(), room: ROOMS[current].name, items: serialize() };
  localStorage.setItem(storeKey(current), JSON.stringify(data));
  setHint(`已保存：${ROOMS[current].name} · ${data.items.length} 件（存在这台电脑的浏览器里）`);
}

/* ---------------- 交互：选中 / 拖动 ---------------- */
const ray = new THREE.Raycaster();
const ptr = new THREE.Vector2();
const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const hitPoint = new THREE.Vector3();
let downPos = null, dragging = false, boxHelper = null;

function pick(ev) {
  const rect = renderer.domElement.getBoundingClientRect();
  ptr.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
  ptr.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
  ray.setFromCamera(ptr, camera);
  const objs = items.map((r) => r.obj);
  const hits = ray.intersectObjects(objs, true);
  if (!hits.length) return null;
  let o = hits[0].object;
  while (o && !o.userData.rec) o = o.parent;
  return o ? o.userData.rec : null;
}

function select(rec) {
  if (boxHelper) { roomGroup.remove(boxHelper); boxHelper.geometry.dispose(); boxHelper = null; }
  selected = rec;
  if (rec) {
    boxHelper = new THREE.BoxHelper(rec.obj, 0x4f8cff);
    roomGroup.add(boxHelper);
    document.getElementById('sel').classList.add('show');
  } else {
    document.getElementById('sel').classList.remove('show');
  }
}

renderer.domElement.addEventListener('pointerdown', (ev) => {
  downPos = { x: ev.clientX, y: ev.clientY };
  dragging = false;
  if (!editMode) return;
  const rec = pick(ev);
  if (rec) {
    select(rec);
    controls.enabled = false;
    dragging = true;
  }
});

renderer.domElement.addEventListener('pointermove', (ev) => {
  if (!dragging || !selected) return;
  const rect = renderer.domElement.getBoundingClientRect();
  ptr.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
  ptr.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
  ray.setFromCamera(ptr, camera);
  if (ray.ray.intersectPlane(plane, hitPoint)) {
    selected.obj.position.x = snap(clamp(hitPoint.x, -ROOM_W / 2 + 0.3, ROOM_W / 2 - 0.3));
    selected.obj.position.z = snap(clamp(hitPoint.z, -ROOM_D / 2 + 0.3, ROOM_D / 2 - 0.3));
    if (boxHelper) boxHelper.update();
  }
});

renderer.domElement.addEventListener('pointerup', (ev) => {
  controls.enabled = true;
  const moved = downPos ? Math.hypot(ev.clientX - downPos.x, ev.clientY - downPos.y) : 99;
  if (editMode && dragging) { dragging = false; return; }
  if (moved < 8) {
    const rec = pick(ev);
    select(editMode ? rec : null);
  }
});

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function snap(v) { return Math.round(v / SNAP) * SNAP; }

window.addEventListener('keydown', (e) => {
  if (!selected) return;
  if (e.key === 'r' || e.key === 'R') rotateSel();
  if (e.key === 'Delete' || e.key === 'Backspace') delSel();
  if (e.key === 'Escape') select(null);
});

function rotateSel() {
  if (!selected) return;
  selected.obj.rotation.y += Math.PI / 4;
  if (boxHelper) boxHelper.update();
}
function scaleSel() {
  if (!selected) return;
  const s = selected.obj.scale.x >= 1.8 ? 0.75 : selected.obj.scale.x + 0.15;
  selected.obj.scale.setScalar(s);
  if (boxHelper) boxHelper.update();
}
function delSel() {
  if (!selected) return;
  roomGroup.remove(selected.obj);
  items = items.filter((r) => r !== selected);
  select(null);
}

/* ---------------- 编辑 UI ---------------- */
function setEdit(on) {
  editMode = on;
  document.getElementById('palette').classList.toggle('show', on);
  document.getElementById('btnEdit').classList.toggle('on', on);
  document.getElementById('btnEdit').textContent = on ? '✅ 完成' : '✏️ 装修';
  document.getElementById('btnSave').style.display = on ? '' : 'none';
  if (!on) select(null);
  if (avatarApi) avatarApi.setVisible(true);
  setHint(on
    ? '装修中：点下面分类选家具 → 拖到想要的位置；选中后可以旋转/放大/删除'
    : '拖动旋转视角，滚轮/双指缩放；点右上角「装修」可以布置房间');
}

function syncEditUI() { setEdit(editMode); }

function buildPalette() {
  const cats = document.getElementById('palCats');
  const itemsBox = document.getElementById('palItems');
  const names = Object.keys(CATS);
  cats.innerHTML = '';
  names.forEach((n, i) => {
    const b = document.createElement('div');
    b.className = 'cat' + (i === 0 ? ' on' : '');
    b.textContent = n;
    b.onclick = () => {
      cats.querySelectorAll('.cat').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      renderItems(n, itemsBox);
    };
    cats.appendChild(b);
  });
  renderItems(names[0], itemsBox);
}

function renderItems(cat, box) {
  box.innerHTML = '';
  CATS[cat].forEach((name) => {
    const d = document.createElement('div');
    d.className = 'it';
    d.textContent = prettyName(name);
    d.onclick = async () => {
      try {
        const rec = await addItem({ m: name, x: snap(rand(-1.2, 1.2)), z: snap(rand(0.2, 1.6)), r: 0 }, true);
        select(rec);
        setHint(`已放入「${prettyName(name)}」，拖动它摆位置`);
      } catch (e) { setHint('这个模型加载失败了：' + name); }
    };
    box.appendChild(d);
  });
}
function rand(a, b) { return a + Math.random() * (b - a); }
function prettyName(n) {
  const map = {
    bedDouble: '双人床', bedSingle: '单人床', bedBunk: '上下铺', loungeSofa: '沙发', loungeSofaLong: '长沙发',
    loungeSofaCorner: '转角沙发', loungeChair: '单椅', loungeChairRelax: '躺椅', bench: '长凳',
    desk: '书桌', deskCorner: '转角桌', table: '桌子', tableCoffee: '茶几', tableCoffeeGlass: '玻璃茶几',
    tableRound: '圆桌', chair: '椅子', chairDesk: '电脑椅', chairRounded: '圆椅', stoolBar: '吧凳',
    sideTable: '边几', sideTableDrawers: '带抽屉边几',
    computerScreen: '显示器', computerKeyboard: '键盘', computerMouse: '鼠标', laptop: '笔记本',
    televisionModern: '电视', televisionVintage: '老电视', speaker: '音箱', speakerSmall: '小音箱',
    radio: '收音机', kitchenMicrowave: '微波炉', kitchenFridge: '冰箱',
    lampRoundFloor: '落地灯', lampRoundTable: '台灯', lampSquareFloor: '方落地灯', lampSquareTable: '方台灯',
    lampSquareCeiling: '吸顶灯', lampWall: '壁灯', ceilingFan: '吊扇',
    plantSmall1: '绿植 1', plantSmall2: '绿植 2', plantSmall3: '绿植 3', pottedPlant: '盆栽',
    rugRectangle: '长方地毯', rugRound: '圆地毯', rugRounded: '椭圆地毯', rugSquare: '方地毯', rugDoormat: '门垫',
    bookcaseOpen: '书架', bookcaseOpenLow: '矮书架', bookcaseClosed: '书柜', bookcaseClosedWide: '宽书柜',
    books: '一摞书', cardboardBoxClosed: '纸箱', cardboardBoxOpen: '开口纸箱', trashcan: '垃圾桶',
    pillow: '枕头', pillowBlue: '蓝枕头', bear: '玩偶熊', coatRack: '衣架', coatRackStanding: '立式衣架',
    kitchenSink: '水槽', kitchenStove: '灶台', kitchenCabinet: '橱柜', kitchenBar: '吧台',
    bathroomSink: '洗手池', bathtub: '浴缸', toilet: '马桶', washer: '洗衣机', doorwayOpen: '门洞',
  };
  return map[n] || n;
}

/* ---------------- 顶栏 / 提示 ---------------- */
function buildTabs() {
  const box = document.getElementById('tabs');
  box.innerHTML = '';
  Object.entries(ROOMS).forEach(([id, cfg]) => {
    const b = document.createElement('div');
    b.className = 'tab' + (id === current ? ' on' : '');
    b.dataset.id = id;
    b.textContent = cfg.name;
    b.onclick = () => openRoom(id);
    box.appendChild(b);
  });
}

let hintTimer = null;
function setHint(t) {
  const el = document.getElementById('hint');
  el.innerHTML = t;
  el.style.opacity = '1';
  clearTimeout(hintTimer);
  hintTimer = setTimeout(() => { el.style.opacity = '0.55'; }, 4200);
}

/* ---------------- 启动 ---------------- */
buildTabs();
buildPalette();

document.getElementById('btnEdit').onclick = () => setEdit(!editMode);
document.getElementById('btnSave').onclick = () => { save(); };
document.getElementById('btnRot').onclick = rotateSel;
document.getElementById('btnScale').onclick = scaleSel;
document.getElementById('btnDel').onclick = delSel;

// 从 URL 选房间：room3d.html?r=jiu / ?house=1（把四间房合成一个大屋）
const HOUSE_MODE = new URLSearchParams(location.search).has('house');
const qr = new URLSearchParams(location.search).get('r');
if (HOUSE_MODE) {
  camera.position.set(9.8, 10.4, 14.6);
  controls.target.set(0, 0.7, 0);
  controls.minDistance = 6;
  controls.maxDistance = 30;
  controls.update();
  startHouse().catch((e) => setHint('加载失败：' + e.message));
} else openRoom(ROOMS[qr] ? qr : 'shiqi').catch((e) => setHint('加载失败：' + e.message));

/* FPS */
let frames = 0, last = performance.now();
const fpsEl = document.getElementById('fps');
function tick() {
  requestAnimationFrame(tick);
  const dt = Math.min(0.05, (performance.now() - (tick._prev || performance.now())) / 1000);
  tick._prev = performance.now();
  controls.update();
  updateAvatar(dt);
  if (boxHelper && selected) boxHelper.update();
  renderer.render(scene, camera);
  frames++;
  const now = performance.now();
  if (now - last >= 1000) {
    fpsEl.textContent = frames;
    frames = 0; last = now;
  }
}
tick();

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// 若从聊天页带 token 过来（将来接 /api/room），先留在 localStorage
const tok = new URLSearchParams(location.search).get('t');
if (tok) localStorage.setItem('room_token', tok);

document.getElementById('who').innerHTML = '小家 3D · PC 版　<b>访客不开放</b>';

/* ---------------- 调试探针（给自动化验收用；不影响用户） ---------------- */
window.__room3dErrors = [];
window.addEventListener('error', (e) => window.__room3dErrors.push(String(e.message)));
window.addEventListener('unhandledrejection', (e) => window.__room3dErrors.push('reject: ' + String(e.reason)));

window.__room3d = {
  get room() { return current; },
  get items() { return items.length; },
  get names() { return items.map((r) => r.name); },
  get groupChildren() { return roomGroup.children.length; },
  get errors() { return window.__room3dErrors.slice(0, 12); },
  get cam() { return camera; },
  get ctrl() { return controls; },
  get avatar() {
    if (!avatarApi) return null;
    const box = new THREE.Box3().setFromObject(avatarApi.group);
    const size = new THREE.Vector3(); box.getSize(size);
    let meshes = 0;
    avatarApi.group.traverse((o) => { if (o.isMesh) meshes++; });
    return {
      meshes,
      h: +size.y.toFixed(2), w: +size.x.toFixed(2), d: +size.z.toFixed(2),
      pos: avatarApi.group.position.toArray().map((v) => +v.toFixed(2)),
      eyes: avatarApi.parts.eyesG ? avatarApi.parts.eyesG.children.length : 0,
    };
  },
  get gl() {
    const c = renderer.domElement;
    return { w: c.width, h: c.height, ctx: !!renderer.getContext(), dataLen: c.toDataURL('image/png').length };
  },
  pixelStats() {
    const c = renderer.domElement;
    const cv = document.createElement('canvas');
    cv.width = 160; cv.height = 100;
    const cx = cv.getContext('2d');
    cx.drawImage(c, 0, 0, cv.width, cv.height);
    const d = cx.getImageData(0, 0, cv.width, cv.height).data;
    let sum = 0, sum2 = 0;
    const seen = new Set();
    for (let i = 0; i < d.length; i += 4) {
      const v = (d[i] + d[i + 1] + d[i + 2]) / 3;
      sum += v; sum2 += v * v;
      seen.add((d[i] >> 3) + ',' + (d[i + 1] >> 3) + ',' + (d[i + 2] >> 3));
    }
    const n = d.length / 4;
    const mean = sum / n;
    return { mean: +mean.toFixed(1), std: +Math.sqrt(Math.max(0, sum2 / n - mean * mean)).toFixed(1), colors: seen.size };
  },
  openRoom, setEdit, save, addItem,
};

/* ================= 合并大屋模式（?house=1） ================= */
const ZONES = {
  shiqi: { x: -3.6, z: -3.1, label: '大姐 · 蓝鲸房', tint: '#4f8cff' },
  jiu:   { x:  3.6, z: -3.1, label: '二姐 · 网吧房',   tint: '#9b6dff' },
  hutao: { x: -3.6, z:  3.1, label: '三姐 · 小窝',   tint: '#ff9d4d' },
  living:{ x:  3.6, z:  3.1, label: '客厅',          tint: '#7fd0a8' },
};
const HOUSE_W = 14.4, HOUSE_D = 12.4, HOUSE_H = 2.9;
let houseFloor = null, engine = null;

function labelSprite(text, color) {
  const S = 512, H = 96;
  const cv = document.createElement('canvas');
  cv.width = S; cv.height = H;
  const c = cv.getContext('2d');
  c.fillStyle = 'rgba(10,16,26,0.72)';
  c.beginPath(); c.roundRect(6, 8, S - 12, H - 16, 22); c.fill();
  c.strokeStyle = color; c.lineWidth = 3; c.stroke();
  c.font = 'bold 44px "Microsoft YaHei", sans-serif';
  c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillStyle = '#e9f1ff';
  c.fillText(text, S / 2, H / 2 + 2);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  sp.scale.set(2.6, 0.49, 1);
  return sp;
}

async function fetchRoomItems(id) {
  try {
    const _tok = localStorage.getItem('room_token') || '';
    const r = await fetch('/api/room/' + id, { credentials: 'same-origin', headers: _tok ? { authorization: 'Bearer ' + _tok } : {} });
    if (r.ok) {
      const j = await r.json();
      if (j && Array.isArray(j.items) && j.items.length) return j.items;
    }
  } catch (e) {}
  const saved = loadSaved(id);
  if (saved && Array.isArray(saved.items) && saved.items.length) return saved.items;
  return ROOMS[id].items;
}

let ceilingMesh = null;
function buildHouseShell() {
  roomGroup.clear();
  roomGroup.add(new THREE.Group());

  const wallMat = new THREE.MeshLambertMaterial({ color: '#40527a' });
  const trimMat = new THREE.MeshLambertMaterial({ color: '#5f7699' });
  const frameMat = new THREE.MeshLambertMaterial({ color: '#8a7355' });
  const t = 0.14;
  const DOOR = 1.30, DOOR_H = 2.15;
  const box = (w, h, d, x, y, z, mat) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat || wallMat);
    m.position.set(x, y, z);
    roomGroup.add(m);
    return m;
  };

  // ---- 地板 + 分区地面 + 分区边线 ----
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(HOUSE_W, HOUSE_D), new THREE.MeshLambertMaterial({ color: '#7a6248' }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = 0.002; roomGroup.add(floor);

  const edgeMat = new THREE.MeshLambertMaterial({ color: '#2a2118' });
  Object.entries(ZONES).forEach(([id, z]) => {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(7.0, 6.0), new THREE.MeshLambertMaterial({ color: new THREE.Color(ROOMS[id].floor).multiplyScalar(1.35) }));
    p.rotation.x = -Math.PI / 2; p.position.set(z.x, 0.006, z.z); roomGroup.add(p);
    // 地面分区边线（细条，强化房间分界）
    const strip = (w, d, x, zz) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), edgeMat); m.rotation.x = -Math.PI / 2; m.position.set(x, 0.009, zz); roomGroup.add(m); };
    strip(7.0, 0.05, z.x, z.z - 2.99); strip(7.0, 0.05, z.x, z.z + 2.99);
    strip(0.05, 6.0, z.x - 3.49, z.z); strip(0.05, 6.0, z.x + 3.49, z.z);
  });

  // ---- 外墙 ----
  box(HOUSE_W + t * 2, HOUSE_H, t, 0, HOUSE_H / 2, -HOUSE_D / 2 - t / 2);
  box(t, HOUSE_H, HOUSE_D + t * 2, -HOUSE_W / 2 - t / 2, HOUSE_H / 2, 0);
  box(t, HOUSE_H, HOUSE_D + t * 2, HOUSE_W / 2 + t / 2, HOUSE_H / 2, 0);
  const FDOOR = 1.8;
  const fxLen = (HOUSE_W - FDOOR) / 2;
  box(fxLen, HOUSE_H, t, -(FDOOR / 2 + fxLen / 2), HOUSE_H / 2, HOUSE_D / 2 + t / 2);
  box(fxLen, HOUSE_H, t, FDOOR / 2 + fxLen / 2, HOUSE_H / 2, HOUSE_D / 2 + t / 2);
  box(FDOOR, HOUSE_H - 2.15, t, 0, 2.15 + (HOUSE_H - 2.15) / 2, HOUSE_D / 2 + t / 2);
  // 大门门框
  box(0.1, 2.15, 0.24, -FDOOR / 2, 1.075, HOUSE_D / 2 + t / 2, frameMat);
  box(0.1, 2.15, 0.24, FDOOR / 2, 1.075, HOUSE_D / 2 + t / 2, frameMat);
  box(FDOOR + 0.1, 0.1, 0.24, 0, 2.2, HOUSE_D / 2 + t / 2, frameMat);

  // ---- 内墙（全高 + 门洞 + 门楣 + 门框 + 门槛）----
  const zLen = (HOUSE_D - DOOR) / 2;
  box(t, HOUSE_H, zLen, 0, HOUSE_H / 2, -(DOOR / 2 + zLen / 2));
  box(t, HOUSE_H, zLen, 0, HOUSE_H / 2, (DOOR / 2 + zLen / 2));
  box(t, HOUSE_H - DOOR_H, DOOR, 0, DOOR_H + (HOUSE_H - DOOR_H) / 2, 0);
  const xLen = (HOUSE_W - DOOR) / 2;
  box(xLen, HOUSE_H, t, -(DOOR / 2 + xLen / 2), HOUSE_H / 2, 0);
  box(xLen, HOUSE_H, t, (DOOR / 2 + xLen / 2), HOUSE_H / 2, 0);
  box(DOOR, HOUSE_H - DOOR_H, t, 0, DOOR_H + (HOUSE_H - DOOR_H) / 2, 0);
  // x=0 墙上的门框（开口沿 z）
  box(0.22, DOOR_H, 0.10, 0, DOOR_H / 2, -DOOR / 2, frameMat);
  box(0.22, DOOR_H, 0.10, 0, DOOR_H / 2, DOOR / 2, frameMat);
  box(0.22, 0.10, DOOR + 0.2, 0, DOOR_H, 0, frameMat);
  // z=0 墙上的门框（开口沿 x）
  box(0.10, DOOR_H, 0.22, -DOOR / 2, DOOR_H / 2, 0, frameMat);
  box(0.10, DOOR_H, 0.22, DOOR / 2, DOOR_H / 2, 0, frameMat);
  box(DOOR + 0.2, 0.10, 0.22, 0, DOOR_H, 0, frameMat);
  // 门槛石
  box(0.34, 0.03, DOOR, 0, 0.016, 0, trimMat);
  box(DOOR, 0.03, 0.34, 0, 0.016, 0, trimMat);

  // ---- 顶角线（让墙看起来封到顶）----
  const crownH = 0.08, crownT = 0.07;
  box(HOUSE_W, crownH, crownT, 0, HOUSE_H - crownH / 2, -HOUSE_D / 2 + crownT / 2, trimMat);
  box(HOUSE_W, crownH, crownT, 0, HOUSE_H - crownH / 2, HOUSE_D / 2 - crownT / 2, trimMat);
  box(crownT, crownH, HOUSE_D, -HOUSE_W / 2 + crownT / 2, HOUSE_H - crownH / 2, 0, trimMat);
  box(crownT, crownH, HOUSE_D, HOUSE_W / 2 - crownT / 2, HOUSE_H - crownH / 2, 0, trimMat);
  box(crownT, crownH, zLen, -crownT / 2, HOUSE_H - crownH / 2, -(DOOR / 2 + zLen / 2), trimMat);
  box(crownT, crownH, zLen, -crownT / 2, HOUSE_H - crownH / 2, (DOOR / 2 + zLen / 2), trimMat);
  box(crownT, crownH, zLen, crownT / 2, HOUSE_H - crownH / 2, -(DOOR / 2 + zLen / 2), trimMat);
  box(crownT, crownH, zLen, crownT / 2, HOUSE_H - crownH / 2, (DOOR / 2 + zLen / 2), trimMat);
  box(xLen, crownH, crownT, -(DOOR / 2 + xLen / 2), HOUSE_H - crownH / 2, -crownT / 2, trimMat);
  box(xLen, crownH, crownT, (DOOR / 2 + xLen / 2), HOUSE_H - crownH / 2, -crownT / 2, trimMat);
  box(xLen, crownH, crownT, -(DOOR / 2 + xLen / 2), HOUSE_H - crownH / 2, crownT / 2, trimMat);
  box(xLen, crownH, crownT, (DOOR / 2 + xLen / 2), HOUSE_H - crownH / 2, crownT / 2, trimMat);

  // ---- 踢脚线（沿外墙内侧 + 内墙两侧）----
  const bbH = 0.10, bbT = 0.05;
  box(HOUSE_W, bbH, bbT, 0, bbH / 2, -HOUSE_D / 2 + bbT / 2, trimMat);
  box(bbT, bbH, HOUSE_D, -HOUSE_W / 2 + bbT / 2, bbH / 2, 0, trimMat);
  box(bbT, bbH, HOUSE_D, HOUSE_W / 2 - bbT / 2, bbH / 2, 0, trimMat);
  box(HOUSE_W, bbH, bbT, 0, bbH / 2, HOUSE_D / 2 - bbT / 2, trimMat);
  box(bbT, bbH, zLen, -bbT / 2, bbH / 2, -(DOOR / 2 + zLen / 2), trimMat);
  box(bbT, bbH, zLen, -bbT / 2, bbH / 2, (DOOR / 2 + zLen / 2), trimMat);
  box(bbT, bbH, zLen, bbT / 2, bbH / 2, -(DOOR / 2 + zLen / 2), trimMat);
  box(bbT, bbH, zLen, bbT / 2, bbH / 2, (DOOR / 2 + zLen / 2), trimMat);
  box(xLen, bbH, bbT, -(DOOR / 2 + xLen / 2), bbH / 2, -bbT / 2, trimMat);
  box(xLen, bbH, bbT, (DOOR / 2 + xLen / 2), bbH / 2, -bbT / 2, trimMat);
  box(xLen, bbH, bbT, -(DOOR / 2 + xLen / 2), bbH / 2, bbT / 2, trimMat);
  box(xLen, bbH, bbT, (DOOR / 2 + xLen / 2), bbH / 2, bbT / 2, trimMat);

  // ---- 墙面装饰：挂画（靠 x=0 内墙两侧看得到）+ 壁灯 ----
  const artCols = { shiqi: '#7ea8ff', jiu: '#b48cff', hutao: '#ffab66', living: '#8fdcae' };
  Object.entries(ZONES).forEach(([id, z], i) => {
    const toward = z.x < 0 ? 1 : -1;          // 画挂在外墙上、朝向房内
    const wx = z.x < 0 ? -HOUSE_W / 2 + 0.08 : HOUSE_W / 2 - 0.08;
    const art = new THREE.Mesh(new THREE.PlaneGeometry(0.92, 0.62), new THREE.MeshLambertMaterial({ color: artCols[id] || '#9cc0ff' }));
    art.position.set(wx, 1.72, z.z - 0.6);
    art.rotation.y = toward * Math.PI / 2;
    roomGroup.add(art);
    const fr = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.74, 1.04), frameMat);
    fr.position.set(wx + (z.x < 0 ? -0.01 : 0.01), 1.72, z.z - 0.6);
    roomGroup.add(fr);
    // 壁灯（外墙 z 侧）
    const wz = z.z < 0 ? -HOUSE_D / 2 + 0.09 : HOUSE_D / 2 - 0.09;
    const lampBase = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.16, 0.05), trimMat);
    lampBase.position.set(z.x + 1.6, 2.0, wz);
    roomGroup.add(lampBase);
    const lampGlow = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 10), new THREE.MeshBasicMaterial({ color: '#ffd9a0' }));
    lampGlow.position.set(z.x + 1.6, 1.98, wz + (z.z < 0 ? 0.08 : -0.08));
    roomGroup.add(lampGlow);
    const sconceLight = new THREE.PointLight(0xffd9a0, 1.7, 4.2, 2);
    sconceLight.position.set(z.x + 1.6, 1.94, wz + (z.z < 0 ? 0.22 : -0.22));
    roomGroup.add(sconceLight);
  });

  // ---- 门扇（半开，真人住宅感）----
  const leafMat = new THREE.MeshLambertMaterial({ color: '#7d6a4f' });
  function doorLeaf(w, h, open) {
    const g = new THREE.Group();
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.04), leafMat);
    leaf.position.set(w / 2, 0, 0);
    g.add(leaf);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), new THREE.MeshLambertMaterial({ color: '#d9c27a' }));
    knob.position.set(w * 0.86, 0, 0.05);
    g.add(knob);
    g.rotation.y = open;
    return g;
  }
  const lx = doorLeaf(DOOR * 0.94, DOOR_H - 0.06, -Math.PI * 0.42);
  lx.position.set(-0.07, 0.03, -DOOR / 2);
  roomGroup.add(lx);
  const lz = doorLeaf(DOOR * 0.94, DOOR_H - 0.06, Math.PI * 0.42);
  lz.position.set(-DOOR / 2, 0.03, -0.07);
  roomGroup.add(lz);

  // ---- 窗户（外墙上，带窗框、玻璃和窗帘）----
  const glassMat = new THREE.MeshBasicMaterial({ color: '#a8c8ee', transparent: true, opacity: 0.55 });
  const curtMat = new THREE.MeshLambertMaterial({ color: '#2f4a72' });
  function windowAt(x, y, z, rotY) {
    const g = new THREE.Group();
    const frame = 0.06;
    g.add(new THREE.Mesh(new THREE.BoxGeometry(1.28, 1.06, 0.05), frameMat));
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(1.12, 0.9), glassMat);
    glass.position.z = 0.035;
    g.add(glass);
    const sill = new THREE.Mesh(new THREE.BoxGeometry(1.34, 0.06, 0.16), trimMat);
    sill.position.set(0, -0.56, 0.06);
    g.add(sill);
    const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.34, 1.02, 0.03), curtMat);
    c1.position.set(-0.56, 0, 0.06);
    g.add(c1);
    const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.34, 1.02, 0.03), curtMat);
    c2.position.set(0.56, 0, 0.06);
    g.add(c2);
    const mid = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.9, 0.045), frameMat);
    mid.position.z = 0.03;
    g.add(mid);
    const lint = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.05, 0.14), trimMat);
    lint.position.set(0, 0.6, 0.06);
    g.add(lint);
    g.position.set(x, y, z);
    g.rotation.y = rotY || 0;
    roomGroup.add(g);
  }
  windowAt(-3.6, 1.55, -HOUSE_D / 2 + 0.09, 0);
  windowAt(3.6, 1.55, -HOUSE_D / 2 + 0.09, 0);
  windowAt(-HOUSE_W / 2 + 0.09, 1.55, -3.1, Math.PI / 2);
  windowAt(HOUSE_W / 2 - 0.09, 1.55, 3.1, -Math.PI / 2);

  // ---- 房间地毯（强化分区）----
  const rugCols = { shiqi: '#3d63a3', jiu: '#6a3f92', hutao: '#8d5c33', living: '#3c7a63' };
  Object.entries(ZONES).forEach(([id, z]) => {
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 3.4), new THREE.MeshLambertMaterial({ color: rugCols[id] || '#333f52' }));
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(z.x, 0.012, z.z + 0.2);
    roomGroup.add(rug);
    const edge = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 3.6), new THREE.MeshLambertMaterial({ color: '#1d2433' }));
    edge.rotation.x = -Math.PI / 2;
    edge.position.set(z.x, 0.010, z.z + 0.2);
    roomGroup.add(edge);
  });

  // ---- 吊灯（每间一个）+ 吸顶底盘 ----
  Object.entries(ZONES).forEach(([id, z]) => {
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.42, 6), trimMat);
    rod.position.set(z.x, HOUSE_H - 0.21, z.z);
    roomGroup.add(rod);
    const shade = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), new THREE.MeshLambertMaterial({ color: '#e8eefc', side: THREE.DoubleSide }));
    shade.position.set(z.x, HOUSE_H - 0.42, z.z);
    roomGroup.add(shade);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 10), new THREE.MeshBasicMaterial({ color: '#fff1cf' }));
    bulb.position.set(z.x, HOUSE_H - 0.50, z.z);
    roomGroup.add(bulb);
  });

  // ---- 分区标签 + 柔光 ----
  Object.entries(ZONES).forEach(([id, z]) => {
    const sp = labelSprite(z.label, z.tint);
    sp.position.set(z.x, 2.52, z.z - 2.6);
    roomGroup.add(sp);
    const pl = new THREE.PointLight(new THREE.Color(z.tint).getHex(), 2.6, 8, 2);
    pl.position.set(z.x, 2.15, z.z);
    roomGroup.add(pl);
  });

  // ---- 天花板（默认隐藏，按 C 或调 toggleCeiling 显示）----
  const ceil = new THREE.Mesh(
    new THREE.PlaneGeometry(HOUSE_W + 0.5, HOUSE_D + 0.5),
    new THREE.MeshLambertMaterial({ color: '#33405c', side: THREE.DoubleSide })
  );
  ceil.rotation.x = Math.PI / 2;
  ceil.position.set(0, HOUSE_H + 0.03, 0);
  ceil.receiveShadow = true;
  ceil.visible = false;
  ceil.name = 'ceiling';
  roomGroup.add(ceil);
  ceilingMesh = ceil;
}

let fly = null;
function flyTo(id) {
  const z = ZONES[id];
  if (!z) return;
  const to = new THREE.Vector3(z.x, 0.95, z.z);
  const from = controls.target.clone();
  const camTo = new THREE.Vector3(z.x + 0.9, 4.15, z.z + 5.6);
  const camFrom = camera.position.clone();
  fly = { t0: performance.now(), dur: 620, from, to, camFrom, camTo };
}
function setCam(px, py, pz, tx, ty, tz) {
  fly = null;
  camera.position.set(px, py, pz);
  controls.target.set(tx, ty, tz);
  controls.update();
}

function stepFly() {
  if (!fly) return;
  const k = Math.min(1, (performance.now() - fly.t0) / fly.dur);
  const e = 1 - Math.pow(1 - k, 3);
  controls.target.lerpVectors(fly.from, fly.to, e);
  camera.position.lerpVectors(fly.camFrom, fly.camTo, e);
  if (k >= 1) fly = null;
}

function buildHouseTabs() {
  const box = document.getElementById('tabs');
  box.innerHTML = '';
  const overview = document.createElement('div');
  overview.className = 'tab on';
  overview.textContent = '整栋';
  overview.onclick = () => {
    document.querySelectorAll('#tabs .tab').forEach((t) => t.classList.toggle('on', t === overview));
    fly = { t0: performance.now(), dur: 700, from: controls.target.clone(), to: new THREE.Vector3(0, 0.8, 0), camFrom: camera.position.clone(), camTo: new THREE.Vector3(0, 12.5, 15.2) };
  };
  box.appendChild(overview);
  Object.entries(ZONES).forEach(([id, z]) => {
    const b = document.createElement('div');
    b.className = 'tab';
    b.textContent = z.label;
    b.onclick = () => {
      document.querySelectorAll('#tabs .tab').forEach((t) => t.classList.toggle('on', t === b));
      flyTo(id);
    };
    box.appendChild(b);
  });
  const edit = document.createElement('div');
  edit.className = 'tab';
  edit.textContent = '去单间装修 ↗';
  edit.onclick = () => { location.href = './room3d.html?r=' + (current || 'shiqi'); };
  box.appendChild(edit);
}

// v21：软接触阴影（贴地暗斑），消除"家具/小人悬空"的观感
const _shadowTex = (() => {
  const cv = document.createElement('canvas');
  cv.width = cv.height = 128;
  const c = cv.getContext('2d');
  const g = c.createRadialGradient(64, 64, 4, 64, 64, 62);
  g.addColorStop(0, 'rgba(0,0,0,0.46)');
  g.addColorStop(0.55, 'rgba(0,0,0,0.22)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = g;
  c.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(cv);
  t.needsUpdate = true;
  return t;
})();
function softShadow(x, z, r, parent) {
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(r * 2, r * 2),
    new THREE.MeshBasicMaterial({ map: _shadowTex, transparent: true, depthWrite: false, opacity: 1 })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.set(x, 0.02, z);
  m.renderOrder = 2;
  (parent || roomGroup).add(m);
  return m;
}

function fitItem(rec) {
  try {
    const box = new THREE.Box3().setFromObject(rec.obj);
    const minY = box.min.y;
    const h = box.max.y - box.min.y;
    if (isFinite(minY) && minY > 0.035) rec.obj.position.y -= minY;
    const maxH = 1.9;
    if (isFinite(h) && h > maxH) {
      const k = maxH / h;
      rec.obj.scale.multiplyScalar(k);
      const b2 = new THREE.Box3().setFromObject(rec.obj);
      if (b2.min.y > 0.035) rec.obj.position.y -= b2.min.y;
    }
  } catch (e) {}
}

async function startHouse() {
  // 等单间初始化跑完再清场
  await new Promise((r) => setTimeout(r, 350));
  clearItems();
  if (avatarApi) { roomGroup.remove(avatarApi.group); avatarApi = null; }
  buildHouseShell();

  for (const id of Object.keys(ZONES)) {
    const list = await fetchRoomItems(id);
    const z = ZONES[id];
    for (const it of list) {
      try {
        const wx = (it.x ?? 0) + z.x, wz = (it.z ?? 0) + z.z;
        const _rec = await addItem({ ...it, x: wx, z: wz });
        fitItem(_rec);
        softShadow(wx, wz, 0.46 * (it.s || 1));
      } catch (e) { console.warn('item fail', it.m); }
    }
  }

  // 三个小人各自在自己房间
  houseAvatars.length = 0;
  for (const [id, z] of Object.entries(ZONES)) {
    if (id === 'living') continue;
    try {
      const spec = AVATAR_SPECS[id] || AVATAR_SPECS.shiqi;
      const api = buildChibi(spec);
      api.group.position.set(z.x + 0.9, 0, z.z + 1.05);
      api.group.rotation.y = -0.4;
      api.group.scale.setScalar(0.62);
      roomGroup.add(api.group);
      softShadow(z.x + 0.9, z.z + 1.05, 0.55);
      houseAvatars.push(api);
    } catch (e) { console.warn('avatar fail', id, e.message); }
  }

  roomGroup.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  const _ceilPref = (function () { try { return localStorage.getItem('house_ceiling') === '1'; } catch (e) { return false; } })();
  if (ceilingMesh) ceilingMesh.visible = _ceilPref;
  camera.position.set(0, 12.5, 15.2);
  controls.target.set(0, 0.8, 0);
  controls.minDistance = 4.5;
  controls.maxDistance = 30;
  controls.enablePan = true;
  buildHouseTabs();
  document.getElementById('who').innerHTML = '三姐妹合租小屋 · PC 版　<b>四间房合并在一起</b>';
  const oldTick = setInterval(() => {}, 1e9); clearInterval(oldTick);
  const loop = () => { stepFly(); requestAnimationFrame(loop); };
  loop();
  setHint('大屋已合并：三间卧室 + 客厅，点顶栏可以飞过去；装修请点「去单间装修」');
  window.__house = { zones: ZONES, items, avatars: houseAvatars, flyTo, openRoom, setEdit, setCam, camera, controls, renderer, scene,
    get ceiling() { return ceilingMesh; },
    setCeiling(v) { if (!ceilingMesh) return null; ceilingMesh.visible = !!v; try { localStorage.setItem('house_ceiling', v ? '1' : '0'); } catch (e) {} return ceilingMesh.visible; } };
  addEventListener('keydown', (e) => {
    if ((e.key === 'c' || e.key === 'C') && ceilingMesh) {
      const v = !ceilingMesh.visible;
      ceilingMesh.visible = v;
      try { localStorage.setItem('house_ceiling', v ? '1' : '0'); } catch (e) {}
      setHint(v ? '封顶：已盖上屋顶（内部会变暗）' : '封顶：已打开屋顶，方便看屋里');
    }
  });
}
