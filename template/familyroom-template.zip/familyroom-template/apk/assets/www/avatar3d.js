// 2.5D 柔光小人 · 「蓝毛小女仆」
// ------------------------------------------------------------------------------------
// 设计目标（对应家长的要求：细节更精细、整体偏 2.5D 渲染、不要小几何体拼出来的突兀感）
//
// 核心手法：「几个大件 + 一体成型 + 顶点色渐变 + 柔光材质」
//   1. 全身轮廓用 **Lathe 旋转体一体成型**（头到裙摆是一个连续剪影），不再是球/胶囊堆叠。
//   2. 部件之间靠 **顶点色** 过渡（深蓝头发→浅蓝发梢、白蕾丝→米色阴影），消除拼块感。
//   3. 材质用 **GradientMap 柔光 5 阶**（不到硬 2 阶），配合高光贴图与轮廓光，接近 2.5D 手绘上色。
//   4. 蕾丝/荷叶边用 **贴图 + 法线**，不是小球串。
//   5. 描边只在「大轮廓」外扩一层，且随镜头距离淡出，不再每个零件都描边。
//
// 用法：
//   import { buildAvatar, AVATAR_SPECS } from './avatar3d.js';
//   const a = buildAvatar(AVATAR_SPECS.shiqi);
//   scene.add(a.group); a.update(dt);

import * as THREE from 'three';
import { closedEyeTexture, blushTexture, mouthTexture, faceSprite } from './face2d.js';
import { buildRig } from './rig.js';
import { createToonMaterial, LIGHT_DIR , attachOutline } from './toon.js';

/* ================= 配色 ================= */
const PAL = {
  skin: 0xffe9dc,
  skinDeep: 0xf6cdba,
  hairDark: 0x27335f,
  hair: 0x37498a,
  hairMid: 0x5473bb,
  hairLight: 0x8db8e8,
  hairTip: 0xbde0fa,
  dress: 0x4b55a0,
  dressDeep: 0x2f3768,
  lace: 0xffffff,
  laceShade: 0xdfe4f2,
  gold: 0xe2bb6c,
  bow: 0x6ab8e8,
  whale: 0x4285cc,
  fin: 0x38477d,
  finLight: 0x9ecdf0,
};

/* ================= 柔光渐变贴图 ================= */
function makeGradient(steps) {
  const data = new Uint8Array(steps);
  const t = new THREE.DataTexture(data, data.length, 1, THREE.RedFormat);
  t.minFilter = THREE.LinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.needsUpdate = true;
  return t;
}
/** 主材质：3D→2D 赛璐璐（柔和色带 + 色相偏移 + 轮廓光），细节见 toon.js */
function matSoft(color, opts = {}) {
  return createToonMaterial({
    color,
    vertexColors: opts.vertexColors !== false,
    map: opts.map || null,
    side: opts.side || THREE.FrontSide,
    transparent: opts.transparent || false,
    depthWrite: opts.depthWrite !== false,
    bands: opts.bands ?? 3,
    softness: opts.softness ?? 0.24,
    rim: opts.rim ?? 0.85,
  });
}

/* ---------- 程序化贴图 ---------- */
/** 白蕾丝：白底 + 淡阴影的扇形齿边 + 点状孔 */
function laceTexture(repeatX = 8, scallop = 0.34) {
  const S = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  x.fillStyle = '#ffffff';
  x.fillRect(0, 0, S, S);

  // 阴影底（做出立体感，不靠几何）
  const g = x.createLinearGradient(0, S * (1 - scallop), 0, S);
  g.addColorStop(0, 'rgba(210,218,238,0.0)');
  g.addColorStop(1, 'rgba(196,206,232,0.85)');
  x.fillStyle = g;
  x.fillRect(0, S * (1 - scallop), S, S * scallop);

  // 扇贝齿边
  x.globalCompositeOperation = 'destination-out';
  const n = repeatX;
  const w = S / n;
  for (let i = 0; i < n; i++) {
    x.beginPath();
    x.arc(i * w + w / 2, S, w * 0.52, Math.PI, Math.PI * 2);
    x.fill();
  }
  x.globalCompositeOperation = 'source-over';

  // 点状孔洞
  x.fillStyle = 'rgba(206,214,236,0.55)';
  for (let r = 0; r < 4; r++) {
    for (let i = 0; i < n * 2; i++) {
      if ((i + r) % 3 === 0) continue;
      x.beginPath();
      x.arc((i + 0.5) * (S / (n * 2)), S * (0.12 + r * 0.2), 2.6, 0, Math.PI * 2);
      x.fill();
    }
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/** 荷叶边：竖向褶皱明暗（配合几何做柔和起伏） */
function pleatTexture(n = 14) {
  const S = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  for (let i = 0; i < n; i++) {
    const px = (i / n) * S;
    const g = x.createLinearGradient(px, 0, px + S / n, 0);
    g.addColorStop(0.0, 'rgba(255,255,255,1.00)');
    g.addColorStop(0.42, 'rgba(226,232,246,1.00)');
    g.addColorStop(0.58, 'rgba(206,214,236,0.95)');
    g.addColorStop(1.0, 'rgba(255,255,255,1.00)');
    x.fillStyle = g;
    x.fillRect(px, 0, S / n + 1, S);
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.repeat.set(1, 1);
  return t;
}

/** 女仆裙格纹（细网格） */
function plaidTexture() {
  const S = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  x.fillStyle = '#2b3057';
  x.fillRect(0, 0, S, S);
  x.strokeStyle = 'rgba(120,140,200,0.30)';
  x.lineWidth = 2;
  for (let i = 0; i <= 8; i++) {
    x.beginPath(); x.moveTo(i * S / 8, 0); x.lineTo(i * S / 8, S); x.stroke();
    x.beginPath(); x.moveTo(0, i * S / 8); x.lineTo(S, i * S / 8); x.stroke();
  }
  x.strokeStyle = 'rgba(190,210,245,0.22)';
  x.lineWidth = 1;
  for (let i = 0; i <= 16; i++) {
    x.beginPath(); x.moveTo(i * S / 16, 0); x.lineTo(i * S / 16, S); x.stroke();
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/** 鲸鱼图案（围裙） */
function whaleTexture() {
  const S = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  x.clearRect(0, 0, S, S);
  x.save();
  x.translate(S * 0.5, S * 0.56);
  x.scale(1.5, 1.5);
  x.translate(-S * 0.32, -S * 0.32);

  // 身体
  const grad = x.createLinearGradient(0, S * 0.3, 0, S * 0.7);
  grad.addColorStop(0, '#5b9fdc');
  grad.addColorStop(1, '#2f6db4');
  x.fillStyle = grad;
  x.beginPath();
  x.moveTo(S * 0.18, S * 0.55);
  x.bezierCurveTo(S * 0.2, S * 0.32, S * 0.52, S * 0.28, S * 0.66, S * 0.42);
  x.bezierCurveTo(S * 0.74, S * 0.5, S * 0.74, S * 0.66, S * 0.6, S * 0.74);
  x.bezierCurveTo(S * 0.42, S * 0.82, S * 0.2, S * 0.74, S * 0.18, S * 0.55);
  x.closePath();
  x.fill();

  // 尾巴
  x.beginPath();
  x.moveTo(S * 0.66, S * 0.44);
  x.quadraticCurveTo(S * 0.82, S * 0.3, S * 0.84, S * 0.5);
  x.quadraticCurveTo(S * 0.85, S * 0.66, S * 0.66, S * 0.6);
  x.closePath();
  x.fillStyle = '#3a7cc0';
  x.fill();

  // 腹部
  x.fillStyle = 'rgba(214,236,252,0.92)';
  x.beginPath();
  x.moveTo(S * 0.24, S * 0.62);
  x.bezierCurveTo(S * 0.36, S * 0.78, S * 0.56, S * 0.78, S * 0.68, S * 0.62);
  x.bezierCurveTo(S * 0.56, S * 0.7, S * 0.36, S * 0.7, S * 0.24, S * 0.62);
  x.closePath();
  x.fill();

  // 眼睛（微微闭）
  x.strokeStyle = '#132139';
  x.lineWidth = 4;
  x.lineCap = 'round';
  x.beginPath();
  x.arc(S * 0.36, S * 0.5, 7, 0.15 * Math.PI, 0.85 * Math.PI);
  x.stroke();

  // 喷水
  x.strokeStyle = 'rgba(146,196,235,0.95)';
  x.lineWidth = 7;
  x.beginPath(); x.moveTo(S * 0.44, S * 0.34); x.quadraticCurveTo(S * 0.41, S * 0.2, S * 0.33, S * 0.15); x.stroke();
  x.beginPath(); x.moveTo(S * 0.44, S * 0.34); x.quadraticCurveTo(S * 0.5, S * 0.19, S * 0.58, S * 0.13); x.stroke();
  x.restore();

  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.userData.canvas = cv;
  return t;
}

/* ================= 几何工具 ================= */

/** 把一面「顶点色函数」应用到几何上；fn(x,y,z,uv) → THREE.Color */
function paint(geo, fn) {
  const pos = geo.attributes.position;
  const col = new Float32Array(pos.count * 3);
  const uv = geo.attributes.uv;
  const c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    c.set(0xffffff);
    fn(c, x, y, z, uv ? { u: uv.getX(i), v: uv.getY(i) } : null);
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return geo;
}

/** 把世界坐标颜色映射进顶点色（用于发色渐变） */
function lerpColor(a, b, t) { return new THREE.Color(a).lerp(new THREE.Color(b), Math.max(0, Math.min(1, t))); }

/** Lathe：给一组 [半径, 高度] 剖面生成旋转体（一体成型的核心） */
function lathe(profile, segs = 48, curveSeg = 64) {
  // 重要：剖面点必须「从下往上」排列，否则 Lathe 的环绕方向反了 → 法线朝内 →
  // 正面被背面剔除，看进去是一团死黑（这是之前裙身发黑的真因）。
  let prof = profile;
  if (prof.length > 1 && prof[0][1] > prof[prof.length - 1][1]) prof = prof.slice().reverse();
  const pts = prof.map(([r, y]) => new THREE.Vector2(Math.max(0.0001, r), y));
  return new THREE.LatheGeometry(pts, segs, 0, Math.PI * 2);
}

/** 平滑的一体轮廓：用 CatmullRom 采样剖面点，让剪影圆润 */
function smoothProfile(key, samples = 26) {
  const curve = new THREE.SplineCurve(key.map(([r, y]) => new THREE.Vector2(r, y)));
  return curve.getSpacedPoints(samples).map((p) => [p.x, p.y]);
}

/** 球面高度贴花（把图案投到球面上，不变形） */
function sphericalDecal(tex, radius, phiLen, thetaStart, thetaLen) {
  const geo = new THREE.SphereGeometry(radius, 40, 32, phiLen / 2, phiLen, thetaStart, thetaLen);
  const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false }));
  return m;
}

/* ================= 头发：连续发片（不是球串） ================= */
function hairStrand(points, radiusKey, colorFn, segs = 24) {
  // points: [[x,y,z,radius], ...] → 用 CatmullRom 采样后做 Tube，再按高度上色
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(p[0], p[1], p[2])));
  const rad = new THREE.CatmullRomCurve3(points.map((p, i) => new THREE.Vector3(p[3], 0, 0)));
  const N = points.length;
  const samples = segs * (N - 1);
  const geo = new THREE.TubeGeometry(curve, samples, 0.02, 10, false);

  // Tube 的 uv.x 是沿长度方向
  const uv = geo.attributes.uv;
  paint(geo, (c, x, y, z, uvs) => {
    const t = uvs ? uvs.u : 0;
    const t2 = Math.pow(t, 0.85);
    colorFn(c, t2, y);
  });
  geo.computeVertexNormals();
  return geo;
}

/* ================= 主构建 ================= */
export function buildAvatar(spec = {}) {
  const {
    name = '大姐',
    hairDark = PAL.hairDark,
    hair = PAL.hair,
    hairMid = PAL.hairMid,
    hairLight = PAL.hairLight,
    hairTip = PAL.hairTip,
    dress = PAL.dress,
    accent = PAL.bow,
    finColor = PAL.fin,
    finLight = PAL.finLight,
    tagColor = '#dfe9ff',
    height = 1.0,
  } = spec;

  const root = new THREE.Group();
  const bounce = new THREE.Group();
  root.add(bounce);

  const HEAD_R = 0.235;
  const HEAD_Y = 0.79;

  /* ============ 1. 身体：一体成型的「伞形轮廓」 ============ */
  // 从脖子 → 肩 → 腰 → 裙摆 → 荷叶边，一条连续曲线（没有接头）
  const bodyProfile = smoothProfile([
    [0.000, 0.663],
    [0.048, 0.660],
    [0.080, 0.646],
    [0.100, 0.618],
    [0.113, 0.578],   // 肩头圆角
    [0.122, 0.532],
    [0.127, 0.487],   // 胸
    [0.124, 0.452],
    [0.116, 0.418],   // 腰（收）
    [0.129, 0.390],
    [0.156, 0.358],
    [0.188, 0.326],
    [0.214, 0.294],
    [0.230, 0.266],   // 裙摆外扩（圆润收尾）
    [0.238, 0.262],
    [0.236, 0.254]
  ], 48);

  const bodyGeo = lathe(bodyProfile, 56);
  {
    // 颜色：上身为裙色，胸口有格纹亮块，下摆渐深
    const white = new THREE.Color(PAL.lace);
    paint(bodyGeo, (c, x, y, z) => {
      const t = THREE.MathUtils.clamp((0.66 - y) / 0.42, 0, 1);
      c.copy(new THREE.Color(dress)).lerp(new THREE.Color(PAL.dressDeep), t * 0.55);
      // 正面胸前浅色块
      const front = z > 0.02 && y > 0.455 && y < 0.605;
      if (front) c.lerp(new THREE.Color(0x39406f), 0.55);
      // 下摆边缘略亮（受光）
      if (y < 0.268) c.lerp(white, 0.22);
      // 裙子布料竖向褶皱：用角度调制明暗（不靠几何，2D 上色思路）
      if (y < 0.335) {
        const a = Math.atan2(x, z);
        const depth = THREE.MathUtils.clamp((0.335 - y) / 0.10, 0, 1);
        const raw = Math.cos(a * 22) * 0.9 + Math.cos(a * 9 + 1.1) * 0.5;
        // 两阶卡通阴影：决不让它变成平滑渐变（那是 3D 味）
        const step = raw > 0.28 ? 1.16 : (raw < -0.28 ? 0.80 : 1.0);
        c.multiplyScalar(1 + (step - 1) * depth);
      }
    });
  }
  const body = new THREE.Mesh(bodyGeo, matSoft(0xffffff));
  bounce.add(body);

  /* ============ 2. 裙摆：荷叶边（法线起伏 + 贴图，不是圆球串） ============ */
  // 两层荷叶边：上沿被裙子盖住（白蕾丝），只有下沿露出波浪 —— 不能出现黑色尖牙
  const frillRows = 2;
  for (let row = 0; row < frillRows; row++) {
    const SEG = 192, HSEG = 14;
    const h = 0.072;
    const petals = 13;                     // 荷叶波浪数（大而柔）
    const thick = 0.016;                   // 布厚度（双层布料，正反都白）
    const pos = [], uv2 = [], idx = [];
    for (let r = 0; r <= HSEG; r++) {
      const k = r / HSEG;                  // 0 = 上沿(藏进裙子) 1 = 下沿(露出)
      const y = -k * h;
      // 半径：上沿贴着裙身，下沿外翻
      const rr = (0.252 + row * 0.006) + Math.pow(k, 1.30) * (0.056 + row * 0.020);
      for (let c = 0; c <= SEG; c++) {
        const u = c / SEG;
        const a = u * Math.PI * 2;
        // 荷叶波浪：下沿摆幅大，上沿几乎为 0（缝在裙子上）
        // 用平滑的余弦瓣做波浪（不要锯齿）：k^1.6 让上沿几乎不动、下沿充分起伏
        const pp = Math.pow(k, 1.6);
        const waveR = Math.cos(a * petals + row * 0.9) * (pp * 0.030);
        const waveY = Math.sin(a * petals + row * 0.9 + 0.6) * (pp * 0.016);
        const rad = rr + waveR;
        pos.push(Math.sin(a) * rad, y - waveY, Math.cos(a) * rad);
        uv2.push(u * 2.4, 1 - k);
      }
    }
    for (let r = 0; r < HSEG; r++) {
      for (let c = 0; c < SEG; c++) {
        const a0 = r * (SEG + 1) + c, b0 = a0 + 1, c0 = a0 + SEG + 1, d0 = c0 + 1;
        idx.push(a0, c0, b0, b0, c0, d0);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv2, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    paint(geo, (c, x, y) => {
      // 下沿略亮（受光），上沿略暗；全部是白色系，绝不发黑
      const k = THREE.MathUtils.clamp(-y / h, 0, 1);
      c.copy(new THREE.Color(PAL.lace)).multiplyScalar(0.90 + k * 0.10);
    });
    const lace = laceTexture(9, 0.34);
    lace.repeat.set(7, 1);
    const m = new THREE.Mesh(geo, matSoft(0xffffff, { map: lace, side: THREE.DoubleSide }));
    m.position.y = 0.300 - row * 0.048;
    bounce.add(m);

    // 内衬：把荷叶边的敞口从里侧封住（白色斜面），从任何角度都看不到黑
    const lin = new THREE.CylinderGeometry(0.196 + row * 0.010, 0.272 + row * 0.018, 0.080, 48, 1, true);
    paint(lin, (c) => c.copy(new THREE.Color(PAL.lace)).multiplyScalar(0.78));
    const linM = new THREE.Mesh(lin, matSoft(0xffffff, { side: THREE.DoubleSide }));
    linM.position.y = m.position.y - 0.026;
    bounce.add(linM);
  }

  // 裙口内侧的接触阴影：腿从裙下出来时压深一圈，避免"裙子浮在腿上"
  {
    const inner = new THREE.CylinderGeometry(0.192, 0.206, 0.030, 48, 1, true);
    paint(inner, (c) => c.copy(new THREE.Color(PAL.dressDeep)).multiplyScalar(0.55));
    const innerM = new THREE.Mesh(inner, matSoft(0xffffff, { side: THREE.DoubleSide }));
    innerM.position.y = 0.214;
    bounce.add(innerM);
    // 裙内封底（朝下的暗盘）：从低角度看也不会露出背景
    const capMat = matSoft(new THREE.Color(PAL.dressDeep).multiplyScalar(0.5).getHex(), { side: THREE.DoubleSide });
    const cap = new THREE.Mesh(new THREE.CircleGeometry(0.196, 40), capMat);
    cap.rotation.x = Math.PI * 0.5;
    cap.position.y = 0.198;
    bounce.add(cap);
  }

  /* ============ 3. 白蕾丝围裙（球面贴花，自然贴合） ============ */
  const apronTex = (() => {
    // 白围裙布 + 泡褶边 + 鲸鱼
    const S = 512;
    const cv = document.createElement('canvas');
    cv.width = cv.height = S;
    const x = cv.getContext('2d');
    x.clearRect(0, 0, S, S);
    // 布形：上窄下宽的圆角梯形
    x.beginPath();
    x.moveTo(S * 0.30, S * 0.10);
    x.bezierCurveTo(S * 0.16, S * 0.30, S * 0.14, S * 0.62, S * 0.20, S * 0.76);
    x.quadraticCurveTo(S * 0.50, S * 0.86, S * 0.80, S * 0.76);
    x.bezierCurveTo(S * 0.86, S * 0.62, S * 0.84, S * 0.30, S * 0.70, S * 0.10);
    x.quadraticCurveTo(S * 0.50, S * 0.03, S * 0.30, S * 0.10);
    x.closePath();
    const cloth = x.createLinearGradient(0, S * 0.1, 0, S * 0.8);
    cloth.addColorStop(0, '#ffffff');
    cloth.addColorStop(1, '#eef1fa');
    x.fillStyle = cloth;
    x.fill();
    // 泡褶边
    x.fillStyle = '#fbfcff';
    x.strokeStyle = '#dfe5f4';
    x.lineWidth = 3;
    for (let i = 0; i < 26; i++) {
      const t = i / 25;
      const bx = THREE.MathUtils.lerp(S * 0.19, S * 0.81, t);
      const by = S * 0.76 + Math.sin(t * Math.PI) * S * 0.06;
      x.beginPath(); x.arc(bx, by, S * 0.028, 0, Math.PI * 2); x.fill(); x.stroke();
    }
    // 鲸鱼
    const wt = whaleTexture();
    x.drawImage(wt.userData.canvas, S * 0.26, S * 0.26, S * 0.48, S * 0.48);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  })();

  // 前胸围裙：贴合身体的「弧形围兜」（自建曲面，半径略大于身体，绝对在外侧）
  {
    const ROWS = 24, COLS = 40;
    const yTop = 0.60, yBot = 0.40;
    const halfAng = 0.92;                        // 横向张开约 105°
    const pos = [], uv = [], idx = [];
    const bodyR = (y) => {
      // 复刻身体剖面半径（0.66→0.24 区间）
      const t = THREE.MathUtils.clamp((0.66 - y) / 0.42, 0, 1);
      return THREE.MathUtils.lerp(0.108, 0.228, Math.pow(t, 1.6)) + 0.004;
    };
    for (let r = 0; r <= ROWS; r++) {
      const v = r / ROWS;
      const y = THREE.MathUtils.lerp(yTop, yBot, v);
      const rr = bodyR(y) + 0.006;
      for (let c = 0; c <= COLS; c++) {
        const u = c / COLS;
        const a = (u - 0.5) * 2 * halfAng;
        pos.push(Math.sin(a) * rr, y, Math.cos(a) * rr);
        uv.push(u, 1 - v);
      }
    }
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const a0 = r * (COLS + 1) + c, b0 = a0 + 1, c0 = a0 + COLS + 1, d0 = c0 + 1;
        idx.push(a0, c0, b0, b0, c0, d0);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
      map: apronTex, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    }));
    bounce.add(m);
  }
  /* ============ 4. 腰封（一体环带，不是轮胎） ============ */
  const beltGeo = new THREE.CylinderGeometry(0.121, 0.117, 0.036, 56, 1, true);
  paint(beltGeo, (c, x, y, z) => {
    c.copy(new THREE.Color(PAL.dressDeep)).lerp(new THREE.Color(PAL.gold), z > 0.08 ? 0.25 : 0);
  });
  const belt = new THREE.Mesh(beltGeo, matSoft(0xffffff));
  belt.position.y = 0.408;
  bounce.add(belt);
  // 腰带下缘的压叠阴影：裙子上沿被腰带压住的那一圈（接触阴影，避免硬切穿模）
  {
    const sh = new THREE.CylinderGeometry(0.1235, 0.1245, 0.013, 56, 1, true);
    paint(sh, (c) => c.copy(new THREE.Color(PAL.dressDeep)).multiplyScalar(0.62));
    const shm = new THREE.Mesh(sh, matSoft(0xffffff));
    shm.position.y = 0.3835;
    bounce.add(shm);
  }
  // 金扣：真正有厚度与高光的环扣（外环 + 内凹板 + 顶部一点亮）
  {
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(0.0165, 0.0042, 14, 36),
      matSoft(PAL.gold, { vertexColors: false })
    );
    ring.position.set(0, 0.408, 0.1195);
    bounce.add(ring);

    const plate = new THREE.Mesh(
      new THREE.CylinderGeometry(0.0145, 0.0145, 0.0035, 28),
      matSoft(PAL.dressDeep, { vertexColors: false })
    );
    plate.rotation.x = Math.PI * 0.5;
    plate.position.set(0, 0.408, 0.1182);
    bounce.add(plate);

    const shine = new THREE.Mesh(
      new THREE.SphereGeometry(0.0042, 14, 10),
      new THREE.MeshBasicMaterial({ color: 0xfff4d2 })
    );
    shine.position.set(-0.005, 0.4145, 0.1222);
    bounce.add(shine);
  }

  /* ============ 5. 领口蕾丝 + 领结（细带一体） ============ */
  const collarGeo = new THREE.TorusGeometry(0.078, 0.012, 12, 60);
  paint(collarGeo, (c) => c.set(PAL.lace));
  const collar = new THREE.Mesh(collarGeo, matSoft(PAL.lace));
  collar.rotation.x = Math.PI * 0.5;
  collar.scale.z = 0.72;
  collar.position.y = 0.612;
  bounce.add(collar);

  // 领结：两个环 + 结，用细几何一次成型（柔软的蝴蝶结）
  const bowTie = new THREE.Group();
  [-1, 1].forEach((s) => {
    const g = new THREE.SphereGeometry(0.045, 24, 18);
    paint(g, (c, x, y, z) => c.copy(new THREE.Color(PAL.dressDeep)).lerp(new THREE.Color(0x3b4270), (x * s + 0.045) / 0.09));
    const loop = new THREE.Mesh(g, matSoft(0xffffff));
    loop.scale.set(1.25, 0.72, 0.5);
    loop.position.set(s * 0.045, 0, 0);
    loop.rotation.z = s * 0.22;
    bowTie.add(loop);
  });
  const knot = new THREE.Mesh(new THREE.SphereGeometry(0.017, 18, 14), matSoft(PAL.dressDeep, { vertexColors: false }));
  bowTie.add(knot);
  bowTie.position.set(0, 0.585, 0.105);
  bounce.add(bowTie);

  /* ============ 6. 手（袖子与手一体，柔和过渡） ============ */
  const arms = [];
  [-1, 1].forEach((s) => {
    const pivot = new THREE.Group();
    pivot.position.set(s * 0.135, 0.552, 0.012);

    // 袖 → 袖口 → 手：一条平滑剖面旋转体，避免「胶囊+球」的接头
    const prof = smoothProfile([
      [0.000, 0.010],
      [0.030, 0.006],
      [0.040, -0.020],
      [0.043, -0.060],
      [0.040, -0.100],
      [0.038, -0.120],   // 袖口收紧
      [0.034, -0.132],
      [0.036, -0.150],   // 小手
      [0.031, -0.172],
      [0.018, -0.182],
      [0.000, -0.184],
    ], 36);
    const armGeo = lathe(prof, 48);
    paint(armGeo, (c, x, y, z) => {
      if (y > -0.118) {
        c.copy(new THREE.Color(dress)).lerp(new THREE.Color(PAL.dressDeep), 0.35);
      } else {
        // 袖口白蕾丝 → 皮肤
        const t = THREE.MathUtils.clamp((-0.118 - y) / 0.022, 0, 1);
        c.copy(new THREE.Color(PAL.lace)).lerp(new THREE.Color(PAL.skin), Math.max(0, (t - 0.55) / 0.45));
      }
    });
    const arm = new THREE.Mesh(armGeo, matSoft(0xffffff));
    pivot.add(arm);
    pivot.rotation.z = s * 0.2;
    arms.push({ pivot, side: s });
    bounce.add(pivot);
  });

  /* ============ 6b. 腿 + 鞋（裙子下面要有东西撑着，不然像飘着） ============ */
  const legs = [];
  [-1, 1].forEach((s) => {
    const legProf = smoothProfile([
      [0.000, 0.006],   // 鞋底中心
      [0.030, 0.004],
      [0.049, 0.014],   // 鞋头外圆
      [0.052, 0.030],
      [0.044, 0.046],   // 鞋跟收口
      [0.036, 0.060],   // 脚踝
      [0.040, 0.086],
      [0.045, 0.118],   // 小腿
      [0.047, 0.152],   // 膝
      [0.052, 0.190],
      [0.048, 0.226],   // 大腿（藏进裙子）
      [0.000, 0.236],
    ], 30);
    const legGeo = lathe(legProf, 40);
    const shoeC = new THREE.Color(accent).multiplyScalar(0.30);
    const skinC = new THREE.Color(PAL.skin);
    const sockC = new THREE.Color(PAL.lace);
    const sm = (a, b, v) => {
      const k = THREE.MathUtils.clamp((v - a) / (b - a), 0, 1);
      return k * k * (3 - 2 * k);
    };
    paint(legGeo, (c, x, y, z) => {
      // 鞋 → 袜 → 皮肤：用 smoothstep 过渡，不再是一刀切的色环
      const toSock = sm(0.030, 0.062, y);
      const toSkin = sm(0.130, 0.152, y);
      c.copy(shoeC).lerp(sockC, toSock).lerp(skinC, toSkin);
      if (y < 0.040) c.multiplyScalar(0.94);
    });
    const leg = new THREE.Mesh(legGeo, matSoft(0xffffff));
    leg.position.set(s * 0.062, 0.001, 0.006);
    leg.rotation.z = s * 0.03;
    // 袜口：一圈略粗的白环（蕾丝边），把袜子和腿的接缝藏进去
    const cuff = new THREE.Mesh(
      new THREE.TorusGeometry(0.0452, 0.0066, 10, 30),
      matSoft(PAL.lace, { vertexColors: false })
    );
    cuff.rotation.x = Math.PI * 0.5;
    cuff.position.set(0, 0.138, 0);
    leg.add(cuff);
    bounce.add(leg);
    legs.push(leg);
  });

  /* ============ 7. 头 + 脸 ============ */
  const headGroup = new THREE.Group();
  headGroup.position.y = HEAD_Y;
  bounce.add(headGroup);

  const headGeo = new THREE.SphereGeometry(HEAD_R, 96, 72);
  // 脸型：用 smoothstep 做「上宽下收 + 脸颊微鼓 + 下巴圆」的连续变形，
  // 不再用分段线性（分段会在法线上留下折痕，看起来就"不顺滑"）。
  {
    const p = headGeo.attributes.position;
    const smooth = (e0, e1, v) => {
      const k = THREE.MathUtils.clamp((v - e0) / (e1 - e0), 0, 1);
      return k * k * (3 - 2 * k);
    };
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const yn = y / HEAD_R;                     // -1 下巴 … 1 头顶
      // 下颌：越往下越收（平滑过渡到 0.86）
      const jaw = 1 - smooth(-0.15, -0.95, -yn) * 0.145;
      // 脸颊：中下段横向略鼓（Q 版的嘟嘟脸）
      const cheek = 1 + Math.max(0, 1 - Math.abs(yn + 0.22) / 0.45) * 0.055;
      // 头顶略微收，避免"圆球感"
      const crown = 1 - smooth(0.55, 1.0, yn) * 0.045;
      const sx = 1.07 * jaw * cheek * crown;
      const sz = 0.985 * jaw * (1 + Math.max(0, 1 - Math.abs(yn + 0.18) / 0.5) * 0.03);
      // 下巴往前一点（侧面看有下巴，不是球）
      const chin = smooth(-0.30, -1.0, -yn) * 0.022;
      p.setXYZ(i, x * sx, y, z * sz + (z > 0 ? chin : 0));
    }
    headGeo.computeVertexNormals();
  }
  paint(headGeo, (c, x, y, z) => {
    // 皮肤带一点下巴阴影
    const t = THREE.MathUtils.clamp((-y / HEAD_R + 0.2) * 0.7, 0, 1);
    c.copy(new THREE.Color(PAL.skin)).lerp(new THREE.Color(PAL.skinDeep), t * 0.55);
  });
  const head = new THREE.Mesh(headGeo, matSoft(0xffffff));
  headGroup.add(head);

  // 脸：闭眼 + 腮红 + 小嘴（贴图 + 正对相机）
  const faceG = new THREE.Group();
  const eyesG = new THREE.Group();
  const EYE_W = 0.145, EYE_H = 0.072;
  [-1, 1].forEach((s) => {
    const eye = faceSprite(closedEyeTexture('#241d22'), EYE_W, EYE_H);
    eye.position.set(s * 0.080, -0.022, 0.221);
    eyesG.add(eye);
  });
  faceG.add(eyesG);
  [-1, 1].forEach((s) => {
    const b = faceSprite(blushTexture('#f6b6b8'), 0.085, 0.046);
    b.position.set(s * 0.135, -0.075, 0.207);
    faceG.add(b);
  });
  const mouth = faceSprite(mouthTexture('#dfa0a4'), 0.02, 0.02);
  mouth.position.set(0, -0.108, 0.228);
  faceG.add(mouth);
  headGroup.add(faceG);

  /* ============ 8. 头发：大块连续发片 ============ */
  const hairG = new THREE.Group();
  headGroup.add(hairG);

  // 8a. 顶盔（一体，带发丝沟槽的柔光渐变）
  const capGeo = new THREE.SphereGeometry(HEAD_R * 1.05, 64, 40, 0, Math.PI * 2, 0, Math.PI * 0.50);
  {
    const p = capGeo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const a = Math.atan2(x, z);
      // 发丝沟槽（很浅，靠光影出质感，不加硬边）
      const groove = 1 + Math.sin(a * 11) * 0.008;
      p.setXYZ(i, x * groove * 1.03, y * 1.03, z * groove * 1.02);
    }
    capGeo.computeVertexNormals();
    paint(capGeo, (c, x, y, z) => {
      const t = THREE.MathUtils.clamp((y / HEAD_R - 0.1) / 0.9, 0, 1);
      c.copy(lerpColor(hairDark, hairMid, t * 0.9));
    });
  }
  hairG.add(new THREE.Mesh(capGeo, matSoft(0xffffff)));

  // 8b. 刘海：三片连续发片（用 Tube 曲线，不是球）
  const bangCurves = [
    { pts: [[-0.20, 0.145, 0.075, 0.062], [-0.185, 0.085, 0.15, 0.062], [-0.15, 0.03, 0.195, 0.056], [-0.11, 0.005, 0.215, 0.044], [-0.075, -0.005, 0.212, 0.03]] },
    { pts: [[-0.135, 0.185, 0.085, 0.06], [-0.115, 0.10, 0.175, 0.062], [-0.075, 0.035, 0.218, 0.056], [-0.035, 0.008, 0.228, 0.044], [0.0, -0.002, 0.222, 0.028]] },
    { pts: [[-0.05, 0.20, 0.09, 0.058], [-0.02, 0.11, 0.19, 0.06], [0.025, 0.04, 0.225, 0.054], [0.062, 0.012, 0.228, 0.042], [0.095, 0.0, 0.218, 0.026]] },
    { pts: [[0.045, 0.20, 0.09, 0.056], [0.08, 0.11, 0.185, 0.058], [0.115, 0.04, 0.218, 0.05], [0.148, 0.012, 0.218, 0.038], [0.172, 0.0, 0.205, 0.024]] },
    { pts: [[0.145, 0.175, 0.08, 0.05], [0.185, 0.10, 0.15, 0.052], [0.20, 0.04, 0.185, 0.044], [0.198, 0.012, 0.19, 0.032], [0.188, 0.0, 0.18, 0.02]] },
  ];
  bangCurves.forEach((b) => {
    const g = hairStrand(b.pts, null, (c, t) => c.copy(lerpColor(hairDark, hair, t)), 14);
    hairG.add(new THREE.Mesh(g, matSoft(0xffffff)));
  });

  // 8c. 侧发：长直发片（连续，发梢渐浅，外翻）
  [-1, 1].forEach((s) => {
    const g = hairStrand([
      [s * 0.215, 0.14, -0.01, 0.066],
      [s * 0.252, 0.02, -0.04, 0.068],
      [s * 0.262, -0.12, -0.05, 0.062],
      [s * 0.258, -0.27, -0.05, 0.052],
      [s * 0.268, -0.40, -0.03, 0.045],
      [s * 0.295, -0.49, 0.0, 0.032],
      [s * 0.318, -0.545, 0.03, 0.012],
    ], null, (c, t) => {
      if (t < 0.35) c.copy(lerpColor(hairDark, hair, t / 0.35));
      else if (t < 0.72) c.copy(lerpColor(hair, hairMid, (t - 0.35) / 0.37));
      else c.copy(lerpColor(hairMid, hairLight, (t - 0.72) / 0.28));
    }, 26);
    hairG.add(new THREE.Mesh(g, matSoft(0xffffff)));

    // 内侧短一缕（层次感）
    const g2 = hairStrand([
      [s * 0.17, 0.06, 0.12, 0.05],
      [s * 0.2, -0.06, 0.1, 0.048],
      [s * 0.215, -0.2, 0.08, 0.04],
      [s * 0.215, -0.3, 0.06, 0.018],
    ], null, (c, t) => c.copy(lerpColor(hair, hairMid, t)), 14);
    hairG.add(new THREE.Mesh(g2, matSoft(0xffffff)));
  });

  // 8d. 后发：一整片（连续曲面，不是三个球）
  const backGeo = new THREE.SphereGeometry(HEAD_R * 1.035, 56, 40, Math.PI * 0.80, Math.PI * 0.40, 0, Math.PI * 0.86);
  {
    const p = backGeo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const a = Math.atan2(x, z);
      const wave = Math.sin(a * 7) * 0.01;
      const dn = THREE.MathUtils.clamp((-y / HEAD_R - 0.2) / 0.9, 0, 1);
      const drop = dn * 0.22; // 长发下垂
      p.setXYZ(i, x * (1.06 + wave), y - drop, z * (1.04 + wave));
    }
    backGeo.computeVertexNormals();
    paint(backGeo, (c, x, y, z) => {
      const dn = THREE.MathUtils.clamp((-y / HEAD_R - 0.2) / 0.9, 0, 1);
      if (dn < 0.5) c.copy(lerpColor(hairDark, hair, dn / 0.5));
      else c.copy(lerpColor(hair, hairMid, (dn - 0.5) / 0.5));
    });
  }
  hairG.add(new THREE.Mesh(backGeo, matSoft(0xffffff)));

  // 8e. 发丝高光：柔和的一条弧带（用贴图而不是小球）
  {
    const S = 256;
    const cv = document.createElement('canvas');
    cv.width = cv.height = S;
    const x = cv.getContext('2d');
    x.clearRect(0, 0, S, S);
    // 赛璐璐的"发丝光环"：额前 3 道竖向高光，沿头顶弧线排布（不是横贯的一条）
    for (let i = 0; i < 3; i++) {
      const cx = S * (0.40 + i * 0.10);
      const cy = S * (0.30 + i * 0.02);
      const g = x.createRadialGradient(cx, cy, 1, cx, cy, S * 0.085);
      g.addColorStop(0, 'rgba(226,244,255,0.95)');
      g.addColorStop(0.5, 'rgba(198,230,255,0.40)');
      g.addColorStop(1, 'rgba(190,225,255,0)');
      x.fillStyle = g;
      x.beginPath(); x.ellipse(cx, cy, S * 0.030, S * 0.085, i === 1 ? 0.05 : -0.12, 0, Math.PI * 2); x.fill();
    }
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const gloss = new THREE.Mesh(
      new THREE.SphereGeometry(HEAD_R * 1.05, 40, 24, Math.PI - 0.7, 1.4, 0.42, 0.5),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false })
    );
    gloss.position.y = 0.006;
    hairG.add(gloss);
  }

  /* ============ 9. 白色蕾丝女仆头巾（大片连续 + 蕾丝贴图） ============ */
  const hd = new THREE.Group();
  {
    // 头巾主体：一个贴合头顶的软罩（覆盖到眉毛线以上，前缘自然搭在刘海上）
    const g = new THREE.SphereGeometry(HEAD_R * 1.085, 64, 36, 0, Math.PI * 2, 0, Math.PI * 0.30);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const y = p.getY(i);
      // 压扁成软趴趴的头巾
      p.setY(i, y * 0.92 + 0.012);
    }
    g.computeVertexNormals();
    paint(g, (c, x, y, z) => {
      const t = THREE.MathUtils.clamp((y - 0.06) / 0.2, 0, 1);
      c.copy(new THREE.Color(PAL.lace)).lerp(new THREE.Color(PAL.laceShade), 0.35 + t * 0.4);
    });
    const m = new THREE.Mesh(g, matSoft(0xffffff));
    m.position.y = 0.145;
    hd.add(m);

    // 泡褶边：一圈连续起伏的环（几何做柔和褶皱 + 蕾丝贴图）
    // 蓬松蕾丝冠：两层球面环带 + 31 瓣扇贝边（用曲面做，不是球串）
    const lace = laceTexture(12, 0.42);
    lace.repeat.set(9, 1);
    [[0.026, 1.020, 0.155, 0.45], [0.022, 1.048, 0.128, 0.30]].forEach(([h, sc, yy, squash], li) => {
      const seg = 140, rows = 8;
      const cols = 31;                              // 扇贝瓣数
      const geo = new THREE.CylinderGeometry(HEAD_R * sc, HEAD_R * (sc + 0.032), h, seg, rows, true);
      const rp = geo.attributes.position;
      for (let i = 0; i < rp.count; i++) {
        const x = rp.getX(i), y = rp.getY(i), z = rp.getZ(i);
        const a = Math.atan2(x, z);
        const k = (y + h / 2) / h;                  // 0 下沿 → 1 上沿
        // 扇贝：每个瓣一个余弦鼓包（圆润，不是折角）
        const petal = Math.pow(Math.abs(Math.cos(a * cols / 2)), 0.55);
        const bulge = (0.013 + li * 0.006) * petal;
        const len = Math.hypot(x, z) || 1;
        rp.setXYZ(i, (x / len) * (len + bulge * k), y - (1 - k) * h * squash * 0.5, (z / len) * (len + bulge * k));
      }
      geo.computeVertexNormals();
      paint(geo, (c, x, y) => {
        const k = THREE.MathUtils.clamp((y + 0.03) / 0.12, 0, 1);
        c.copy(new THREE.Color(PAL.lace)).multiplyScalar(0.86 + k * 0.14);
      });
      const ring = new THREE.Mesh(geo, matSoft(0xffffff, { map: lace, side: THREE.DoubleSide }));
      ring.position.y = yy;
      hd.add(ring);
    });
  }
  hairG.add(hd);

  /* ============ 10. 呆毛（连续曲线） ============ */
  {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.01, 0.285, -0.01),
      new THREE.Vector3(-0.06, 0.35, -0.02),
      new THREE.Vector3(-0.02, 0.40, -0.05),
      new THREE.Vector3(0.035, 0.385, -0.07),
    ]);
    const g = new THREE.TubeGeometry(curve, 32, 0.009, 8, false);
    paint(g, (c, x, y, z, uv) => c.copy(lerpColor(hair, hairMid, uv ? uv.u : 0.5)));
    const m = new THREE.Mesh(g, matSoft(0xffffff));
    hairG.add(m);
    m.userData.ahoge = true;
  }

  /* ============ 11. 鱼鳍耳（一片式，带渐变与鳍条贴图） ============ */
  const ears = [];
  [-1, 1].forEach((side) => {
    const sh = new THREE.Shape();
    // 柔和的水滴形鳍，不用三角硬边
    sh.moveTo(0, 0.03);
    sh.bezierCurveTo(0.06, 0.085, 0.135, 0.06, 0.155, 0.02);
    sh.bezierCurveTo(0.145, -0.02, 0.105, -0.055, 0.072, -0.058);
    sh.bezierCurveTo(0.04, -0.06, 0.012, -0.035, 0, 0.03);
    const geo = new THREE.ExtrudeGeometry(sh, { depth: 0.03, bevelEnabled: true, bevelSize: 0.008, bevelThickness: 0.008, bevelSegments: 3, curveSegments: 24 });
    geo.computeVertexNormals();
    paint(geo, (c, x, y, z) => {
      const t = THREE.MathUtils.clamp(x / 0.155, 0, 1);
      c.copy(lerpColor(finColor, finLight, Math.pow(t, 0.7)));
    });
    const fin = new THREE.Group();
    const m = new THREE.Mesh(geo, matSoft(0xffffff, { side: THREE.DoubleSide }));
    m.position.z = -0.014;
    m.scale.set(0.86, 0.86, 1);
    fin.add(m);

    // 鳍条：细长曲面（贴花式，不做硬胶囊）
    for (let i = 0; i < 3; i++) {
      const rib = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.0055, 0.062 - i * 0.008, 4, 8),
        matSoft(PAL.lace, { vertexColors: false })
      );
      rib.position.set(0.055 + i * 0.022, 0.012 - i * 0.021, 0.017);
      rib.rotation.z = Math.PI * 0.5 - (0.5 + i * 0.17);
      fin.add(rib);
    }
    fin.position.set(side * 0.252, -0.018, 0.052);
    fin.rotation.z = side * 0.26;
    if (side < 0) fin.scale.x = -1;
    headGroup.add(fin);
    ears.push(fin);
  });

  /* ============ 12. 蝴蝶结（柔软一体 + 金扣） ============ */
  const hairBow = new THREE.Group();
  [-1, 1].forEach((s) => {
    const g = new THREE.SphereGeometry(0.05, 28, 20);
    paint(g, (c, x) => c.copy(lerpColor(accent, new THREE.Color(accent).multiplyScalar(0.72), (x * s + 0.05) / 0.10)));
    const loop = new THREE.Mesh(g, matSoft(0xffffff));
    loop.scale.set(1.3, 0.78, 0.55);
    loop.position.x = s * 0.05;
    loop.rotation.z = s * 0.26;
    hairBow.add(loop);
    // 垂带
    const tail = new THREE.Mesh(new THREE.CapsuleGeometry(0.013, 0.045, 4, 10), matSoft(accent, { vertexColors: false }));
    tail.position.set(s * 0.028, -0.055, 0);
    tail.rotation.z = s * 0.34;
    hairBow.add(tail);
  });
  const goldBead = new THREE.Mesh(new THREE.SphereGeometry(0.016, 20, 16), matSoft(PAL.gold, { vertexColors: false }));
  hairBow.add(goldBead);
  hairBow.position.set(0.168, 0.145, 0.155);
  hairBow.rotation.set(0.06, 0.6, -0.34);
  headGroup.add(hairBow);

  /* ============ 13. 人鱼尾巴（连续曲面 + 渐变色鳍） ============ */
  const fluke = new THREE.Group();
  {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0.26, -0.05),
      new THREE.Vector3(0.015, 0.16, -0.15),
      new THREE.Vector3(0.05, 0.11, -0.27),
      new THREE.Vector3(0.095, 0.17, -0.35),
    ]);
    const g = new THREE.TubeGeometry(curve, 40, 0.056, 14, false);
    paint(g, (c, x, y, z, uv) => {
      const t = uv ? uv.u : 0;
      c.copy(lerpColor(hair, hairMid, t)).lerp(new THREE.Color(hairLight), Math.pow(t, 3) * 0.7);
    });
    bounce.add(new THREE.Mesh(g, matSoft(0xffffff)));

    // 尾鳍：两片柔和曲面
    [-1, 1].forEach((s) => {
      const sh = new THREE.Shape();
      sh.moveTo(0, 0);
      sh.bezierCurveTo(0.05, 0.055, 0.13, 0.05, 0.15, 0.005);
      sh.bezierCurveTo(0.125, -0.03, 0.06, -0.04, 0, 0);
      const geo = new THREE.ExtrudeGeometry(sh, { depth: 0.018, bevelEnabled: true, bevelSize: 0.006, bevelThickness: 0.005, bevelSegments: 2, curveSegments: 20 });
      geo.computeVertexNormals();
      paint(geo, (c, x) => c.copy(lerpColor(hairMid, hairTip, THREE.MathUtils.clamp(x / 0.15, 0, 1))));
      const m = new THREE.Mesh(geo, matSoft(0xffffff, { side: THREE.DoubleSide }));
      m.scale.x = s;
      m.position.z = -0.01;
      fluke.add(m);
    });
    fluke.position.set(0.095, 0.19, -0.36);
    fluke.rotation.set(-0.55, 0, 0.2);
    bounce.add(fluke);
  }

  /* ============ 14. 名牌 ============ */
  const tag = (() => {
    const cv = document.createElement('canvas');
    cv.width = 320; cv.height = 84;
    const x = cv.getContext('2d');
    x.fillStyle = 'rgba(10,16,28,.68)';
    x.beginPath();
    if (x.roundRect) x.roundRect(6, 8, 308, 68, 26); else x.rect(6, 8, 308, 68);
    x.fill();
    x.strokeStyle = 'rgba(160,200,255,.42)'; x.lineWidth = 2; x.stroke();
    x.fillStyle = tagColor;
    x.font = 'bold 42px "Microsoft YaHei", sans-serif';
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(name, 160, 44);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
    spr.scale.set(0.6, 0.158, 1);
    spr.position.y = 1.16;
    return spr;
  })();
  root.add(tag);

  const ahoge = hairG.children.find((c) => c.userData && c.userData.ahoge);

  // 描边：把 3D 渲染拉回 2D 动画的勾线质感（深蓝紫，粗细随距离补偿）
  const outlineCount = attachOutline(root, { color: '#171b36', thickness: 0.0030 });

  // 骨骼：把已建好的模型按骨骼重新挂载，之后所有动画只动骨骼
  const rig = buildRig(
    root,
    { headGroup, hairG, faceG, eyesG, arms, legs, fluke, ahoge, tag },
    { twintail: !!spec.twintail, fluke: true }
  );
  let tagT = 0;

  /* ============ 动画（全部走骨骼） ============ */
  return {
    group: root,
    outlineCount,
    rig,
    parts: { headGroup, hairG, faceG, eyesG, eyesGroup: eyesG, arms, legs, tag, fluke, ahoge },
    setVisible(v) { root.visible = v; },
    update(dt) {
      rig.update(dt);
      // 姓名牌是 Sprite，不进骨骼，单独轻轻浮
      tagT += dt;
      if (tag) tag.position.y = 1.16 + Math.sin(tagT * 1.2) * 0.006;
    },
  };
}

/* ================= 三姐妹设定 ================= */
export const AVATAR_SPECS = {
  shiqi: {
    name: '大姐',
    hairDark: 0x27335f, hair: 0x37498a, hairMid: 0x5473bb, hairLight: 0x8db8e8, hairTip: 0xbde0fa,
    dress: 0x4b55a0, accent: PAL.bow, finColor: 0x38477d, finLight: 0x9ecdf0, tagColor: '#dfe9ff',
  },
  jiu: {
    name: '二姐',
    hairDark: 0x1f1929, hair: 0x30243f, hairMid: 0x4a3463, hairLight: 0x8a63a8, hairTip: 0xd2a8e4,
    dress: 0x221d29, accent: 0xe8598a, finColor: 0x3a2a52, finLight: 0xc99fd8, tagColor: '#ffd9e5',
  },
  hutao: {
    name: '三姐',
    hairDark: 0x7a3f22, hair: 0xa2562c, hairMid: 0xc97440, hairLight: 0xf0a865, hairTip: 0xffdcaa,
    dress: 0x3a2620, accent: 0xffb040, finColor: 0x7a4326, finLight: 0xffc98a, tagColor: '#ffe6c4',
  },
};
