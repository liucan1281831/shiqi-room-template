# Build the "room" Android client (WebView shell for the family room)
# Toolchain is the one already used for qqhook: JDK17 + android-35 jar + build-tools 14 (d8/aapt2/zipalign/apksigner)
$ErrorActionPreference = 'Stop'
$root = '/home/user/familyroom\apk'
$sdk  = '/home/user\local-ai\tools\sdk'
$jdk  = "$sdk\jdk\jdk-17.0.20.1+1"
$javac = "$jdk\bin\javac.exe"
$androidJar = "$sdk\plat\android-35\android.jar"
$bt = "$sdk\bt\android-14"
$ks = '/home/user/familyroom\apk\dsh.keystore'

$env:JAVA_HOME = $jdk
$env:PATH = "$jdk\bin;$env:PATH"

$build = "$root\build"
if (Test-Path $build) { Remove-Item $build -Recurse -Force }
New-Item -ItemType Directory -Force -Path "$build\classes","$build\dex","$root\assets" | Out-Null

$src = Get-ChildItem "$root\src" -Recurse -Filter *.java | ForEach-Object { $_.FullName }

Write-Host '[1/6] javac'
& $javac -source 8 -target 8 -nowarn -encoding UTF-8 -cp $androidJar -d "$build\classes" $src
if ($LASTEXITCODE -ne 0) { throw 'javac failed' }

Write-Host '[2/6] d8'
$classFiles = Get-ChildItem "$build\classes" -Recurse -Filter *.class | ForEach-Object { $_.FullName }
& "$bt\d8.bat" --lib $androidJar --min-api 23 --output "$build\dex" $classFiles
if ($LASTEXITCODE -ne 0) { throw 'd8 failed' }

Write-Host '[3/6] aapt2 compile'
& "$bt\aapt2.exe" compile --dir "$root\res" -o "$build\res.zip"
if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile failed' }

Write-Host '[3b/6] aapt2 link'
& "$bt\aapt2.exe" link -o "$build\base.apk" --manifest "$root\AndroidManifest.xml" -I $androidJar -A "$root\assets" --min-sdk-version 23 --target-sdk-version 33 --auto-add-overlay "$build\res.zip"
if ($LASTEXITCODE -ne 0) { throw 'aapt2 failed' }

Write-Host '[4/6] add classes.dex'
$py = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'
if (-not (Test-Path $py)) { $py = (Get-Command python -ErrorAction SilentlyContinue).Source }
if (-not $py) { throw 'python not found' }
& $py '/home/user\local-ai\qqhook\add_dex.py' "$build\base.apk" "$build\dex\classes.dex" "$build\unsigned.apk"
if ($LASTEXITCODE -ne 0) { throw 'add_dex failed' }

Write-Host '[5/6] zipalign'
& "$bt\zipalign.exe" -f 4 "$build\unsigned.apk" "$build\aligned.apk"
if ($LASTEXITCODE -ne 0) { throw 'zipalign failed' }

Write-Host '[6/6] sign'
& "$bt\apksigner.bat" sign --ks $ks --ks-pass pass:dshfamily --key-pass pass:dshfamily --out "$root\room.apk" "$build\aligned.apk"
if ($LASTEXITCODE -ne 0) { throw 'apksigner failed' }

Write-Host ''
Write-Host ('OK -> ' + (Resolve-Path "$root\room.apk"))
Get-Item "$root\room.apk" | Select-Object FullName, Length