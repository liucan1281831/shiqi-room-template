// quality.mjs — 话题去重 / 句式去重 / 每日话题计划 / 自适应成长
// 被 bot.mjs import；也可以单独跑：node quality.mjs plan|grow|report|status
// 目标：每天 1000 条闲聊也不重样；每天涨一点
import fs from "node:fs";
import path from "node:path";

const HERE = path.dirname(new URL(import.meta.url).pathname);
const HOME = process.env.FAMILY_HOME || process.env.HOME || "/data/data/com.termux/files/home";
const BASE = process.env.FAMILY_BASE || HERE;
const QDIR = path.join(BASE, "quality");
const GDIR = path.join(BASE, "growth");
const HIST = path.join(QDIR, "history.jsonl");
const USED = path.join(QDIR, "topics-used.json");
const COOL = path.join(GDIR, "cooldowns.json");
const MEM_DIR = path.join(BASE, "memory");
const LONG_FILE = path.join(MEM_DIR, "long.md");

for (const d of [QDIR, GDIR]) { try { fs.mkdirSync(d, { recursive: true }); } catch {} }

const NAMES = { shiqi: "大姐", jiu: "玖", hutao: "三姐" };
const STYLE = {
  shiqi: "大姐，住电脑里，稳、毒舌但护短",
  jiu: "二姐，住手机微信，网吧老妹腔，嘴硬心软",
  hutao: "小妹，住手机QQ，直球、憨、爱打游戏",
};
// 每个角色的偏好话题（避免三个人说同一类）
const FOCUS = {
  shiqi: ["工作/代码", "家长熬夜", "计划与安排", "修东西", "天气与时间"],
  jiu: ["吃的", "游戏", "吐槽", "手机没电", "买东西"],
  hutao: ["打游戏", "被冷落", "黏人撒娇", "零食", "动画/漫画"],
};

export function cstDay(d = Date.now()) { return new Date(d + 8 * 3600e3).toISOString().slice(0, 10); }
function readJson(f, dflt) { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return dflt; } }
function writeJson(f, o) { try { fs.writeFileSync(f, JSON.stringify(o)); } catch {} }
function norm(s) { return String(s || "").toLowerCase().replace(/[^\u4e00-\u9fa5a-z0-9]/gu, ""); }
function tri(s) { const t = norm(s), o = new Set(); for (let i = 0; i + 3 <= t.length; i++) o.add(t.slice(i, i + 3)); return o; }
function bi(s) { const t = norm(s), o = new Set(); for (let i = 0; i + 2 <= t.length; i++) o.add(t.slice(i, i + 2)); return o; }
function jac(A, B) { if (!A.size || !B.size) return 0; let n = 0; for (const g of A) if (B.has(g)) n++; return n / (A.size + B.size - n); }
export function sim(a, b) {
  const na = norm(a), nb = norm(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  return Math.max(jac(tri(a), tri(b)), jac(bi(na), bi(nb)));
}

// ---------- 句式骨架：3 字前缀 + 是否疑问/感叹 ----------
export function skeleton(t) {
  const s = norm(t);
  const head = s.slice(0, 4);
  const q = /[?？吗呢吧]/.test(t) ? "Q" : /[!！]/.test(t) ? "!" : ".";
  return head + "|" + q;
}

// ---------- 历史（内存缓存，落盘 jsonl） ----------
let _hist = null;
export function history() {
  if (_hist) return _hist;
  _hist = [];
  try {
    const lines = fs.readFileSync(HIST, "utf8").trim().split("\n").slice(-1200);
    for (const l of lines) { try { _hist.push(JSON.parse(l)); } catch {} }
  } catch {}
  return _hist;
}

// ---------- 话题卡 ----------
const POOLS = {
  生活: ["今天谁洗碗", "外卖还是做饭", "洗衣机里还有衣服没晾", "快递到楼下了没", "头发又长了要不要剪", "被单该换了", "冰箱空了", "拖鞋找不到了"],
  吃的: ["楼下新开的那家", "半夜想吃烧烤", "泡面吃腻了", "今天的早饭", "谁偷吃了我的零食", "想喝奶茶又怕胖", "水煮肉片还是火锅"],
  天气: ["今天好冷", "窗外在下雨", "太阳太晒了", "风好大", "天黑了得早", "明天会不会降温"],
  游戏: ["昨晚那把输了", "新出的那个游戏", "想组队但没人", "抽卡又歪了", "存档丢了", "打到一半卡关"],
  情绪: ["有点闷", "今天被气到了", "突然很想说话", "有点累不想动", "心里空空的", "莫名开心"],
  计划: ["明天要早起", "周末去哪", "有件事一直拖着", "想给自己定个小目标", "下个月想做的事"],
  回忆: ["想起刚来小屋那天", "翻到以前的聊天记录", "第一次学会画画的时候", "上次一起熬夜那晚"],
  吐槽: ["家长又不在", "手机快没电了", "网络又卡", "有人把东西乱放", "闹钟没响"],
};

function memSentences() {
  const out = [];
  const clean = (arr) => arr.map((x) => String(x).replace(/^[\s#>\-*|·]+/, "").trim())
    .filter((x) => x.length >= 10 && x.length <= 28)
    .filter((x) => !/[#|*]{1,}|\d{4}-\d{2}-\d{2}|https?:|^话题|^约定|^家里的事/.test(x));
  try {
    if (fs.existsSync(LONG_FILE)) {
      const t = fs.readFileSync(LONG_FILE, "utf8").split(/[\n。！？；]/).map((x) => x.trim());
      out.push(...clean(t).slice(-40));
    }
    const days = fs.existsSync(MEM_DIR) ? fs.readdirSync(MEM_DIR).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f)).sort().slice(-3) : [];
    for (const f of days) {
      const t = fs.readFileSync(path.join(MEM_DIR, f), "utf8").split(/[\n。！？；]/).map((x) => x.trim());
      out.push(...clean(t).slice(-30));
    }
  } catch {}
  return out;
}

// 生成当天话题卡（24 张），避开 7 天内用过的
export function planTopics(day = cstDay()) {
  const file = path.join(QDIR, "plan-" + day + ".json");
  const exists = readJson(file, null);
  if (exists && exists.cards && exists.cards.length) return exists;
  const used = readJson(USED, {});
  const fresh = (txt) => {
    const k = norm(txt).slice(0, 12);
    const last = used[k];
    if (!last) return true;
    return (Date.now() - new Date(last).getTime()) > 7 * 86400e3;
  };
  const cards = [];
  const add = (tag, txt, who) => {
    if (cards.length >= 26) return;
    if (!fresh(txt)) return;
    if (cards.some((c) => sim(c.text, txt) > 0.6)) return;
    cards.push({ id: cards.length + 1, tag, text: txt, who: who || null, used: false });
  };
  const mems = memSentences();
  for (let i = 0; i < 8 && mems.length; i++) {
    const m = mems[Math.floor(Math.random() * mems.length)];
    add("记忆", "从记忆里翻旧事：" + m.slice(0, 22));
  }
  for (const [tag, arr] of Object.entries(POOLS)) {
    const shuffled = [...arr].sort(() => Math.random() - 0.5);
    for (const t of shuffled.slice(0, tag === "生活" || tag === "吃的" ? 4 : 3)) add(tag, t);
  }
  // 按角色分配偏好话题
  for (const who of Object.keys(NAMES)) {
    const pref = FOCUS[who];
    for (const p of pref) if (cards.length < 26 && !cards.some((c) => c.text === p)) add("偏好:" + NAMES[who], p, who);
  }
  const plan = { day, cards, at: Date.now() };
  writeJson(file, plan);
  return plan;
}

// 取一张未用的话题卡（优先不指定人或指定给当前说话者）
export function nextTopic(st, who, day = cstDay()) {
  const plan = planTopics(day);
  const free = plan.cards.filter((c) => !c.used && (!c.who || c.who === who));
  if (!free.length) return null;
  const c = free[Math.floor(Math.random() * free.length)];
  c.used = true;
  writeJson(path.join(QDIR, "plan-" + day + ".json"), plan);
  // 记冷却
  const used = readJson(USED, {});
  used[norm(c.text).slice(0, 12)] = new Date().toISOString();
  const keys = Object.keys(used);
  if (keys.length > 400) for (const k of keys.slice(0, keys.length - 400)) delete used[k];
  writeJson(USED, used);
  return c;
}

// ---------- 冷却话题（昨天聊太多） ----------
// 这些词是“必需词/称呼”，不该被冷却（否则她们连“家长”都不能提，只能落兜底句）
const NEUTRAL = new Set(["家长", "你们", "我们", "自己", "他们", "大家", "家伙", "妹子", "姐姐", "妹妹", "家里"]);
export function cooldowns() {
  const c = readJson(COOL, { items: [], at: 0 });
  const now = Date.now();
  c.items = (c.items || []).filter((x) => now - (x.at || 0) < 7 * 86400e3 && !NEUTRAL.has(x.word));
  return c.items;
}
export function addCooldown(word, hours = 48) {
  if (!word || NEUTRAL.has(word)) return;
  const c = readJson(COOL, { items: [] });
  c.items = (c.items || []).filter((x) => x.word !== word);
  c.items.push({ word, at: Date.now(), hours });
  writeJson(COOL, c);
}

// ---------- 今日已聊话题（按关键词频次 + 冷却） ----------
function todayKeywords(limit = 10) {
  const day = cstDay();
  const stop = new Set(["我们", "你们", "他们", "什么", "这个", "那个", "不是", "就是", "可以", "一个", "现在", "然后", "因为", "所以", "但是", "没有", "自己", "知道", "觉得", "真的", "时候", "已经", "还是", "今天", "有点", "怎么"]);
  const freq = new Map();
  for (const h of history()) {
    if (cstDay(h.ts) !== day) continue;
    const t = norm(h.text);
    for (let n = 2; n <= 4; n++) for (let i = 0; i + n <= t.length; i++) {
      const w = t.slice(i, i + n);
      if (/^[0-9a-z]+$/.test(w) || stop.has(w)) continue;
      freq.set(w, (freq.get(w) || 0) + 1);
    }
  }
  const arr = [...freq.entries()].filter(([, c]) => c >= 3).sort((a, b) => b[1] - a[1]);
  const out = [];
  for (const [w] of arr) {
    if (out.some((x) => x.includes(w) || w.includes(x))) continue;
    out.push(w);
    if (out.length >= limit) break;
  }
  return out;
}

// ---------- 提示词增量 ----------
export function hintBits(st, who, banned) {
  const bits = [];
  const tk = todayKeywords(8);
  if (tk.length) bits.push("今天已经聊过的关键词（尽量别再碰）：" + tk.join("、") + "。");
  const cool = cooldowns().map((x) => x.word).slice(0, 6);
  if (cool.length) bits.push("这些话题最近聊腻了，先别碰：" + cool.join("、") + "。");
  const t = nextTopic(st, who);
  if (t) bits.push("这一条可以聊这个（换个新鲜的）：「" + t.text + "」，别原样念，用你自己的话说。");
  bits.push("你的关注点偏：" + FOCUS[who].join("、") + "；别抢别人的话题。");
  // 句式限制
  const sk = st.sk || {};
  const today = sk.day === cstDay() ? sk.count : {};
  const hot = Object.entries(today).filter(([, c]) => c >= 3).map(([k]) => k.split("|")[0]).filter((x) => x.length >= 2);
  if (hot.length) bits.push("这些开头今天用太多次了，换一种开头：" + hot.slice(0, 4).join("、") + "。");
  if (banned && banned.length) bits.push("别再提这些词：" + banned.join("、") + "。");
  return bits.join("");
}

// ---------- 一句话通过检查 ----------
export function ok(text, st, maxSim = 0.5) {
  const t = String(text || "").trim();
  if (t.length < 2) return { ok: false, why: "too-short" };
  // 1) 近 60 条（bot.mjs 维护）
  const recent = (st.recent || []).slice(-60);
  for (const r of recent) if (sim(r, t) >= maxSim) return { ok: false, why: "recent-sim" };
  // 2) 当天/前一天历史（最多 600 条）
  const now = Date.now();
  for (const h of history()) {
    if (now - (h.ts || 0) > 36 * 3600e3) continue;
    if (sim(h.text, t) >= maxSim) return { ok: false, why: "hist-sim:" + String(h.text).slice(0, 12) };
  }
  // 3) 句式上限
  const sk = skeleton(t);
  const day = cstDay();
  const cnt = (st.sk && st.sk.day === day ? st.sk.count : {})[sk] || 0;
  if (cnt >= 4) return { ok: false, why: "skeleton" };
  // 4) 冷却词：单个只是软提示（不拦），一句话里同时撞上两个以上才算又绕回老话题
  const nt = norm(t);
  const hits = [];
  for (const c of cooldowns()) if (nt.includes(norm(c.word))) hits.push(c.word);
  if (hits.length >= 2) return { ok: false, why: "cooldown:" + hits.slice(0, 3).join("+") };
  return { ok: true, why: "" };
}

export function remember(st, who, text) {
  const day = cstDay();
  if (!st.sk || st.sk.day !== day) st.sk = { day, count: {} };
  const sk = skeleton(text);
  st.sk.count[sk] = (st.sk.count[sk] || 0) + 1;
  const rec = { ts: Date.now(), who, text: String(text).slice(0, 200), sk };
  try { fs.appendFileSync(HIST, JSON.stringify(rec) + "\n"); } catch {}
  history().push(rec);
  if (history().length > 1500) { _hist = history().slice(-1000); try { fs.writeFileSync(HIST, _hist.map((x) => JSON.stringify(x)).join("\n") + "\n"); } catch {} }
}

// 兜底话术：40 句，避开 7 天内说过的
const FALLBACK = [
  "人呢，都去哪了", "有点饿了，谁陪我点个外卖", "刚看到一个视频笑死", "今天步数有点少，得动动",
  "外面好像要下雨了，窗户关没", "有人在吗，我有点无聊", "突然想吃甜的，谁懂", "今天谁洗的碗",
  "腰有点酸，是不是坐太久了", "手机快没电了，充电器在哪", "刚把桌子收拾了一遍，舒坦", "好想出去玩一天",
  "刚想起来一件事，差点忘了", "今天风好大，头发全乱了", "谁把我的耳机拿走了", "水杯空了，去接点水",
  "有点困，但不想睡", "刚刷到一只猫，好傻", "今天走了多少步来着", "想吃火锅但要攒钱",
  "有人在看那个新剧吗", "突然很想听歌", "衣柜里又没衣服穿了", "今天天真蓝",
  "刚才差点摔倒", "好想吃炸鸡，但怕胖", "谁借我点运", "发呆了一下午",
  "手指敲键盘敲麻了", "想喝冰的，但天太冷", "今天啥也没干，有点心虚", "刚打了个哈欠",
  "有段时间没一起熬夜了", "想给房间换个布置", "刚看到一条超好笑的评论", "有人陪我聊会儿吗",
  "今天好安静", "想吃点热的", "刚发现我袜子穿反了", "明天要不要一起吃个饭",
];
export function fallbacks(st, who) {
  const recent = (st.recent || []).slice(-40);
  const hist = history().filter((h) => Date.now() - (h.ts || 0) < 7 * 86400e3).map((h) => h.text);
  const pool = FALLBACK.filter((t) => !recent.some((r) => sim(r, t) > 0.6) && !hist.some((h) => sim(h, t) > 0.6));
  return (pool.length ? pool : FALLBACK).sort(() => Math.random() - 0.5).slice(0, 8);
}

// ---------- 自适应成长（每晚跑一次） ----------
const STOP = new Set(["我们", "你们", "他们", "什么", "这个", "那个", "不是", "就是", "可以", "一个", "现在", "然后", "因为", "所以", "但是", "没有", "自己", "知道", "觉得", "真的", "时候", "已经", "还是", "今天", "有点", "怎么", "就是", "好像", "真的"]);
function topWords(texts, n = 8) {
  const freq = new Map();
  for (const t of texts) {
    const s = norm(t);
    for (let k = 2; k <= 4; k++) for (let i = 0; i + k <= s.length; i++) {
      const w = s.slice(i, i + k);
      if (/^[0-9a-z]+$/.test(w) || STOP.has(w)) continue;
      freq.set(w, (freq.get(w) || 0) + 1);
    }
  }
  const arr = [...freq.entries()].filter(([, c]) => c >= 2).sort((a, b) => b[1] - a[1]);
  const out = [];
  for (const [w, c] of arr) {
    if (out.some((x) => x.word.includes(w) || w.includes(x.word))) continue;
    out.push({ word: w, n: c });
    if (out.length >= n) break;
  }
  return out;
}

export function grow(day = cstDay()) {
  const hist = history().filter((h) => cstDay(h.ts) === day);
  if (!hist.length) return { ok: false, why: "no history" };
  const byWho = {};
  for (const who of Object.keys(NAMES)) byWho[who] = hist.filter((h) => h.who === who).map((h) => h.text);
  const report = { day, at: new Date().toISOString(), who: {}, dupRate: 0, topics: todayKeywords(12) };

  // 重复率：相邻 5 条内的最高相似度 > 0.55 视为重复
  let dup = 0;
  for (let i = 0; i < hist.length; i++) {
    for (let j = Math.max(0, i - 5); j < i; j++) {
      if (sim(hist[i].text, hist[j].text) > 0.55) { dup++; break; }
    }
  }
  report.dupRate = hist.length ? +(dup / hist.length).toFixed(3) : 0;

  for (const who of Object.keys(NAMES)) {
    const texts = byWho[who];
    if (!texts.length) continue;
    const prevFile = path.join(GDIR, who + ".json");
    const prev = readJson(prevFile, { words: [] });
    const words = topWords(texts, 8);
    const prevSet = new Set((prev.words || []).map((x) => x.word));
    const fresh = words.filter((w) => !prevSet.has(w.word)).slice(0, 4);
    const skCount = new Map();
    for (const t of texts) { const s = skeleton(t); skCount.set(s, (skCount.get(s) || 0) + 1); }
    const overSk = [...skCount.entries()].filter(([, c]) => c >= 5).map(([k]) => k.split("|")[0]).slice(0, 4);
    const note = {
      day,
      words,
      fresh: fresh.map((x) => x.word),
      overSkeleton: overSk,
      lines: texts.length,
      avgLen: +(texts.reduce((a, t) => a + t.length, 0) / texts.length).toFixed(1),
    };
    writeJson(prevFile, note);
    // 冷却：今天聊太多的词，未来 48h 少提
    for (const w of words.slice(0, 3)) if (w.n >= 6) addCooldown(w.word, 48);
    // 生成给提示词用的小纸条（200 字内）
    const md = [
      "# " + NAMES[who] + " · 最近的变化（" + day + "）",
      "",
      "- 今天说了 " + texts.length + " 句，平均 " + note.avgLen + " 字",
      "- 新出现的词：" + (fresh.map((x) => x.word).join("、") || "无"),
      "- 高频词（别老围着它们转）：" + words.slice(0, 5).map((x) => x.word + "×" + x.n).join("、"),
      "- 句式用旧了：" + (overSk.join("、") || "无"),
      "",
      "【明天试着】把关注点往「" + FOCUS[who].join(" / ") + "」之外挪一点，多问家长一句他那边的具体事。",
    ].join("\n");
    try { fs.writeFileSync(path.join(GDIR, who + ".md"), md); } catch {}
    report.who[who] = { lines: texts.length, fresh: note.fresh, overSkeleton: overSk };
  }
  writeJson(path.join(QDIR, "daily-" + day + ".json"), report);
  const rep = [
    "# 小屋质量日报 " + day,
    "",
    "- 机器人发言：" + hist.length + " 句",
    "- 重复率（相邻 5 句内 >0.55）：**" + (report.dupRate * 100).toFixed(1) + "%**",
    "- 今日话题词：" + (report.topics.join("、") || "无"),
    "",
    "| 谁 | 句数 | 新词 | 用旧句式 |",
    "|---|---|---|---|",
    ...Object.entries(report.who).map(([w, x]) => "| " + NAMES[w] + " | " + x.lines + " | " + (x.fresh.join("、") || "—") + " | " + (x.overSkeleton.join("、") || "—") + " |"),
  ].join("\n");
  try { fs.writeFileSync(path.join(QDIR, "report-" + day + ".md"), rep); } catch {}
  return { ok: true, report };
}

// 给提示词用：她最近的变化（100 字内）
export function notes(who) {
  try {
    const n = readJson(path.join(GDIR, who + ".json"), null);
    if (!n) return "";
    const bits = [];
    if (n.fresh && n.fresh.length) bits.push("最近学会的新词：" + n.fresh.join("、"));
    if (n.overSkeleton && n.overSkeleton.length) bits.push("这些开头别再用了：" + n.overSkeleton.join("、"));
    if (!bits.length) return "";
    return "【你最近的变化】" + bits.join("；") + "。往新的方向长一点。";
  } catch { return ""; }
}

// ---------- CLI ----------
if (process.argv[1] && /quality\.mjs$/.test(process.argv[1])) {
  const cmd = process.argv[2] || "status";
  const day = process.argv[3] || cstDay();
  if (cmd === "plan") console.log(JSON.stringify(planTopics(day).cards.slice(0, 8), null, 1));
  else if (cmd === "grow") console.log(JSON.stringify(grow(day), null, 1));
  else if (cmd === "report") console.log(fs.readFileSync(path.join(QDIR, "report-" + day + ".md"), "utf8"));
  else console.log(JSON.stringify({ hist: history().length, cooldowns: cooldowns(), today: todayKeywords(10) }, null, 1));
}