#!/data/data/com.termux/files/usr/bin/sh
# T2 云镜像：每小时把 familyroom/data 的「变化文件」打包推到腾讯云备份仓
# 云端 /box/backup 只保留 10 份（按名字排序删最旧），所以命名必须能排序 = 时间在名字里
# 每月 1 号 00:xx 额外做一次全量 latest-full.tgz 覆盖（提供恢复基点）
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
export HOME=/data/data/com.termux/files/home
H=$HOME/familyroom
D=$H/data
ST=$H/mirror
LOG=$H/mirror.log
CURL=/data/data/com.termux/files/usr/bin/curl
TAR=/data/data/com.termux/files/usr/bin/tar
BOX=http://203.0.113.10/box
KEY=change-me-box-key

mkdir -p "$ST"
[ -d "$D" ] || { echo "$(date '+%F %T') no data dir" >> "$LOG"; exit 0; }

# 网络不通就别浪费时间（3 秒超时）
$CURL -s -m 3 -o /dev/null "$BOX/health" || { echo "$(date '+%F %T') skip: cloud unreachable" >> "$LOG"; exit 0; }

NOW=$(date +%s)
HOUR=$(date +%H)
DAY=$(date +%d)
STAMP=$ST/last.stamp
NAME=$(date '+mirror-%Y%m%d-%H').tgz
OUT=$ST/$NAME

# 全量基点：没有基点 / 每月 1 号 / 基点超过 30 天
NEED_FULL=0
[ -e "$ST/base.stamp" ] || NEED_FULL=1
if [ "$DAY" = "01" ] && [ "$HOUR" = "03" ]; then NEED_FULL=1; fi
if [ -e "$ST/base.stamp" ]; then
  BASE_T=$(cat "$ST/base.stamp" 2>/dev/null || echo 0)
  case "$BASE_T" in ''|*[!0-9]*) BASE_T=0 ;; esac
  [ $((NOW - BASE_T)) -gt 2592000 ] && NEED_FULL=1
fi

if [ "$NEED_FULL" = "1" ]; then
  OUT=$ST/latest-full.tgz
  NAME=latest-full.tgz
  $TAR -czf "$OUT" -C "$H" data 2>/dev/null
  echo "$NOW" > "$ST/base.stamp"
  touch "$ST/last.stamp"
else
  # 增量：比 stamp 新的文件（stamp 不存在就当全部）
  if [ -e "$STAMP" ]; then
    LIST=$ST/changed.lst
    find "$D" -type f -newer "$STAMP" > "$LIST" 2>/dev/null
    CNT=$(wc -l < "$LIST" 2>/dev/null | tr -d ' ')
    case "$CNT" in ''|*[!0-9]*) CNT=0 ;; esac
    if [ "$CNT" = "0" ]; then
      echo "$(date '+%F %T') skip: no change" >> "$LOG"
      exit 0
    fi
    $TAR -czf "$OUT" -C "$H" $(sed "s#^$H/##" "$LIST") 2>/dev/null
  else
    $TAR -czf "$OUT" -C "$H" data 2>/dev/null
  fi
fi

[ -s "$OUT" ] || { echo "$(date '+%F %T') tar failed" >> "$LOG"; exit 1; }
BYTES=$(stat -c %s "$OUT" 2>/dev/null || echo 0)

if $CURL -s -m 120 -X POST --data-binary @"$OUT" "$BOX/backup?key=$KEY&name=$NAME" -o "$ST/resp.json"; then
  echo "$(date '+%F %T') pushed $NAME $BYTES bytes -> $(cat "$ST/resp.json" 2>/dev/null)" >> "$LOG"
  touch "$ST/last.stamp"
  [ "$NEED_FULL" = "1" ] || rm -f "$OUT"
else
  echo "$(date '+%F %T') fail push $NAME $BYTES bytes" >> "$LOG"
fi

# 本地只留最近 24 个临时包 + 日志 200 行
ls -1t "$ST"/mirror-*.tgz 2>/dev/null | tail -n +25 | while read -r f; do rm -f "$f"; done
[ -f "$LOG" ] && { tail -n 200 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"; }
exit 0