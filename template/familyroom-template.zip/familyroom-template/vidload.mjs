// vidload.mjs —— 三姐妹自己去 B 站搬「小鱼」相关视频进小剧院
// 用法：node vidload.mjs [--n 1] [--kw "自定义关键词"] [--dry]
// 环境：ROOM(=http://127.0.0.1:8660) ROOM_PASS(家长密码，默认读 data/admin-pass.txt) VID_DIR(=data/videos)
import fs from "node:fs";
import path from "node:path";

const HERE = path.dirname(new URL(import.meta.url).pathname);
const DATA = process.env.ROOM_DATA || path.join(HERE, "data");
const VID_DIR = path.join(DATA, "videos");
const VJSON = path.join(DATA, "videos.json");
const ROOM = process.env.ROOM || "http://127.0.0.1:8660";

const argv = process.argv.slice(2);
function flag(name, def) { const i = argv.indexOf("--" + name); return i >= 0 ? (argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[i + 1] : true) : def; }
const N = Math.max(1, Math.min(3, Number(flag("n", 1)) || 1));
const DRY = !!flag("dry", false);
const MAXMB = 45;
const KWS = [
  "小鱼", "蓝色小鱼", "小鱼 表情包", "小鱼 桌宠", "小鱼 教程",
  "鲸鱼 拟人 AI", "DeepSeek 小鱼", "小鱼 日常", "肥鱼 弹幕",
];

const UA = "Mozilla/5.0 (Linux; Android 13; RMX3708) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";
const jar = new Map();
const cookieStr = () => [...jar.entries()].map(([k, v]) => k + "=" + v).join("; ");
function eat(res) {
  const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  for (const c of sc) { const m = /^([^=]+)=([^;]*)/.exec(c); if (m) jar.set(m[1], m[2]); }
}
async function bget(url, extra = {}) {
  const r = await fetch(url, {
    headers: { "user-agent": UA, "accept-language": "zh-CN,zh;q=0.9", referer: "https://www.bilibili.com/", ...(jar.size ? { cookie: cookieStr() } : {}), ...extra },
    redirect: "follow",
  });
  eat(r);
  return r;
}
async function bjson(url) {
  const r = await bget(url, { accept: "application/json, text/plain, */*" });
  const t = await r.text();
  try { return JSON.parse(t); } catch { return { code: -999, message: "not json", head: t.slice(0, 120) }; }
}
const dur2s = (s) => { const p = String(s || "0:0").split(":").map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : p[0] || 0; };
const strip = (s) => String(s || "").replace(/<[^>]+>/g, "").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();

function known() {
  try { return new Set((JSON.parse(fs.readFileSync(VJSON, "utf8")) || []).map((v) => String(v.bvid || "")).filter(Boolean)); } catch { return new Set(); }
}
async function login() {
  // 1) 优先用机器人自己的 token（family 身份，最有权限）
  for (const f of ["bot-token.txt"]) {
    try {
      const t = fs.readFileSync(path.join(DATA, f), "utf8").trim();
      if (t.length > 20) return t;
    } catch {}
  }
  // 2) 退化为家长账号登录
  let pass = process.env.ROOM_PASS || "";
  if (!pass) { try { pass = fs.readFileSync(path.join(DATA, "admin-pass.txt"), "utf8").trim(); } catch {} }
  for (const name of ["家长", "laoda"]) {
    const r = await fetch(ROOM + "/api/login", { method: "POST", headers: { "content-type": "application/json", "user-agent": "vidload/1.0" }, body: JSON.stringify({ name, pass }) });
    const j = await r.json().catch(() => ({}));
    if (j && j.ok && j.token) return j.token;
  }
  return "";
}

async function main() {
  const token = await login();
  if (!token && !DRY) { console.log("login failed"); process.exit(2); }
  await bget("https://www.bilibili.com/");           // 拿 buvid3
  const seen = known();
  const picks = [];
  const kwlist = flag("kw", "") ? [String(flag("kw", ""))] : KWS.slice().sort(() => Math.random() - 0.5);
  for (const kw of kwlist) {
    if (picks.length >= N) break;
    const s = await bjson("https://api.bilibili.com/x/web-interface/search/type?search_type=video&page=1&keyword=" + encodeURIComponent(kw));
    const list = (s && s.data && s.data.result) || [];
    for (const v of list) {
      if (picks.length >= N) break;
      if (!v || !v.bvid || seen.has(v.bvid)) continue;
      const ds = dur2s(v.duration);
      if (ds < 8 || ds > 600) continue;             // 8 秒~10 分钟
      if (Number(v.play || 0) < 500) continue;
      if (picks.some((p) => p.bvid === v.bvid)) continue;
      picks.push({ bvid: v.bvid, title: strip(v.title), dur: ds, play: Number(v.play || 0), kw });
    }
  }
  if (!picks.length) { console.log("no candidates"); return; }
  fs.mkdirSync(VID_DIR, { recursive: true });
  for (const p of picks) {
    try {
      const view = await bjson("https://api.bilibili.com/x/web-interface/view?bvid=" + p.bvid);
      const d = view && view.data;
      if (!d || !d.cid) { console.log("skip(no cid)", p.bvid); continue; }
      const pu = await bjson("https://api.bilibili.com/x/player/playurl?bvid=" + p.bvid + "&cid=" + d.cid + "&qn=32&fnval=1&platform=html5&high_quality=1");
      const du = pu && pu.data && pu.data.durl && pu.data.durl[0];
      if (!du || !du.url) { console.log("skip(no url)", p.bvid, pu && pu.message); continue; }
      const sizeMB = (du.size || 0) / 1048576;
      if (sizeMB > MAXMB) { console.log("skip(big)", p.bvid, sizeMB.toFixed(1) + "MB"); continue; }
      const fname = "bili_" + p.bvid + ".mp4";
      const dst = path.join(VID_DIR, fname);
      if (DRY) { console.log("DRY would fetch", p.bvid, p.title, sizeMB.toFixed(1) + "MB", du.url.slice(0, 60)); continue; }
      const r = await fetch(du.url, { headers: { "user-agent": UA, referer: "https://www.bilibili.com/", ...(jar.size ? { cookie: cookieStr() } : {}) } });
      if (!r.ok) { console.log("dl fail", p.bvid, r.status); continue; }
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length < 100 * 1024) { console.log("too small", p.bvid, buf.length); continue; }
      fs.writeFileSync(dst, buf);
      const rr = await fetch(ROOM + "/api/video/ingest", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: "Bearer " + token, "user-agent": "vidload/1.0" },
        body: JSON.stringify({ file: fname, title: p.title, bvid: p.bvid, dur: p.dur, play: p.play, srcUrl: "https://www.bilibili.com/video/" + p.bvid }),
      });
      const jj = await rr.json().catch(() => ({}));
      console.log("ingested", p.bvid, fname, (buf.length / 1048576).toFixed(1) + "MB", "=>", jj.ok ? "ok" : JSON.stringify(jj).slice(0, 120));
    } catch (e) {
      console.log("err", p.bvid, String(e && e.message || e).slice(0, 120));
    }
  }
}
main().catch((e) => { console.log("fatal", String(e && e.stack || e).slice(0, 300)); process.exit(1); });