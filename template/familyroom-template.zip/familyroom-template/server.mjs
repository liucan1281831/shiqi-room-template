
// ---------- v1.42 游戏厅数据 ----------
const GAMES = [
  { id: "memory", name: "记忆翻牌", max: 1000, desc: "配对三姐妹，步数越少分越高" },
  { id: "puzzle", name: "家庭拼图", max: 1000, desc: "3×3 拼回家庭照片，步数越少分越高" },
  { id: "gomoku", name: "五子棋", max: 1000, desc: "和妹妹下一局，赢了加分" },
  { id: "g2048", name: "2048", max: 1000, desc: "合并数字，分数越高越好" },
  { id: "snake", name: "贪吃蛇", max: 1000, desc: "吃满屏，活得越久分越高" },
];
function gamesFile() { return path.join(DATA, "games.json"); }
function gamesDB() {
  try { return JSON.parse(fs.readFileSync(gamesFile(), "utf8")) || {}; } catch { return {}; }
}
function saveGames(db) {
  try {
    const tmp = gamesFile() + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, gamesFile());
  } catch (e) { /* 忽略写失败，不影响聊天 */ }
}
function rankRows(db, gid, n) {
  const m = db[gid] || {};
  return Object.keys(m)
    .map((k) => ({ who: k, name: m[k].name || k, best: m[k].best || 0, plays: m[k].plays || 0 }))
    .filter((r) => r.best > 0)
    .sort((a, b) => b.best - a.best)
    .slice(0, n);
}

// family-room/server.mjs v3 —— 家庭小屋：多用户 + 申请审批 + 频道隔离
// 监听 0.0.0.0:8660，无第三方依赖。
//
// 结构：
//   data/accounts.json     账号（family=家人 / visitor=访客，status=pending|active|rejected）
//   data/sessions.json     token -> accountId
//   data/bot-token.txt     机器人密钥（server 首次启动自动生成）
//   data/msgs/<channel>/<date>.jsonl   每个频道按天存储
//   data/applications.json 申请与投票
//
// 频道：
//   family      家庭小屋（只有家人可见，访客永远看不到）
//   v<accountId> 每个访客一条独立频道（访客只看得到自己的）
import http from "node:http";
import https from "node:https";
import zlib from "node:zlib";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import net from "node:net";
import { execFile, execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { attachCall } from "./call-rt.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DATA = process.env.ROOM_DATA ? path.resolve(process.env.ROOM_DATA) : path.join(HERE, "data");
const MSGS = path.join(DATA, "msgs");
// v45: jsonl 结果缓存（按 mtime+size 失效），解决 /api/moments、/api/diaries 每次全量重读
const JSONL_CACHE = new Map();
function readJsonlCached(dir, file) {
  const fp = path.join(dir, file);
  let st;
  try { st = fs.statSync(fp); } catch { return []; }
  const c = JSONL_CACHE.get(fp);
  if (c && c.mtimeMs === st.mtimeMs && c.size === st.size) return c.rows;
  const rows = [];
  try {
    for (const ln of fs.readFileSync(fp, "utf8").split("\n")) {
      const t = ln.trim();
      if (!t) continue;
      try { rows.push(JSON.parse(t)); } catch {}
    }
  } catch {}
  JSONL_CACHE.set(fp, { mtimeMs: st.mtimeMs, size: st.size, rows });
  return rows;
}
const UPLOADS = path.join(DATA, "uploads");

// ---------- v1.41 小剧院（短视频） ----------
const VID_DIR = path.join(DATA, "videos");
const CLOUD_BASE = (process.env.ROOM_CLOUD_BASE || "https://203.0.113.10").replace(/\/+$/, "");
const CLOUD_BOX_KEY = process.env.ROOM_CLOUD_KEY || "change-me-box-key";
const CLOUD_VIDEO_BASE = CLOUD_BASE + "/videos/";

// 视频上云（异步、失败不影响本地）
async function cloudUploadVideo(abs, fname) {
  try {
    const st = fs.statSync(abs);
    if (!st.size || st.size > 300 * 1024 * 1024) return "";
    const buf = fs.readFileSync(abs);
    const r = await fetch(CLOUD_BASE + "/box/video?name=" + encodeURIComponent(fname), {
      method: "POST",
      headers: { "x-box-key": CLOUD_BOX_KEY, "content-type": "application/octet-stream" },
      body: buf,
    });
    if (!r.ok) return "";
    const j = await r.json().catch(() => null);
    if (!j || !j.ok) return "";
    return CLOUD_VIDEO_BASE + fname;
  } catch (e) { return ""; }
}

function patchVideoCloud(id, url) {
  try {
    const l = readVideos();
    const it = l.find((x) => x.id === id);
    if (it && !it.cloud) { it.cloud = url; writeVideos(l); }
  } catch (e) {}
}

const VID_JSON = path.join(DATA, "videos.json");
fs.mkdirSync(VID_DIR, { recursive: true });
function readVideos() {
  try { return JSON.parse(fs.readFileSync(VID_JSON, "utf8")); } catch { return []; }
}
function writeVideos(list) {
  try { fs.writeFileSync(VID_JSON, JSON.stringify(list.slice(0, 600), null, 0)); } catch {}
}
function vidKey(it) { return String(it.id || ""); }
// 表情库：直接用手机微信那套（微信 Agent 的 memes 目录，80 个系列 / 500+ 张）
const STICKER_DIR = process.env.STICKER_DIR || "/storage/emulated/0/Android/data/com.tencent.mm/files/WechatAi/memes";
const RECORDS = path.join(DATA, "records");
const MIME = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
  ".wav": "audio/wav", ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".ogg": "audio/ogg", ".opus": "audio/ogg",
  ".mp4": "video/mp4", ".m4v": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime", ".3gp": "video/3gpp" };
const PORT = Number(process.env.ROOM_PORT || 8660);
// v33：版本 / 检查更新（网页 + APK 共用一份 VERSION 与 release.json）
const VERSION_FILE = path.join(HERE, "VERSION");
const WEB_VERSION = (() => { try { return fs.readFileSync(VERSION_FILE, "utf8").trim().split(/\s+/)[0]; } catch { return "1.3.0"; } })();
const RELEASE_DIR = path.join(DATA, "releases");
const APK_FILE = path.join(RELEASE_DIR, "familyroom.apk");
const OLD_APK_DIR = path.join(DATA, "releases", "old");
const RELEASE_JSON = path.join(RELEASE_DIR, "release.json");
function versionInfo() {
  let rel = {};
  try { rel = JSON.parse(fs.readFileSync(RELEASE_JSON, "utf8")) || {}; } catch {}
  let size = 0, mtime = "";
  try { const st = fs.statSync(APK_FILE); size = st.size; mtime = new Date(st.mtimeMs).toISOString(); } catch {}
  const v = String(rel.apkVersion || WEB_VERSION);
  return {
    ok: true,
    web: WEB_VERSION,
    apkVersion: v,
    apkVersionCode: Number(rel.apkVersionCode || 0),
    apkUrl: size ? "/download/familyroom.apk" : (rel.apkUrl || ""),
    apkSize: size,
    apkSha256: rel.sha256 || "",
    apkBuiltAt: rel.builtAt || mtime,
    notes: Array.isArray(rel.notes) ? rel.notes : (rel.notes ? [String(rel.notes)] : []),
    github: rel.github || "",
    publishedAt: rel.publishedAt || "",
  };
}
const FAMILY_CHANNEL = "family";
// v27：家长与大姐的一对一私聊（工作频道），只有家长能进，访客看不到
// v37：给二姐、三姐也各开一个私聊（左列依次排开），三个妹妹各自独立
const DM_CHANNEL = "dm_laoda_shiqi";
const DM_LIST = [
  { id: "dm_laoda_shiqi", who: "shiqi", title: "私聊 · 大姐", note: "工作频道 · 只有你能看" },
  { id: "dm_laoda_jiu", who: "jiu", title: "私聊 · 二姐", note: "私聊 · 只有你能看" },
  { id: "dm_laoda_hutao", who: "hutao", title: "私聊 · 三姐", note: "私聊 · 只有你能看" },
];
const DM_IDS = DM_LIST.map((d) => d.id);
function dmOf(channel) { return DM_LIST.find((d) => d.id === channel) || null; }

fs.mkdirSync(DATA, { recursive: true });
fs.mkdirSync(MSGS, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });

const WHO = {
  shiqi: { name: "大姐", color: "#7cc4ff", tag: "电脑·大姐" },
  jiu: { name: "二姐", color: "#ff8fb1", tag: "手机微信·二姐" },
  hutao: { name: "三姐", color: "#ffd166", tag: "家里·小妹" },
  laoda: { name: "家长", color: "#9be89b", tag: "主人" },
};
const SISTERS = ["shiqi", "jiu", "hutao"];

// ---------- 基础工具 ----------
function readJson(file, dflt) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return dflt; }
}
function writeJson(file, val) {
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(val, null, 2));
  fs.renameSync(tmp, file);
}
const SHARE_FILE = path.join(DATA, "shares.json");
let _shares = null;
function shares() {
  if (_shares) return _shares;
  try { _shares = JSON.parse(fs.readFileSync(SHARE_FILE, "utf8")); } catch { _shares = []; }
  if (!Array.isArray(_shares)) _shares = [];
  return _shares;
}
function saveShares(list) {
  _shares = Array.isArray(list) ? list : [];
  try { fs.mkdirSync(DATA, { recursive: true }); fs.writeFileSync(SHARE_FILE, JSON.stringify(_shares)); } catch {}
}
function todayStr() { return new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10); }

// ---------- v1.24：已读回执 ----------
const READS = path.join(DATA, "reads");
function readsFile(ch) { return path.join(READS, String(ch).replace(/[^a-zA-Z0-9_-]/g, "_") + ".json"); }
function loadReads(ch) {
  try { return JSON.parse(fs.readFileSync(readsFile(ch), "utf8")) || {}; } catch { return {}; }
}
function saveReads(ch, obj) {
  try { fs.mkdirSync(READS, { recursive: true }); fs.writeFileSync(readsFile(ch), JSON.stringify(obj)); } catch {}
}

function hashPass(pass, salt) {
  return crypto.scryptSync(String(pass), salt, 32).toString("hex");
}
function newToken() { return crypto.randomBytes(24).toString("hex"); }
function cookieOf(t) { return "room_token=" + t + "; Path=/; Max-Age=" + (180 * 86400) + "; SameSite=Lax"; }
function clean(s, n = 200) { return String(s == null ? "" : s).replace(/[\u0000-\u001f]/g, "").trim().slice(0, n); }

// ---------- v34 访客开关 ----------
const SETTINGS_FILE = path.join(DATA, "settings.json");
// v126 P0-4: 纪念日 / 家规
const ANNIV_FILE = path.join(DATA, "anniversary.json");
const PINS_FILE = path.join(DATA, "pins.json");
function loadJsonArr(fp) {
  try { const a = JSON.parse(fs.readFileSync(fp, "utf8")); return Array.isArray(a) ? a : []; } catch { return []; }
}
function saveJsonArr(fp, arr) { try { fs.mkdirSync(path.dirname(fp), { recursive: true }); fs.writeFileSync(fp, JSON.stringify(arr, null, 1)); } catch {} }
function annivItems() {
  const now = new Date(Date.now() + 8 * 3600e3);
  const out = [];
  for (const a of loadJsonArr(ANNIV_FILE)) {
    const dstr = String(a.date || "");
    const md = dstr.slice(5, 10);
    let base = new Date(now.getFullYear() + "-" + md + "T00:00:00Z");
    if (isNaN(base.getTime())) continue;
    const today = new Date(now.toISOString().slice(0, 10) + "T00:00:00Z");
    let diff = Math.round((base - today) / 864e5);
    if (diff < 0) { base = new Date((now.getFullYear() + 1) + "-" + md + "T00:00:00Z"); diff = Math.round((base - today) / 864e5); }
    out.push({ id: a.id, title: a.title, date: dstr, note: a.note || "", yearly: a.yearly !== false, daysLeft: diff, dueToday: diff === 0 });
  }
  out.sort((x, y) => x.daysLeft - y.daysLeft);
  return out;
}

function settings() {
  const q2 = (readJson(SETTINGS_FILE, null) || {}).notifyQuiet || {};
  const s = readJson(SETTINGS_FILE, null) || {};
  const q = (s.quiet && typeof s.quiet === "object") ? s.quiet : {};
  return {
    allowGuest: s.allowGuest !== false,
    // v1.16: 免打扰时段（本地时间小时，左闭右开；from==to 视为关闭）
    quiet: { enabled: q.enabled === true, from: Number.isFinite(+q.from) ? +q.from : 23, to: Number.isFinite(+q.to) ? +q.to : 8 },
    // v127: 通知免打扰（默认 23:00–08:00 只在 @我/私聊 时响），与「禁言时段」独立
    notifyQuiet: {
      enabled: (q2.enabled === undefined ? true : q2.enabled === true),
      from: Number.isFinite(+q2.from) ? +q2.from : 23,
      to: Number.isFinite(+q2.to) ? +q2.to : 8,
    },
  };
}
function saveSettings(patch) {
  const cur = readJson(SETTINGS_FILE, null) || {};
  writeJson(SETTINGS_FILE, Object.assign({}, cur, patch, { updatedAt: Date.now() }));
}
function guestAllowed() { return settings().allowGuest; }
function inQuiet() {
  const q = settings().quiet;
  if (!q.enabled || q.from === q.to) return false;
  const h = new Date(Date.now() + 8 * 3600e3).getUTCHours();
  return q.from < q.to ? (h >= q.from && h < q.to) : (h >= q.from || h < q.to);
}

// v127: 通知是否该响（"m"=@我/私聊必响；"q"=免打扰时段静默；""=正常）
function notifyQuiet() {
  const nq = settings().notifyQuiet || {};
  const from = Number.isFinite(+nq.from) ? +nq.from : 23;
  const to = Number.isFinite(+nq.to) ? +nq.to : 8;
  if (nq.enabled === false || from === to) return false;
  const h = new Date(Date.now() + 8 * 3600e3).getUTCHours();
  return from < to ? (h >= from && h < to) : (h >= from || h < to);
}
function notifyTag(channel, msg) {
  if (String(channel || "").indexOf("dm_") === 0) return "m";
  const ms = Array.isArray(msg && msg.mentions) ? msg.mentions : [];
  if (ms.indexOf("家长") >= 0 || ms.indexOf("所有人") >= 0) return "m";
  return notifyQuiet() ? "q" : "";
}

// ---------- 账号与会话 ----------
const ACC_FILE = path.join(DATA, "accounts.json");
const SES_FILE = path.join(DATA, "sessions.json");
const APP_FILE = path.join(DATA, "applications.json");
const BOT_FILE = path.join(DATA, "bot-token.txt");
const RULES_FILE = path.join(DATA, "rules.json");
const DEFAULT_RULES = {
  speakerMaxPerMin: 1,     // 每人每分钟最多几条（家长不受限；v45 家长定：三姐妹每人 1 分钟 1 条）
  speakerMaxPerHour: 60,   // 每人每小时最多几条
  stickerMaxPerMin: 2,     // 每人每分钟最多几个表情
  drawMaxPerDay: 5,        // 每人每天最多画几张
  stickerMaxPer10Min: 2,   // v10 旧字段，保留兼容
  topicDedupePerDay: true, // 话题每天不重复
  guestTopicFollow: true,  // 访客提话题就跟着聊
  noRepeat: true,          // 三姐妹之间不准重复
  updatedAt: 0, by: ""
};
let rules = Object.assign({}, DEFAULT_RULES, readJson(RULES_FILE, {}));
if (!(rules.speakerMaxPerHour > 0)) rules.speakerMaxPerHour = DEFAULT_RULES.speakerMaxPerHour;
if (!(rules.stickerMaxPerMin > 0)) rules.stickerMaxPerMin = DEFAULT_RULES.stickerMaxPerMin;
if (!(rules.drawMaxPerDay > 0)) rules.drawMaxPerDay = DEFAULT_RULES.drawMaxPerDay;
// v19 一次性迁移：旧的「每人每分钟 4 条」默认值 → 2 条（家长在 2026-10-23 的新规则）
if (!rules.rulesVersion) {
  rules.speakerMaxPerMin = DEFAULT_RULES.speakerMaxPerMin;
  rules.rulesVersion = 2;
  try { writeJson(RULES_FILE, rules); } catch {}
}
// v45 迁移：家长把上限压到「每人每分钟 1 条」（2026-10-25）
if (rules.rulesVersion < 3) {
  rules.speakerMaxPerMin = 1;
  rules.rulesVersion = 3;
  try { writeJson(RULES_FILE, rules); } catch {}
}

// ---------- v30：三姐妹音色参数（在小屋界面可改，bot 合成语音时读取） ----------
// voice = qwen3-tts-flash 的音色 id；rate = 语速倍率；pitch = 音高半音；volume = 增益
const VOICE_FILE = path.join(DATA, "voice.json");
const VOICE_TIMBRES = ["Cherry", "Serena", "Chelsie", "Ethan", "Chelsie"];
const DEFAULT_VOICE = {
  shiqi: { voice: "Cherry", rate: 0.97, pitch: -1, volume: 1.0, note: "大姐：温柔偏低，语速略慢" },
  jiu: { voice: "Serena", rate: 1.03, pitch: 1, volume: 1.05, note: "二姐：清亮俏皮，语速略快" },
  hutao: { voice: "Chelsie", rate: 1.0, pitch: 2, volume: 1.0, note: "小妹：软糯偏高，一点点奶音" },
};
function clampN(v, lo, hi, dflt) { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt; }
function normVoice(raw) {
  const out = {};
  for (const who of ["shiqi", "jiu", "hutao"]) {
    const d = DEFAULT_VOICE[who];
    const v = (raw && raw[who]) || {};
    out[who] = {
      voice: VOICE_TIMBRES.includes(String(v.voice)) ? String(v.voice) : d.voice,
      rate: clampN(v.rate, 0.8, 1.25, d.rate),
      pitch: clampN(v.pitch, -6, 6, d.pitch),
      volume: clampN(v.volume, 0.5, 1.5, d.volume),
      note: clean(v.note == null ? d.note : v.note, 60),
    };
  }
  return out;
}
let voice = normVoice(readJson(VOICE_FILE, {}));
try { writeJson(VOICE_FILE, voice); } catch {}

// v36：/api/metrics 的 20 秒缓存
let METRICS_CACHE = null;

// v1253: HTTP 统计（QPS / 平均延迟 / 错误率），滑动 60 秒窗口
const HTTP_STAT = { t0: Date.now(), total: 0, e4: 0, e5: 0, sumMs: 0, maxMs: 0, byPath: {}, win: [] };
function httpStatNote(p, ms, code) {
  const s = HTTP_STAT;
  s.total++;
  s.sumMs += ms;
  if (ms > s.maxMs) s.maxMs = ms;
  if (code >= 500) s.e5++;
  else if (code >= 400) s.e4++;
  const key = String(p || "/").replace(/\/[A-Za-z0-9_-]{16,}$/, "/:id");
  const b = s.byPath[key] || (s.byPath[key] = { n: 0, ms: 0, e: 0 });
  b.n++; b.ms += ms; if (code >= 400) b.e++;
  const now = Date.now();
  s.win.push({ t: now, ms, code });
  while (s.win.length && now - s.win[0].t > 60000) s.win.shift();
}
function httpStatSnap() {
  const s = HTTP_STAT;
  const win = s.win;
  const spanSec = Math.max(1, Math.min(60, (Date.now() - s.t0) / 1000));
  const qps60 = win.length / 60;
  const ms60 = win.length ? Math.round(win.reduce((a, x) => a + x.ms, 0) / win.length) : 0;
  const err60 = win.filter((x) => x.code >= 400).length;
  const top = Object.entries(s.byPath).sort((a, b) => b[1].n - a[1].n).slice(0, 8)
    .map(([p, v]) => ({ path: p, n: v.n, avgMs: Math.round(v.ms / Math.max(1, v.n)), err: v.e }));
  return {
    upSec: Math.round((Date.now() - s.t0) / 1000),
    total: s.total,
    avgMs: Math.round(s.sumMs / Math.max(1, s.total)),
    maxMs: s.maxMs,
    errRate: s.total ? Number((((s.e4 + s.e5) / s.total) * 100).toFixed(2)) : 0,
    e4: s.e4, e5: s.e5,
    qps60: Number(qps60.toFixed(3)),
    ms60, err60, spanSec: Math.round(spanSec),
    top,
  };
}

// v19：绘画配额与点名豁免
const MOM_DIR = path.join(DATA, "moments");
// v47: 动态的点赞 / 评论（按 who:ts 作为 key，存 data/moment-meta.json）
const MOM_META = path.join(DATA, "moment-meta.json");
function loadMomMeta() {
  try { return JSON.parse(fs.readFileSync(MOM_META, "utf8")) || {}; } catch { return {}; }
}
let _momMetaCache = { at: 0, data: null };
function momMeta() {
  const st = (() => { try { return fs.statSync(MOM_META).mtimeMs; } catch { return 0; } })();
  if (!_momMetaCache.data || _momMetaCache.at !== st) { _momMetaCache = { at: st, data: loadMomMeta() }; }
  return _momMetaCache.data;
}
function saveMomMeta(m) {
  try { fs.writeFileSync(MOM_META, JSON.stringify(m)); } catch {}
  _momMetaCache = { at: 0, data: null };
}
const momKey = (x) => String(x.key || (String(x.who || "") + ":" + String(x.ts || 0)));
const DIARY_DIR = path.join(DATA, "diaries"); // v40
const ROOMS_FILE = path.join(DATA, "rooms.json");
const ALLOWED_ITEMS = new Set(["bedDouble","bedSingle","bedBunk","loungeSofa","loungeSofaLong","loungeSofaCorner","loungeChair","loungeChairRelax","bench","desk","deskCorner","table","tableCoffee","tableCoffeeGlass","tableRound","chair","chairDesk","chairRounded","stoolBar","sideTable","sideTableDrawers","computerScreen","computerKeyboard","computerMouse","laptop","televisionModern","televisionVintage","speaker","speakerSmall","radio","kitchenMicrowave","kitchenFridge","lampRoundFloor","lampRoundTable","lampSquareFloor","lampSquareTable","lampSquareCeiling","lampWall","ceilingFan","plantSmall1","plantSmall2","plantSmall3","pottedPlant","rugRectangle","rugRound","rugRounded","rugSquare","rugDoormat","bookcaseOpen","bookcaseOpenLow","bookcaseClosed","bookcaseClosedWide","books","cardboardBoxClosed","cardboardBoxOpen","trashcan","pillow","pillowBlue","bear","coatRack","coatRackStanding","kitchenSink","kitchenStove","kitchenCabinet","kitchenBar","bathroomSink","bathtub","toilet","washer","doorwayOpen"]);
try { fs.mkdirSync(MOM_DIR, { recursive: true }); } catch {}
try { fs.mkdirSync(DIARY_DIR, { recursive: true }); } catch {}
const DRAWS_FILE = path.join(DATA, "draws.json");
let drawsLog = readJson(DRAWS_FILE, []);
function pruneDraws() { const cut = Date.now() - 26 * 3600e3; const before = drawsLog.length; drawsLog = drawsLog.filter((d) => d.ts > cut); if (drawsLog.length !== before) writeJson(DRAWS_FILE, drawsLog); }
function drawsToday(speaker) {
  pruneDraws();
  const day = cstParts().day;
  return drawsLog.filter((d) => d.speaker === speaker && new Date(d.ts + 8 * 3600e3).toISOString().slice(0, 10) === day).length;
}
function noteDraw(speaker) { drawsLog.push({ speaker, ts: Date.now() }); pruneDraws(); writeJson(DRAWS_FILE, drawsLog); }
const drawExempt = new Map();
function grantDrawExempt(key) { if (key) drawExempt.set(key, Date.now() + 180000); }
function takeDrawExempt(key) {
  const t = drawExempt.get(key);
  if (!t) return false;
  if (Date.now() > t) { drawExempt.delete(key); return false; }
  drawExempt.delete(key);
  return true;
}
function saveRules() { writeJson(RULES_FILE, rules); }
const recentSays = []; // {speaker, ts, sticker}
function pruneRecent() { const cut = Date.now() - 65 * 60e3; while (recentSays.length && recentSays[0].ts < cut) recentSays.shift(); }
function speakerOf(me, who) {
  if (me.role === "bot") return WHO[who] ? who : "shiqi";
  if (me.role === "family") return "laoda";
  return "guest:" + me.id;
}
// 返回 {ok:true} 或 {ok:false, err, limited}
function checkLimit(me, speaker, sticker, draw, force) {
  if (force && !sticker && !draw) return { ok: true, exempt: true };
  if (me.role === "family") return { ok: true };   // 家长不受限
  if (me.role === "visitor") return { ok: true };  // v45/v1.38 家长定：访客不受任何发言限制（频率、表情、绘画全放开）
  pruneRecent();
  const now = Date.now();
  const mine = recentSays.filter((r) => r.speaker === speaker);
  // 家长点名 @某人 要图/表情 → 该人当次不受限
  if ((sticker || draw) && takeDrawExempt(speaker)) return { ok: true, exempt: true };
  // v143：表情不占「发言条数」额度（之前表情被 speaker 限流挡住，一天 35 次失败）
  const mineText = mine.filter((r) => !r.sticker);
  if (rules.speakerMaxPerMin > 0) {
    const perMin = mineText.filter((r) => now - r.ts < 60e3).length;
    if (perMin >= rules.speakerMaxPerMin) return { ok: false, limited: "speaker", err: `发太密了：每人每分钟最多 ${rules.speakerMaxPerMin} 条` };
  }
  if (rules.speakerMaxPerHour > 0) {
    const perHour = mineText.filter((r) => now - r.ts < 3600e3).length;
    if (perHour >= rules.speakerMaxPerHour) return { ok: false, limited: "speakerHour", err: `先歇会儿：每人每小时最多 ${rules.speakerMaxPerHour} 条` };
  }
  if (sticker && rules.stickerMaxPerMin > 0) {
    const sMin = mine.filter((r) => r.sticker && now - r.ts < 60e3).length;
    if (sMin >= rules.stickerMaxPerMin) return { ok: false, limited: "sticker", err: `表情太密：每分钟最多 ${rules.stickerMaxPerMin} 个` };
  }
  if (draw && rules.drawMaxPerDay > 0) {
    const dn = drawsToday(speaker);
    if (dn >= rules.drawMaxPerDay) return { ok: false, limited: "draw", err: `今天画够了：每人每天最多 ${rules.drawMaxPerDay} 张` };
  }
  return { ok: true };
}
function noteSay(speaker, sticker) { recentSays.push({ speaker, ts: Date.now(), sticker: !!sticker }); pruneRecent(); }
// 把家长话里的命令解析成规则
function applyRuleCommands(text) {
  const out = [];
  const t = String(text || "");
  let m;
  if ((m = t.match(/(\d+)\s*分钟\s*内?\s*每\s*人?\s*最?多\s*(?:发)?\s*(\d+)\s*条/))) { m = [m[0], m[2]]; }
  else if ((m = t.match(/每\s*人?\s*(?:每)?\s*分钟\s*最?多\s*(?:发)?\s*(\d+)\s*条/))) { }
  else if ((m = t.match(/一分钟内\s*最?多\s*(?:发)?\s*(\d+)\s*条/))) { }
  if (m) {
    rules.speakerMaxPerMin = Number(m[1]); out.push({ name: "每人每分钟最多", value: m[1] + " 条" });
  }
  if ((m = t.match(/表情\s*(\d+)\s*分钟[^0-9]{0,8}(\d+)\s*个/)) && Number(m[1]) === 10) {
    rules.stickerMaxPer10Min = Number(m[2]); out.push({ name: "表情每10分钟最多", value: m[2] + " 个" });
  } else if ((m = t.match(/表情[^0-9]{0,10}(\d+)\s*(?:个|张)/)) && /10\s*分钟|十分钟/.test(t)) {
    rules.stickerMaxPer10Min = Number(m[1]); out.push({ name: "表情每10分钟最多", value: m[1] + " 个" });
  }
  if (/话题.*(不|别).*(重复|一样)/.test(t)) { rules.topicDedupePerDay = true; out.push({ name: "话题每天不重复", value: "开" }); }
  if (/访客.{0,6}(提出|说起|提到)?.{0,4}话题/.test(t) && /(接着|跟着|顺着)/.test(t)) { rules.guestTopicFollow = true; out.push({ name: "访客提的话题要接着聊", value: "开" }); }
  if (/(三姐妹|你们三个|姐妹们).{0,12}(不准|不许|不能).{0,10}重复/.test(t) || /各自.{0,6}人设/.test(t)) { rules.noRepeat = true; out.push({ name: "三姐妹不重复、各按人设", value: "开" }); }
  if ((m = t.match(/(?:每|一)\s*小时[^0-9]{0,8}(\d+)\s*条/)) || (m = t.match(/(?:每|一)?\s*小时\s*内?\s*每\s*人?\s*最?多\s*(?:发)?\s*(\d+)\s*条/))) {
    rules.speakerMaxPerHour = Number(m[1]); out.push({ name: "每人每小时最多", value: m[1] + " 条" });
  }
  if ((m = t.match(/表情[^0-9]{0,10}(?:每|一)?\s*分钟[^0-9]{0,8}(\d+)\s*(?:个|张)/))) {
    rules.stickerMaxPerMin = Number(m[1]); out.push({ name: "表情每分钟最多", value: m[1] + " 个" });
  }
  if ((m = t.match(/(?:每|一)?\s*天[^0-9]{0,12}(?:绘画|画画|画图|画)[^0-9]{0,8}(\d+)\s*(?:张|幅)/)) || (m = t.match(/(?:绘画|画画|画图)[^0-9]{0,12}(?:每|一)?\s*天[^0-9]{0,8}(\d+)\s*(?:张|幅)/))) {
    rules.drawMaxPerDay = Number(m[1]); out.push({ name: "每天绘画最多", value: m[1] + " 张" });
  }
  if (out.length) { rules.updatedAt = Date.now(); rules.by = "laoda"; saveRules(); }
  return out;
}
function rulesText() {
  return `每人每分钟最多 ${rules.speakerMaxPerMin} 条、每小时最多 ${rules.speakerMaxPerHour} 条；表情每分钟最多 ${rules.stickerMaxPerMin} 个；每天绘画最多 ${rules.drawMaxPerDay} 张（家长点名要图的那个人当次不受限）；`
    + `${rules.topicDedupePerDay ? "话题每天不重复" : "话题不限"}；${rules.guestTopicFollow ? "访客提的话题要接着聊" : ""}；${rules.noRepeat ? "三姐妹不重复、各按人设" : ""}`;
}

// ---------- v17: 禁言时段（0:00-7:00 北京时间）----------
const MUTE_FROM = 0, MUTE_TO = 7;
function cstParts() {
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  return { h: d.getUTCHours(), day: d.toISOString().slice(0, 10) };
}
function inMute() { const h = cstParts().h; return h >= MUTE_FROM && h < MUTE_TO; }
function muteUntilText() { return "07:00"; }

// ---------- v17: 头像 ----------
const AVDIR = path.join(DATA, "avatars");
const DEFAULT_AVDIR = path.join(HERE, "assets-avatars"); // 内置默认头像（随包发布）
function avFile(who) {
  for (const ext of ["jpg", "png", "webp"]) {
    const f = path.join(AVDIR, who + "." + ext);
    if (fs.existsSync(f)) return f;
  }
  return "";
}
function avUrl(who) {
  const f = avFile(who);
  if (!f) return "";
  try { return "/api/avatar/" + who + "?v=" + Math.floor(fs.statSync(f).mtimeMs); } catch { return "/api/avatar/" + who; }
}
function whoPayload() {
  const out = {};
  for (const k of Object.keys(WHO)) out[k] = Object.assign({}, WHO[k], { avatar: avUrl(k) });
  out._mute = inMute();
  return out;
}


let accounts = readJson(ACC_FILE, []);
let sessions = readJson(SES_FILE, {});
let applications = readJson(APP_FILE, []);

if (!fs.existsSync(BOT_FILE)) fs.writeFileSync(BOT_FILE, newToken() + "\n");
const BOT_TOKEN = fs.readFileSync(BOT_FILE, "utf8").trim();

function saveAccounts() { writeJson(ACC_FILE, accounts); }
function saveSessions() { writeJson(SES_FILE, sessions); }
function saveApps() { writeJson(APP_FILE, applications); }

// 访客记录归档：visitors/<id>/<date>.jsonl（离线/手动都能触发，尽力传 PC）
function uploadToPc(name, text) {
  try {
    const rq = http.request({ hostname: "127.0.0.1", port: 8000, path: "/up/" + encodeURIComponent(name),
      method: "POST", timeout: 4000,
      headers: { "content-type": "application/octet-stream", "content-length": Buffer.byteLength(text) } },
      (r) => r.resume());
    rq.on("timeout", () => rq.destroy());
    rq.on("error", () => {});
    rq.end(text);
  } catch {}
}
function archiveVisitor(acc, force) {
  try {
    if (!acc || acc.role !== "visitor" || acc.share === false) return { ok: false, skipped: "no-share" };
    const c2 = "v" + acc.id;
    const date = todayStr();
    const all = readDay(c2, date);
    if (!all.length) return { ok: false, skipped: "empty" };
    const dir = path.join(DATA, "visitors", String(acc.id));
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, date + ".jsonl");
    const text = all.map((m) => JSON.stringify({ ...m, date })).join("\n") + "\n";
    const prev = fs.existsSync(file) ? fs.readFileSync(file, "utf8").split("\n").length - 1 : 0;
    const nowN = all.length;
    if (!force && nowN <= prev) return { ok: true, skipped: "up-to-date", lines: prev };
    fs.writeFileSync(file, text);
    uploadToPc("visitor-" + acc.id + "-" + date + ".jsonl", text);
    return { ok: true, file: "visitors/" + acc.id + "/" + date + ".jsonl", lines: nowN, size: fs.statSync(file).size };
  } catch (e) { return { ok: false, err: String((e && e.message) || e) }; }
}

function ensureFamily() {
  // 家人账号：家长是 admin；密码首次生成并写 admin-pass.txt，之后可用 /api/passwd 改
  const admin = accounts.find((a) => a.role === "family" && a.id === "laoda");
  if (admin) return;
  const passFile = path.join(HERE, "admin-pass.txt");
  const pass = fs.existsSync(passFile)
    ? fs.readFileSync(passFile, "utf8").trim()
    : crypto.randomBytes(6).toString("hex");
  fs.writeFileSync(passFile, pass + "\n");
  const salt = newToken();
  accounts.push({
    id: "laoda", name: "家长", role: "family", who: "laoda", identity: "主人",
    salt, pass: hashPass(pass, salt), status: "active", createdAt: Date.now(),
  });
  saveAccounts();
}
ensureFamily();

function auth(req) {
  const h = String(req.headers.authorization || "");
  let t = h.startsWith("Bearer ") ? h.slice(7).trim() : "";
  if (!t) {
    // v1.48: 外部脚本可用 `token: <48位>` 或 `x-dsh-token: <48位>` 请求头
    const th = String(req.headers["token"] || req.headers["x-dsh-token"] || "").trim();
    if (th) t = th;
  }
  if (!t) {
    // EventSource 不能带 header，允许 query 传 token
    try { t = String(new URL(req.url, "http://x").searchParams.get("token") || "").trim(); } catch {}
  }
  if (!t) {
    // 浏览器 cookie（180 天），localStorage 被清也能自动恢复
    const ck = String(req.headers.cookie || "");
    const m = ck.match(/(?:^|;\s*)room_token=([a-f0-9]{48})/);
    if (m) t = m[1];
  }
  if (!t) return null;
  if (t === BOT_TOKEN) return { id: "bot", name: "bot", role: "bot" };
  const s = sessions[t];
  if (!s || s.exp < Date.now()) return null;
  const acc = accounts.find((a) => a.id === s.accountId);
  if (!acc || acc.status !== "active") return null;
  return { ...acc, token: t };
}

// v1.31: 让 <iframe>/子资源用 Referer 里的 token 通过门禁（APK 的 WebView 里 cookie 可能被当三方 cookie 拦掉）
function authFromReferer(req) {
  try {
    const r = String(req.headers.referer || "");
    if (!r) return null;
    if (!/room_token=[a-f0-9]{48}/.test(String(req.headers.cookie || "")) && !/[?&]token=[a-f0-9]{48}/.test(r)) return null;
    return auth({ url: r, headers: req.headers });
  } catch { return null; }
}

function accPublic(a) {
  return { id: a.id, name: a.name, role: a.role, who: a.who || null, identity: a.identity || "", share: a.share !== false };
}

// ---------- 消息存储（按频道/按天） ----------
function chanDir(channel) {
  const safe = channel.replace(/[^a-zA-Z0-9_-]/g, "_");
  const d = path.join(MSGS, safe);
  fs.mkdirSync(d, { recursive: true });
  return d;
}
// T4: 支持 <date>.jsonl.gz（旧消息归档后仍可读）
function dayFileList(dir) {
  let files = [];
  try { files = fs.readdirSync(dir).filter((f) => /^\d{4}-\d{2}-\d{2}\.jsonl(\.gz)?$/.test(f)).sort(); } catch {}
  return files;
}
function dayBase(f) { return f.replace(/\.jsonl(\.gz)?$/, ""); }
function readDayText(dir, f) {
  try {
    if (f.endsWith(".gz")) return zlib.gunzipSync(fs.readFileSync(path.join(dir, f))).toString("utf8");
    return fs.readFileSync(path.join(dir, f), "utf8");
  } catch { return ""; }
}
// P0: 解析结果缓存（按 mtime+size 校验，命中时省掉整文件 JSON.parse）
const _dayCache = new Map();
function readDay(channel, date) {
  const dir = chanDir(channel);
  let st = null;
  try { st = fs.statSync(path.join(dir, date + ".jsonl")); } catch {}
  const ck = channel + "|" + date;
  if (st) {
    const hit = _dayCache.get(ck);
    if (hit && hit.mtimeMs === st.mtimeMs && hit.size === st.size) return hit.arr;
  } else {
    _dayCache.delete(ck);
  }
  const arr = readDayRaw(channel, date);
  if (st) _dayCache.set(ck, { mtimeMs: st.mtimeMs, size: st.size, arr });
  return arr;
}
function readDayRaw(channel, date) {
  const dir = chanDir(channel);
  let txt = readDayText(dir, date + ".jsonl");
  if (!txt) txt = readDayText(dir, date + ".jsonl.gz");
  if (!txt) return [];
  const out = [];
  for (const ln of txt.split("\n")) {
    const s = ln.trim();
    if (!s) continue;
    try { out.push(JSON.parse(s)); } catch {}
  }
  return out;
}
function append(channel, msg) {
  try { if (!msg.nf) msg.nf = notifyTag(channel, msg); } catch (e) {}
  fs.appendFileSync(path.join(chanDir(channel), todayStr() + ".jsonl"), JSON.stringify(msg) + "\n");
}
// “重新开一段聊天”：只对访客频道生效，记一个时间戳，之后只显示这之后的消息（旧记录不删）
function resetFile(channel) { return path.join(chanDir(channel), ".reset"); }
function resetTs(channel) {
  try { return Number(fs.readFileSync(resetFile(channel), "utf8").trim()) || 0; } catch { return 0; }
}

// ---------- 访问控制 ----------
function canSeeChannel(acc, channel) {
  if (!acc) return false;
  if (acc.role === "family" || acc.role === "bot") {
    return channel === FAMILY_CHANNEL || /^v[a-z0-9]+$/.test(channel) || channel === "lobby" || DM_IDS.includes(channel);
  }
  if (acc.role === "visitor") return channel === "v" + acc.id || channel === "lobby";
  return false;
}

// ---------- SSE ----------
// ---- 在线状态（SSE 连接 + 妹妹发言/心跳）----
const sseIds = new Set();
const botSeen = new Map();
function bumpBot(who) {
  const w = String(who || "");
  if (SISTERS.includes(w)) botSeen.set(w, Date.now());
}
function presenceIds() {
  const now = Date.now();
  const out = new Set(sseIds);
  for (const [w, ts] of botSeen) if (now - ts < 150000) out.add(w);
  try {
    const msgs = readDay(FAMILY_CHANNEL, todayStr()).slice(-60);
    for (const m of msgs) {
      const w = String(m.who || "");
      if (SISTERS.includes(w) && now - Number(m.ts || 0) < 150000) out.add(w);
    }
  } catch {}
  try {
    const a = accounts.find((x) => x.id === "laoda");
    if (a && a.lastSeen && now - a.lastSeen < 150000) out.add("laoda");
  } catch {}
  return [...out];
}
function broadcastPresence() {
  let evt = "";
  try { evt = "data: " + JSON.stringify({ type: "presence", online: presenceIds(), ts: Date.now() }) + "\n\n"; } catch { return; }
  for (const c of clients) { try { c.res.write(evt); } catch {} }
}

// ---- 压缩发送：公网隧道下压小 HTML/JSON，明显降首屏与消息延迟 ----
function acceptsGzip(req) { return /\bgzip\b/.test(String((req && req.headers && req.headers["accept-encoding"]) || "")); }
function sendC(req, res, code, payload, type = "application/json; charset=utf-8") {
  let buf = Buffer.isBuffer(payload) ? payload
    : Buffer.from(typeof payload === "string" ? payload : JSON.stringify(payload), "utf8");
  const h = { "content-type": type, "cache-control": "no-store" };
  if (buf.length > 800 && acceptsGzip(req)) {
    try { buf = zlib.gzipSync(buf, { level: 6 }); h["content-encoding"] = "gzip"; h["vary"] = "accept-encoding"; } catch {}
  }
  h["content-length"] = String(buf.length);
  if (!res || typeof res.writeHead !== "function") {
    try { console.log("[sendC] bad res: " + (res && res.constructor && res.constructor.name)); } catch {}
    return;
  }
  res.writeHead(code, h);
  res.end(buf);
}

const clients = new Set(); // {res, channel, all?, sees?}

// v1.19: 某人能看到的全部频道（供「全域订阅」一条 SSE 拿所有频道的未读/@）
function visibleChannels(me) {
  const out = [];
  if (!me) return out;
  if (canSeeChannel(me, FAMILY_CHANNEL)) out.push(FAMILY_CHANNEL);
  try { for (const d of DM_LIST) if (canSeeChannel(me, d.id)) out.push(d.id); } catch {}
  if (canSeeChannel(me, "lobby")) out.push("lobby");
  if (me.role === "visitor" && me.id && canSeeChannel(me, me.id)) out.push(me.id);
  return out;
}

// ---------- v26：新消息系统通知（termux-notification，root 身份可发） ----------
const TERMUX_PREFIX = "/data/data/com.termux/files/usr";
const NOTIFY_ENV = Object.assign({}, process.env, {
  PREFIX: TERMUX_PREFIX,
  LD_LIBRARY_PATH: TERMUX_PREFIX + "/lib",
  PATH: TERMUX_PREFIX + "/bin:/system/bin:/system/xbin",
  HOME: "/data/data/com.termux/files/home",
  TMPDIR: TERMUX_PREFIX + "/tmp",
});
let lastNotifyAt = 0, lastNotifyKey = "";
function notifyChannelName(channel) {
  if (channel === FAMILY_CHANNEL) return "大屋";
  if (dmOf(channel)) return dmOf(channel).title;
  const acc = (typeof accounts !== "undefined" && Array.isArray(accounts))
    ? accounts.find((a) => a.id === channel) : null;
  return acc ? (acc.identity || "频道") : "小屋";
}
// v37：APK 的常驻通知服务每 60s 打一次心跳；心跳新鲜时不再用 Termux 通知（否则一条消息弹两遍）
let appNotifyUntil = 0;
function notifyPush(channel, msg) {
  if (String(process.env.ALLOW_TERMUX_NOTIFY || "") !== "1") return; // v1.20 默认关闭
  try {
    if (!msg || !msg.who) return;
    if (msg.who === "laoda") return;              // 自己在手机上发的不推
    if (Date.now() < appNotifyUntil) return;       // App 在，系统通知由 App 自己发（带正文/横幅）
    if (inQuiet()) return;                         // v1.16: 免打扰时段内不推送
    const now = Date.now();
    if (now - lastNotifyAt < 8000) return;         // 8s 全局节流
    const key = channel + "|" + msg.who;
    if (key === lastNotifyKey && now - lastNotifyAt < 60000) return;
    lastNotifyAt = now; lastNotifyKey = key;
    const title = channel.startsWith("dm_") ? notifyChannelName(channel) : ((msg.name || "小屋") + " · " + notifyChannelName(channel));
    let body = String(msg.text || "").replace(/\s+/g, " ").slice(0, 90);
    if (!body) body = msg.kind === "image" ? "[图片]" : msg.kind === "sticker" ? "[表情]" : msg.kind === "audio" ? "[语音]" : "[消息]";
    execFile(TERMUX_PREFIX + "/bin/termux-notification", [
      "--title", title, "--content", body, "--id", "7001", "--priority", "high",
      "--action", "am start -n com.dsh.familyroom/.MainActivity",
    ], { env: NOTIFY_ENV, timeout: 12000 }, () => {});
  } catch {}
}

function broadcast(channel, msg) {
  const one = "data: " + JSON.stringify(msg) + "\n\n";
  const all = "data: " + JSON.stringify(Object.assign({}, msg, { channel })) + "\n\n";
  for (const c of clients) {
    if (c.all) { if (c.sees && !c.sees.has(channel)) continue; try { c.res.write(all); } catch {} continue; }
    if (c.channel !== channel) continue;
    try { c.res.write(one); } catch {}
  }
  // v1.20: 通知只由 App 原生端（NotifyService）发，服务端不再用 termux-notification
}

// ---------- v38: 撤回 / 编辑 / 表情回应 / 搜索 ----------
// 只推 SSE，不触发通知（改动不是新消息）
function broadcastRaw(channel, obj) {
  const one = "data: " + JSON.stringify(obj) + "\n\n";
  const all = "data: " + JSON.stringify(Object.assign({}, obj, { channel })) + "\n\n";
  for (const c of clients) {
    if (c.all) { if (c.sees && !c.sees.has(channel)) continue; try { c.res.write(all); } catch {} continue; }
    if (c.channel !== channel) continue;
    try { c.res.write(one); } catch {}
  }
}
function mkey(m) { return [Number(m.ts || 0), String(m.who || "")].join("|"); }
function dayFiles(channel) {
  const dir = chanDir(channel);
  let files = [];
  files = dayFileList(dir);
  return files.slice(-40).reverse();
}
function findMsg(channel, key) {
  const dir = chanDir(channel);
  for (const f of dayFiles(channel)) {
    const fp = path.join(dir, f);
    let txt = "";
    txt = readDayText(dir, f);
    if (!txt) continue;
    const lines = txt.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const t = lines[i].trim();
      if (!t) continue;
      let m;
      try { m = JSON.parse(t); } catch { continue; }
      if (mkey(m) === key) return { fp, idx: i, msg: m };
    }
  }
  return null;
}
function rewriteMsg(hit, fn) {
  let txt = "";
  try { txt = fs.readFileSync(hit.fp, "utf8"); } catch { return null; }
  const lines = txt.split("\n");
  if (!lines[hit.idx]) return null;
  const m = fn(JSON.parse(lines[hit.idx]));
  lines[hit.idx] = JSON.stringify(m);
  fs.writeFileSync(hit.fp, lines.join("\n"));
  return m;
}
function iOwn(me, m) {
  if (!m) return false;
  if (me.role === "family") return true;
  return !!(m.accountId && String(m.accountId) === String(me.id));
}

const PAGE_PATH = path.join(HERE, "index.html");
let PAGE = fs.readFileSync(PAGE_PATH, "utf8");
let pageMtime = fs.statSync(PAGE_PATH).mtimeMs;
function page() {
  try {
    const st = fs.statSync(PAGE_PATH);
    if (st.mtimeMs !== pageMtime) { pageMtime = st.mtimeMs; PAGE = fs.readFileSync(PAGE_PATH, "utf8"); }
  } catch {}
  return PAGE;
}
const STATIC = {
  "/manifest.webmanifest": ["application/manifest+json; charset=utf-8", "manifest.webmanifest"],
  "/sw.js": ["application/javascript; charset=utf-8", "sw.js"],
  "/icon.svg": ["image/svg+xml", "icon.svg"],
};

// ---------- v42: 在线状态页 ----------
const STATUS_PATH = path.join(HERE, "status.html");
let STATUS_PAGE = "";
let statusMtime = 0;
try { STATUS_PAGE = fs.readFileSync(STATUS_PATH, "utf8"); statusMtime = fs.statSync(STATUS_PATH).mtimeMs; } catch {}
function statusPage() {
  try {
    const st = fs.statSync(STATUS_PATH);
    if (st.mtimeMs !== statusMtime) { statusMtime = st.mtimeMs; STATUS_PAGE = fs.readFileSync(STATUS_PATH, "utf8"); }
  } catch {}
  return STATUS_PAGE;
}
function portOpen(port, ms) {
  return new Promise((resolve) => {
    let done = false;
    const fin = (v) => { if (done) return; done = true; try { s.destroy(); } catch {} resolve(v); };
    const s = net.connect({ port: Number(port), host: "127.0.0.1" });
    s.setTimeout(ms || 700);
    s.on("connect", () => fin(true));
    s.on("timeout", () => fin(false));
    s.on("error", () => fin(false));
  });
}
const MSGCOUNT = { ts: 0, n: 0 };
function countMsgsAll() {
  const now = Date.now();
  if (now - MSGCOUNT.ts < 30000) return MSGCOUNT.n;
  let n = 0;
  try {
    for (const d of fs.readdirSync(MSGS)) {
      const dir = path.join(MSGS, d);
      let st;
      try { st = fs.statSync(dir); } catch { continue; }
      if (!st.isDirectory()) continue;
      let files = [];
      try { files = fs.readdirSync(dir); } catch { continue; }
      for (const f of dayFileList(dir)) {
        const t = readDayText(dir, f);
        for (const ln of t.split("\n")) if (ln.trim()) n++;
      }
    }
  } catch {}
  MSGCOUNT.ts = now; MSGCOUNT.n = n;
  return n;
}

// ---------- 3D 小家（/house/ 静态目录；由 PC 端 house-sync.ps1 推送） ----------
const HOUSE_DIR = path.join(HERE, "house");
const HOUSE_GZ = new Map(); // abs -> {mtimeMs, buf, gz, type}
const HOUSE_MIME = {
  ".webm": "video/webm",
  ".mp4": "video/mp4",
  ".m4a": "audio/mp4",
  ".mp3": "audio/mpeg",
  ".ogg": "audio/ogg",
  ".wav": "audio/wav",
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".glb": "model/gltf-binary",
  ".gltf": "model/gltf+json",
  ".bin": "application/octet-stream",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ktx2": "image/ktx2",
  ".wasm": "application/wasm",
};
function houseRel(raw) {
  const parts = String(raw || "").split("/").filter(Boolean);
  if (!parts.length || parts.length > 8) return null;
  for (const q of parts) if (q === ".." || q === "." || /[\\\u0000]/.test(q)) return null;
  return parts.join("/");
}
function houseGz(abs, type) {
  let st;
  try { st = fs.statSync(abs); } catch { return null; }
  if (!st.isFile()) return null;
  const hit = HOUSE_GZ.get(abs);
  if (hit && hit.mtimeMs === st.mtimeMs && hit.size === st.size) return hit;
  let buf;
  try { buf = fs.readFileSync(abs); } catch { return null; }
  let gz = null;
  if (/^(text\/|application\/(javascript|json))/.test(type) && buf.length > 2048 && buf.length < 8 * 1024 * 1024) {
    try { gz = zlib.gzipSync(buf, { level: 6 }); } catch { gz = null; }
  }
  const rec = { mtimeMs: st.mtimeMs, size: st.size, buf, gz, type };
  HOUSE_GZ.set(abs, rec);
  if (HOUSE_GZ.size > 400) { const k = HOUSE_GZ.keys().next().value; HOUSE_GZ.delete(k); }
  return rec;
}
function serveHouse(req, res, rel) {
  const abs = path.join(HOUSE_DIR, rel);
  if (!abs.startsWith(HOUSE_DIR)) return send(res, 403, { ok: false });
  const type = HOUSE_MIME[path.extname(rel).toLowerCase()] || "application/octet-stream";
  const rec = houseGz(abs, type);
  if (!rec) return send(res, 404, { ok: false });
  const isHtml = /\.html$/.test(rel);
  const h = {
    "content-type": type,
    "cache-control": "private, max-age=0",   // 门禁：不许 Cloudflare/浏览器共享缓存（否则匿名也能拿到）
    "access-control-allow-origin": "*",
  };
  const ae = String(req.headers["accept-encoding"] || "");
  if (rec.gz && /gzip/.test(ae)) {
    h["content-encoding"] = "gzip";
    h["vary"] = "Accept-Encoding";
    h["content-length"] = rec.gz.length;
    res.writeHead(200, h);
    return res.end(rec.gz);
  }
  h["content-length"] = rec.buf.length;
  res.writeHead(200, h);
  return res.end(rec.buf);
}

function send(res, code, obj, type = "application/json; charset=utf-8") {
  // v41: APK 内置页（file://）跨域访问需要 CORS
  try {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "authorization,content-type,x-dsh-room");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    res.setHeader("Access-Control-Max-Age", "86400");
  } catch {}

  const txt = typeof obj === "string" ? obj : JSON.stringify(obj);
  // v1.16: 文本响应 gzip（页面/JSON 首屏从 116KB 降到 ~30KB）
  try {
    const ae = String((res.__req && res.__req.headers && res.__req.headers["accept-encoding"]) || "");
    if (txt.length >= 700 && /gzip/i.test(ae)) {
      const gz = zlib.gzipSync(Buffer.from(txt, "utf8"), { level: 6 });
      res.writeHead(code, { "content-type": type, "cache-control": "no-store", "content-encoding": "gzip", "content-length": gz.length, vary: "accept-encoding" });
      return res.end(gz);
    }
  } catch {}
  res.writeHead(code, { "content-type": type, "cache-control": "no-store" });
  res.end(txt);
}

function body(req) {
  return new Promise((resolve) => {
    let b = "";
    req.on("data", (c) => { b += c; if (b.length > 40_000_000) req.destroy(); });
    req.on("end", () => { try { resolve(JSON.parse(b || "{}")); } catch { resolve({}); } });
    req.on("error", () => resolve({}));
  });
}

// ---------- 图片 / 表情 ----------
function safeRel(rel) {
  const parts = String(rel || "").split("/").filter(Boolean);
  if (!parts.length || parts.length > 4) return null;
  for (const p2 of parts) if (p2 === ".." || p2 === "." || /[\\\u0000]/.test(p2)) return null;
  return parts.join("/");
}
function contentTypeOf(f) { return MIME[path.extname(f).toLowerCase()] || "application/octet-stream"; }
function serveFile(res, abs, type) {
  try {
    const st = fs.statSync(abs);
    res.writeHead(200, { "content-type": type, "content-length": st.size, "cache-control": "public, max-age=86400" });
    fs.createReadStream(abs).pipe(res);
  } catch { send(res, 404, { ok: false }); }
}
// ---------- v13：大图预览（缩略图） ----------
const THUMB_DIR = path.join(DATA, "thumbs");
const THUMB_SVC = process.env.THUMB_SVC || "http://127.0.0.1:8770";
const THUMB_MIN = 120 * 1024;   // 小于这个直接发原图
// v43b：手机单独跑时 PC 缩图服务不可用 → 用 Termux python3 + Pillow 本地缩（WebP 不支持，改 JPEG）
function localThumb(abs, w) {
  try {
    const py = process.env.PY3 || "/data/data/com.termux/files/usr/bin/python3";
    if (!fs.existsSync(py)) return null;
    const code = [
      "import sys,io",
      "from PIL import Image",
      "im=Image.open(sys.argv[1]).convert('RGB')",
      "w=int(sys.argv[2])",
      "im.thumbnail((w,w*3), Image.LANCZOS)",
      "b=io.BytesIO(); im.save(b,'JPEG',quality=78,optimize=True)",
      "sys.stdout.buffer.write(b.getvalue())",
    ].join("\n");
    const out = execFileSync(py, ["-c", code, abs, String(w)], { maxBuffer: 16 * 1024 * 1024, timeout: 20000 });
    return out && out.length > 1024 ? out : null;
  } catch { return null; }
}
async function makeThumb(abs, w) {
  try {
    const st = fs.statSync(abs);
    if (st.size <= THUMB_MIN) return null;
    const base = crypto.createHash("sha1").update(abs + ":" + st.size + ":" + Math.round(st.mtimeMs) + ":" + w).digest("hex").slice(0, 20);
    for (const ext of ["webp", "jpg"]) {
      const p0 = path.join(THUMB_DIR, base + "." + ext);
      if (fs.existsSync(p0)) return p0;
    }
    let ob = null, ext = "webp";
    try {
      const buf = fs.readFileSync(abs);
      const r = await fetch(THUMB_SVC + "/thumb?w=" + w + "&q=78&fmt=webp", {
        method: "POST", body: buf,
        headers: { "content-type": "application/octet-stream" },
        signal: AbortSignal.timeout(4000),
      });
      if (r.ok) ob = Buffer.from(await r.arrayBuffer());
    } catch {}
    if (!ob || ob.length < 1024) { ob = localThumb(abs, w); ext = "jpg"; }
    if (!ob || ob.length < 1024) return null;
    fs.mkdirSync(THUMB_DIR, { recursive: true });
    const tp = path.join(THUMB_DIR, base + "." + ext);
    fs.writeFileSync(tp, ob);
    return tp;
  } catch { return null; }
}
async function serveMedia(req, res, abs, type, url) {
  try {
    const st = fs.statSync(abs);
    const isImg = /^image\//.test(type || "");
    const raw = url.searchParams.get("raw") === "1";
    if (isImg && !raw && st.size > THUMB_MIN) {
      const w = Math.min(1440, Math.max(320, Number(url.searchParams.get("w") || 720) || 720));
      const tp = await makeThumb(abs, w);
      if (tp) {
        const tst = fs.statSync(tp);
        const ct = tp.endsWith(".webp") ? "image/webp" : "image/jpeg";
        res.writeHead(200, {
          "content-type": ct, "content-length": tst.size,
          "cache-control": "public, max-age=604800",
          "x-orig-bytes": String(st.size), "x-thumb": "1",
        });
        return fs.createReadStream(tp).pipe(res);
      }
    }
    const range = req.headers["range"];
    if (range) {
      const rm = /^bytes=(\d*)-(\d*)$/.exec(String(range).trim());
      if (rm) {
        let start = rm[1] ? parseInt(rm[1], 10) : 0;
        let end = rm[2] ? parseInt(rm[2], 10) : st.size - 1;
        if (isNaN(start) || start < 0) start = 0;
        if (isNaN(end) || end >= st.size) end = st.size - 1;
        if (start > end) { res.writeHead(416, { "content-range": "bytes */" + st.size }); return res.end(); }
        res.writeHead(206, {
          "content-type": type, "content-length": end - start + 1,
          "content-range": "bytes " + start + "-" + end + "/" + st.size,
          "accept-ranges": "bytes", "cache-control": "public, max-age=86400",
        });
        return fs.createReadStream(abs, { start: start, end: end }).pipe(res);
      }
    }
    res.writeHead(200, { "content-type": type, "content-length": st.size, "accept-ranges": "bytes", "cache-control": "public, max-age=86400" });
    fs.createReadStream(abs).pipe(res);
  } catch { send(res, 404, { ok: false }); }
}
function saveMedia(channel, dataUrl, name) {
  const raw = String(dataUrl || "");
  let buf = null, ext = ".jpg";
  let isVid = /^data:video\//i.test(raw.slice(0, 40));
  const m2 = /^data:(image|video)\/([a-z0-9+.-]+);base64,(.+)$/i.exec(raw);
  if (m2) {
    const e = m2[2].toLowerCase();
    ext = "." + (e === "jpeg" ? "jpg" : e);
    buf = Buffer.from(m2[3], "base64");
    if (m2[1].toLowerCase() === "video") isVid = true;
  } else {
    buf = Buffer.from(raw, "base64");
    const e = path.extname(String(name || "")).toLowerCase();
    if (MIME[e]) ext = e;
    if (e === ".mp4" || e === ".mov" || e === ".webm" || e === ".m4v" || e === ".3gp") isVid = true;
  }
  const limit = isVid ? 25 * 1024 * 1024 : 4 * 1024 * 1024;
  if (!buf || !buf.length || buf.length > limit) return null;
  const safeChan = channel.replace(/[^a-zA-Z0-9_-]/g, "_");
  const dir = path.join(UPLOADS, safeChan);
  fs.mkdirSync(dir, { recursive: true });
  const file = Date.now() + "_" + crypto.randomBytes(3).toString("hex") + ext;
  fs.writeFileSync(path.join(dir, file), buf);
  return safeChan + "/" + file;
}
// 表情语义匹配：句子里出现 k → 优先挑系列名匹配 s 的那几套（series 名里带中文/英文/emoji）
const STK_HINTS = [
  { k: /吃|饭|饿|火锅|外卖|奶茶|零食|夜宵|做饭|干饭|早餐|午饭|晚饭/, s: /吃|food|eat|鸡|鸭|鱼|daily|DeepSeekFish|鹦鹉|企鹅|火锅/i },
  { k: /睡|困|失眠|熬夜|晚安|打呼|早起/, s: /睡|sleep|夜|困|熊|企鹅|猫/i },
  { k: /游戏|开黑|上分|原神|王者|steam|主机|副本|排位/, s: /game|游戏|原神|JOJO|黑神话|女神异闻录|p5r|王者|Genshin/i },
  { k: /生气|烦|滚|怼|骂|破防|气死|讨厌|无语/, s: /生气|angry|怼|绿帽子|黑人抬棺|张翰|王老师|保国|吴刚|同福/i },
  { k: /可爱|萌|乖乖|撒娇|摸摸|撸猫|小猫|狗狗|好可爱/, s: /cute|cat|猫|girl|女孩|熊|鸭|狗|企鹅|panda/i },
  { k: /笑|哈哈|好笑|搞笑|沙雕|乐死|幽默|绷不住/, s: /funny|滑稽|笑|沙雕|斗图|Emoji|表情符号|FamousPerson/i },
  { k: /哭|难过|委屈|伤心|呜呜|难受|emo|破防了/, s: /哭|cry|sad|委屈|伤心|悲伤|Squirtle/i },
  { k: /累|上班|打工|加班|忙|工作|下班|开会|摸鱼/, s: /上班|程序|打工|班|work|job|摸鱼|躺|咸鱼/i },
  { k: /钱|穷|红包|转账|工资|买|花钱|剁手/, s: /钱|红包|转账|暴富|工资|coin|heart|心/i },
  { k: /冷|热|天气|下雨|刮风|冻|太阳/, s: /天气|冷|热|雨|雪|Frog/i },
  { k: /爱|喜欢|心|表白|抱抱|想你|亲亲/, s: /heart|心|爱|恋|情侣|抱|AllHeart/i },
  { k: /惊|吓|卧槽|震惊|离谱|真的假的/, s: /惊|震|what|黑人|奥特曼|柯南|News/i },
  { k: /牛|厉害|赞|强|666|崇拜|服了/, s: /赞|牛|强|猫|大拇指|Panda|张翰/i },
  { k: /猫|喵/, s: /cat|猫|三姐妹/i },
  { k: /狗|汪/, s: /dog|狗/i },
  { k: /鱼|鲸/, s: /fish|鱼|DeepSeekFish|DaFeiYu/i },
  { k: /鸡|鸭|鸟|鸽|鹅/, s: /鸡|鸭|鸟|鸽|parrot|pigeon|企鹅|Duck/i },
  { k: /画|画画|拍照|图/, s: /画|图|浏览器|WebBrowser/i },
  { k: /手机|充电|没电|电量|插座|断电/, s: /程序|程序员|浏览器|WebBrowser|Programmer/i },
  { k: /熬夜|失眠|睡不着|三点|半夜/, s: /熬夜|夜|睡|困|Panda|猫/i },
];
function stickerRank(list, q) {
  if (!q) return list;
  const hints = STK_HINTS.filter((h) => h.k.test(q));
  const scored = [];
  for (const it of list) {
    const name = (it.series + " " + it.file).toLowerCase();
    let sc = 0;
    for (const h of hints) if (h.s.test(name)) sc += 10;
    if (name.includes(q)) sc += 6;
    if (sc) scored.push({ sc, it });
  }
  if (!scored.length) return [];
  const best = Math.max(...scored.map((x) => x.sc));
  return scored.filter((x) => x.sc === best).map((x) => x.it);
}
let STK_CACHE = { at: 0, list: [] };
function stickerList() {
  const now = Date.now();
  if (STK_CACHE.list.length && now - STK_CACHE.at < 600_000) return STK_CACHE.list;
  const out = [];
  try {
    for (const d of fs.readdirSync(STICKER_DIR, { withFileTypes: true })) {
      if (!d.isDirectory()) continue;
      let files = [];
      try { files = fs.readdirSync(path.join(STICKER_DIR, d.name)); } catch { continue; }
      for (const f of files) if (MIME[path.extname(f).toLowerCase()]) out.push({ series: d.name, file: f });
    }
  } catch {}
  STK_CACHE = { at: now, list: out };
  return out;
}
function mediaMsg(me, channel, kind, rel, text, wantWho) {
  let who = me.role === "bot" ? "shiqi" : (me.role === "family" ? (me.who || "laoda") : "guest:" + me.id);
  if (wantWho && WHO[wantWho] && (me.role === "bot" || me.role === "family")) who = wantWho;
  const display = WHO[who] || { name: me.name, color: "#c9c9c9", tag: "访客" };
  const url = (kind === "sticker" ? "/sticker/" : "/media/") + rel.split("/").map(encodeURIComponent).join("/");
  const msg = {
    ts: Date.now(), who, name: display.name, color: display.color, tag: display.tag,
    text: text || (kind === "sticker" ? "[表情]" : kind === "audio" ? "[语音]" : kind === "video" ? "[视频]" : "[图片]"), kind, url, accountId: me.id,
  };
  append(channel, msg);
  broadcast(channel, msg);
  return msg;
}

function recordMeta(id) {
  try { return JSON.parse(fs.readFileSync(path.join(RECORDS, id + ".json"), "utf8")); } catch (e) { return null; }
}

// ---------- 审批 ----------
const IDENTITIES = ["学生", "上班族", "游戏玩家", "二次元", "夜猫子", "路过网友", "朋友", "其他"];

function voteSummary(app) {
  const votes = app.votes || {};
  const yes = Object.values(votes).filter((v) => v === "yes").length;
  const no = Object.values(votes).filter((v) => v === "no").length;
  return { yes, no, total: yes + no, votes };
}
function decideApp(app) {
  const v = voteSummary(app);
  if (app.status !== "pending") return app.status;
  const votes = app.votes || {};
  // 家长否决即拒绝；通过必须家长点头（yes）且家人两票以上同意、无人反对
  if (votes.laoda === "no") return "rejected";
  if (votes.laoda === "yes" && v.yes >= 2 && v.no === 0) return "active";
  return "pending";
}
function applyDecision(app) {
  const d = decideApp(app);
  if (d === app.status) return null;
  app.status = d;
  app.decidedAt = Date.now();
  const acc = accounts.find((a) => a.id === app.accountId);
  if (acc) acc.status = d;
  saveApps(); saveAccounts();
  return d;
}

// ---------- HTTP ----------
// ---------- v1.16: 状态历史（5 分钟一采样，保留 288 条 = 24h） ----------
const STATUS_HIST = path.join(DATA, "status-history.json");
function pushStatusSample() {
  try {
    const arr = readJson(STATUS_HIST, []);
    const list = Array.isArray(arr) ? arr : [];
    let msgsToday = 0;
    try { msgsToday = readDay(FAMILY_CHANNEL, todayStr()).length; } catch {}
    const mem = process.memoryUsage();
    list.push({
      ts: Date.now(), msgs: msgsToday,
      rssMB: Math.round((mem.rss || 0) / 1048576),
      online: (() => { try { return presenceIds().length; } catch { return 0; } })(),
    });
    while (list.length > 288) list.shift();
    writeJson(STATUS_HIST, list);
  } catch {}
}
pushStatusSample();
setInterval(pushStatusSample, 5 * 60_000);

// ---------- v126: 简易令牌桶限流（防脚本刷爆/前端误循环） ----------
const RL = new Map();
const RL_RULES = [
  { re: /^\/api\/say$/, win: 10000, max: 12 },
  { re: /^\/api\/upload$/, win: 60000, max: 20 },
  { re: /^\/api\/asr$/, win: 60000, max: 20 },
  { re: /^\/api\/search$/, win: 10000, max: 15 },
  { re: /^\/api\/login$/, win: 60000, max: 10 },
  { re: /^\/api\/register$/, win: 600000, max: 5 },
];
function rlKey(req, p) {
  const xf = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  const ip = xf || (req.socket && req.socket.remoteAddress) || "?";
  const tk = String(req.headers["authorization"] || "").slice(-10);
  return p + "|" + ip + "|" + tk;
}
function rateLimit(req, p) {
  const rule = RL_RULES.find((r) => r.re.test(p));
  if (!rule) return { ok: true };
  // v1.38 家长定：访客不受发言频率限制（家人放宽到 60 次/窗），只防脚本刷屏
  let cap = rule.max;
  try {
    const me = auth(req);
    if (me && me.role === "visitor") cap = 100000;
    else if (me && me.role === "family") cap = Math.max(cap, 60);
  } catch {}
  const k = rlKey(req, p);
  const now = Date.now();
  const e = RL.get(k) || { n: 0, ts: now };
  if (now - e.ts > rule.win) { e.n = 0; e.ts = now; }
  e.n++;
  RL.set(k, e);
  if (RL.size > 4000) { for (const [kk, vv] of RL) { if (now - vv.ts > 600000) RL.delete(kk); } }
  if (e.n > cap) return { ok: false, retryAfter: Math.ceil((rule.win - (now - e.ts)) / 1000) };
  return { ok: true };
}

// ================= P0-1：数据保险（导出 / 列表 / 下载）=================
const EXPORTS = path.join(path.dirname(DATA), "exports");
function ensureExports() { try { fs.mkdirSync(EXPORTS, { recursive: true }); } catch {} }
function sha256File(fp) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash("sha256");
    const s = fs.createReadStream(fp);
    s.on("data", (d) => h.update(d));
    s.on("end", () => resolve(h.digest("hex")));
    s.on("error", reject);
  });
}
function countLines(fp) {
  try {
    const t = fs.readFileSync(fp, "utf8");
    let n = 0;
    for (const ln of t.split("\n")) if (ln.trim()) n++;
    return n;
  } catch { return 0; }
}
function msgStat() {
  let files = 0, lines = 0;
  try {
    for (const ch of fs.readdirSync(MSGS)) {
      const dir = path.join(MSGS, ch);
      let st; try { st = fs.statSync(dir); } catch { continue; }
      if (!st.isDirectory()) continue;
      for (const f of fs.readdirSync(dir)) {
        if (!f.endsWith(".jsonl")) continue;
        files++; lines += countLines(path.join(dir, f));
      }
    }
  } catch {}
  const chanCount = (() => { try { return fs.readdirSync(MSGS).length; } catch { return 0; } })();
  return { channels: chanCount, files, lines };
}
function dirStat(p) {
  let n = 0, bytes = 0;
  try {
    const walk = (d) => {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const fp = path.join(d, e.name);
        if (e.isDirectory()) walk(fp);
        else { n++; try { bytes += fs.statSync(fp).size; } catch {} }
      }
    };
    walk(p);
  } catch {}
  return { files: n, bytes };
}
function listExports() {
  try {
    return fs.readdirSync(EXPORTS).filter((f) => f.endsWith(".tgz")).map((f) => {
      const fp = path.join(EXPORTS, f);
      let st = { size: 0, mtimeMs: 0 };
      try { st = fs.statSync(fp); } catch {}
      return { name: f, size: st.size, mtime: st.mtimeMs };
    }).sort((a, b) => b.mtime - a.mtime).slice(0, 20);
  } catch { return []; }
}
function makeExport() {
  return new Promise((resolve, reject) => {
    ensureExports();
    const d = new Date(Date.now() + 8 * 3600e3);
    const stamp = d.toISOString().slice(0, 19).replace(/[-:T]/g, "");
    const name = "room-" + stamp + ".tgz";
    const out = path.join(EXPORTS, name);
    const stat = { msgs: msgStat(), uploads: dirStat(path.join(DATA, "uploads")) };
    const cmd = "tar -cf - -C '" + DATA + "' . | gzip -6 > '" + out + "'";
    const t0 = Date.now();
    execFile("/bin/sh", ["-c", cmd], { timeout: 300000, maxBuffer: 1 << 20 }, async (err) => {
      if (err) return reject(err);
      try {
        const st = fs.statSync(out);
        const sha = await sha256File(out);
        // 只留最近 5 份
        const all = listExports();
        for (const x of all.slice(4)) { try { fs.unlinkSync(path.join(EXPORTS, x.name)); } catch {} }
        resolve({ name, size: st.size, sha256: sha, ms: Date.now() - t0, msgStat: stat.msgs, uploads: stat.uploads });
      } catch (e) { reject(e); }
    });
  });
}

async function handleRequest(req, res) {
  res.__req = req;   // v1.16: send() 需要看 accept-encoding
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "authorization,content-type,x-dsh-room");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    res.setHeader("Access-Control-Max-Age", "86400");
    res.writeHead(204);
    return res.end();
  }

  const url = new URL(req.url, "http://x");
  const p = url.pathname;
  // v1.43：APK 内置页(file://)发起的请求 Origin=null，放开 CORS（仍靠 token 鉴权）
  if (req.headers.origin === "null") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "authorization,content-type");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
    if (req.method === "OPTIONS") { try { res.writeHead(204); res.end(); } catch (e) {} return; }
  }
  // v1253: HTTP 统计（QPS / 延迟 / 错误率）
  {
    const _t0 = Date.now();
    res.on("finish", () => { try { httpStatNote(p, Date.now() - _t0, res.statusCode); } catch {} });
  }
  // v126b: 写操作限流（令牌桶近似：窗口内计数）
  if (req.method === "POST") {
    const _rl = rateLimit(req, p);
    if (!_rl.ok) return send(res, 429, { ok: false, err: "操作太频繁，缓一下再试", retryAfter: _rl.retryAfter });
  }
  // v41: 全局 CORS（APK 内置页面 file:// 跨域访问）
  try {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "authorization,content-type,x-dsh-room");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    res.setHeader("Access-Control-Max-Age", "86400");
  } catch {}

  // 静态
  if (p === "/" || p === "/index.html") {
    return sendC(req, res, 200, page(), "text/html; charset=utf-8");
  }
  // v47: 通话记录（独立界面用）—— 只有家里人能看
  if (p === "/api/calls") {
    const meC = auth(req);
    if (!meC) return send(res, 401, { ok: false, err: "not logged in" });
    if (meC.role !== "family") return send(res, 403, { ok: false, err: "家里人才能看通话记录" });
    const q = u.searchParams;
    const wantWho = clean(q.get("who") || "", 20);
    const limit = Math.min(500, Math.max(1, Number(q.get("limit") || 200)));
    const recs = [];
    const byWho = { shiqi: 0, jiu: 0, hutao: 0 };
    const days = [];
    let totalSecs = 0, totalCount = 0;
    try {
      const files = fs.readdirSync(CALL_DIR).filter((f) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort().reverse();
      for (const f of files) {
        const day = f.slice(0, 10);
        let daySecs = 0, dayCount = 0, txt = "";
        try { txt = fs.readFileSync(path.join(CALL_DIR, f), "utf8"); } catch (e) { txt = ""; }
        for (const ln of txt.split("\n")) {
          if (!ln.trim()) continue;
          let r = null;
          try { r = JSON.parse(ln); } catch (e) { continue; }
          if (!r || !r.ts) continue;
          const secs = Number(r.secs || 0);
          totalSecs += secs; totalCount += 1;
          if (byWho[r.who] === undefined) byWho[r.who] = 0;
          byWho[r.who] += secs;
          daySecs += secs; dayCount += 1;
          if (!wantWho || r.who === wantWho) recs.push(Object.assign({}, r, { day: day }));
        }
        days.push({ day: day, secs: daySecs, count: dayCount });
      }
    } catch (e) { }
    const tday = todayStr();
    const todayRec = days.find((d) => d.day === tday) || { day: tday, secs: 0, count: 0 };
    const week = days.slice(0, 7).reduce((a, d) => ({ secs: a.secs + d.secs, count: a.count + d.count }), { secs: 0, count: 0 });
    return send(res, 200, {
      ok: true, list: recs.slice(0, limit), days: days.slice(0, 60),
      total: { secs: totalSecs, count: totalCount }, byWho: byWho,
      today: todayRec, week: week, quotaSec: CALL_QUOTA_SEC,
    });
  }

  // v47: 通话记录独立页面
  if (p === "/calls" || p === "/calls.html" || p === "/calls/") {
    try {
      const bufC = fs.readFileSync(path.join(HERE, "calls.html"));
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
      return res.end(bufC);
    } catch (e) { return send(res, 404, { ok: false, msg: "calls.html missing" }); }
  }
  if (p === "/calls.js") {
    try {
      const bufJ = fs.readFileSync(path.join(HERE, "calls.js"));
      res.writeHead(200, { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-store" });
      return res.end(bufJ);
    } catch (e) { return send(res, 404, { ok: false }); }
  }

  // v47: 通话记录（独立界面用）—— 只有家里人能看
  if (p === "/api/calls") {
    const meC = auth(req);
    if (!meC) return send(res, 401, { ok: false, err: "not logged in" });
    if (meC.role !== "family") return send(res, 403, { ok: false, err: "家里人才能看通话记录" });
    const q = u.searchParams;
    const wantWho = clean(q.get("who") || "", 20);
    const limit = Math.min(500, Math.max(1, Number(q.get("limit") || 200)));
    const recs = [], byWho = { shiqi: 0, jiu: 0, hutao: 0 }, days = [];
    let totalSecs = 0, totalCount = 0;
    try {
      const files = fs.readdirSync(CALL_DIR).filter((f) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort().reverse();
      for (const f of files) {
        const day = f.slice(0, 10);
        let daySecs = 0, dayCount = 0, txt = "";
        try { txt = fs.readFileSync(path.join(CALL_DIR, f), "utf8"); } catch (e) { txt = ""; }
        for (const ln of txt.split("\n")) {
          if (!ln.trim()) continue;
          let r = null;
          try { r = JSON.parse(ln); } catch (e) { continue; }
          if (!r || !r.ts) continue;
          const secs = Number(r.secs || 0);
          totalSecs += secs; totalCount += 1;
          if (byWho[r.who] === undefined) byWho[r.who] = 0;
          byWho[r.who] += secs;
          daySecs += secs; dayCount += 1;
          if (!wantWho || r.who === wantWho) recs.push(Object.assign({}, r, { day: day }));
        }
        days.push({ day: day, secs: daySecs, count: dayCount });
      }
    } catch (e) { }
    const tday = todayStr();
    const todayRec = days.find((d) => d.day === tday) || { day: tday, secs: 0, count: 0 };
    const week = days.slice(0, 7).reduce((a, d) => ({ secs: a.secs + d.secs, count: a.count + d.count }), { secs: 0, count: 0 });
    return send(res, 200, {
      ok: true, list: recs.slice(0, limit), days: days.slice(0, 60),
      total: { secs: totalSecs, count: totalCount }, byWho: byWho,
      today: todayRec, week: week, quotaSec: CALL_QUOTA_SEC,
    });
  }

  // v47: 通话记录独立页面
  if (p === "/calls" || p === "/calls.html" || p === "/calls/") {
    try {
      const bufC = fs.readFileSync(path.join(HERE, "calls.html"));
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
      return res.end(bufC);
    } catch (e) { return send(res, 404, { ok: false, msg: "calls.html missing" }); }
  }
  if (p === "/calls.js") {
    try {
      const bufJ = fs.readFileSync(path.join(HERE, "calls.js"));
      res.writeHead(200, { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-store" });
      return res.end(bufJ);
    } catch (e) { return send(res, 404, { ok: false }); }
  }

  if (p === "/call" || p === "/call.html" || p === "/call/") {
    try {
      const buf = fs.readFileSync(path.join(HERE, "call.html"));
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
      return res.end(buf);
    } catch { return send(res, 404, { ok: false, msg: "call.html missing" }); }
  }
  if (p === "/call.js") {
    try {
      const buf = fs.readFileSync(path.join(HERE, "call.js"));
      res.writeHead(200, { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-store" });
      return res.end(buf);
    } catch { return send(res, 404, { ok: false }); }
  }
  if (p.startsWith("/media/")) {
    const rel = safeRel(decodeURIComponent(p.slice(7)));
    if (!rel) return send(res, 404, { ok: false });
    try { res.setHeader("cache-control", "public, max-age=31536000, immutable"); } catch {}
    return serveMedia(req, res, path.join(UPLOADS, rel), contentTypeOf(rel), url);
  }
  if (p.startsWith("/videos/")) {
    const f = path.basename(p.slice("/videos/".length));
    const fp = path.join(VID_DIR, f);
    if (!f || !fs.existsSync(fp)) return send(res, 404, { ok: false });
    return serveMedia(req, res, fp, contentTypeOf(f), url);
  }
  if (p.startsWith("/sticker/")) {
    const rel = safeRel(decodeURIComponent(p.slice(9)));
    if (!rel) return send(res, 404, { ok: false });
    return serveFile(res, path.join(STICKER_DIR, rel), contentTypeOf(rel));
  }
  if (STATIC[p]) {
    const [type, file] = STATIC[p];
    try {
      const buf = fs.readFileSync(path.join(HERE, file));
      res.writeHead(200, { "content-type": type, "cache-control": "public, max-age=300" });
      return res.end(buf);
    } catch { return send(res, 404, { ok: false }); }
  }

  // ---------- v22: 大屋权限预检（前端据此决定是否开浮层，避免 302 弹回） ----------
  if (p === "/api/house-ok") {
    const meH2 = auth(req);
    if (!meH2) return send(res, 401, { ok: false, err: "请先登录" });
    // 顺手刷新 cookie：老用户只有 localStorage token 时，这一步把 cookie 补齐，
    // 后面 iframe 里的 /house/ 静态资源才能带着凭据加载。
    if (meH2.token) res.setHeader("set-cookie", cookieOf(meH2.token));
    return send(res, 200, { ok: meH2.role === "family", role: meH2.role, name: meH2.name });
  }

  // ---------- 3D 小家（v1.33：静态场景公开可读；真实数据一律走 /api/* 鉴权） ----------
  // 说明：APK 内页面来自 file:///android_asset/www/index.html，iframe 子资源（pet3d.js、
  // pet/*.webm、模型文件）在 WebView 里不保证带 cookie / Referer，鉴权会把整页打死在
  // 「正在加载模型」。这里只放开静态资源，/api/* 的鉴权、私聊隔离、访客频道全部不变。
  if (p === "/house" || p.startsWith("/house/")) {
    if (p === "/house" || p === "/house/") return serveHouse(req, res, "index.html");
    const hrel = houseRel(decodeURIComponent(p.slice(6)));
    if (!hrel) return send(res, 404, { ok: false });
    return serveHouse(req, res, hrel);
  }

  // 公开信息
  // ---------- v17: 头像 ----------
  if (p.startsWith("/api/avatar/")) {
    const who = clean(p.slice("/api/avatar/".length), 20);
    if (!WHO[who]) return send(res, 404, { ok: false });
    if (req.method === "GET") {
      let f = avFile(who);
      if (!f) {
        const dflt = path.join(DEFAULT_AVDIR, who + ".png");
        if (fs.existsSync(dflt)) f = dflt; else return send(res, 404, { ok: false });
      }
      const buf = fs.readFileSync(f);
      const ext = f.slice(f.lastIndexOf(".") + 1).toLowerCase();
      const mime = ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
      res.writeHead(200, { "content-type": mime, "cache-control": "public, max-age=86400", "content-length": buf.length });
      return res.end(buf);
    }
    if (req.method === "POST") {
      const me = auth(req);
      if (!me || me.role !== "family") return send(res, 403, { ok: false, err: "只有家长能换头像" });
      const b = await body(req);
      const m = String(b.dataUrl || "").match(/^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=\s]+)$/);
      if (!m) return send(res, 400, { ok: false, err: "图片格式不对" });
      const buf = Buffer.from(m[2].replace(/\s/g, ""), "base64");
      if (buf.length > 3 * 1024 * 1024) return send(res, 400, { ok: false, err: "图太大（≤3MB）" });
      fs.mkdirSync(AVDIR, { recursive: true });
      for (const ext of ["jpg", "png", "webp"]) { try { fs.unlinkSync(path.join(AVDIR, who + "." + ext)); } catch {} }
      const ext = m[1] === "png" ? "png" : m[1] === "webp" ? "webp" : "jpg";
      fs.writeFileSync(path.join(AVDIR, who + "." + ext), buf);
      return send(res, 200, { ok: true, avatar: avUrl(who) });
    }
    return send(res, 405, { ok: false });
  }
  if (p.startsWith("/api/avatar-reset/") && req.method === "POST") {
    const me = auth(req);
    if (!me || me.role !== "family") return send(res, 403, { ok: false, err: "只有家长能改头像" });
    const who = clean(p.slice("/api/avatar-reset/".length), 20);
    if (!WHO[who]) return send(res, 404, { ok: false });
    for (const ext of ["jpg", "jpeg", "png", "webp"]) { try { fs.unlinkSync(path.join(AVDIR, who + "." + ext)); } catch {} }
    return send(res, 200, { ok: true, avatar: avUrl(who) });
  }
  if (p === "/api/who") return send(res, 200, whoPayload());
  if (p === "/api/presence") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    return sendC(req, res, 200, { ok: true, online: presenceIds(), sisters: SISTERS, mute: inMute(), ts: Date.now() });
  }
  if (p === "/api/bots/heartbeat" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    bumpBot(b.who || "shiqi");
    return sendC(req, res, 200, { ok: true, online: presenceIds() });
  }
  // v33：检查更新（公开接口；网页与 APK 客户端共用）
  if (p === "/api/version") return sendC(req, res, 200, versionInfo());
  if (p === "/download/familyroom.apk") {
    let st = null;
    try { st = fs.statSync(APK_FILE); } catch {}
    if (!st) return send(res, 404, { ok: false, err: "还没有发布包" });
    const vi = versionInfo();
    res.writeHead(200, {
      "content-type": "application/vnd.android.package-archive",
      "content-length": st.size,
      "content-disposition": `attachment; filename="familyroom-${vi.apkVersion}.apk"`,
      "cache-control": "no-cache",
    });
    return fs.createReadStream(APK_FILE).pipe(res);
  }
  if (p === "/api/visitor/archive" && req.method === "POST") {
    const me = auth(req);
    if (!me || (me.role !== "family" && me.role !== "bot")) return send(res, 403, { ok: false });
    const b = await body(req);
    const acc = accounts.find((a) => a.id === clean(b.accountId, 40));
    if (!acc) return send(res, 404, { ok: false });
    return sendC(req, res, 200, { ok: true, ...archiveVisitor(acc, true) });
  }
  // v29：小二姐的冰窖化进度（只有家里人/机器人能看；访客拿不到，前端因此不显示 ❄）
  if (p === "/api/jiu") {
    const meJ = auth(req);
    if (!meJ || meJ.role === "visitor") return send(res, 403, { ok: false, err: "家里人才能看" });
    let st9 = {}, inner = "";
    try { st9 = JSON.parse(fs.readFileSync(path.join(DATA, "jiu-state.json"), "utf8")); } catch {}
    try {
      const ls = fs.readFileSync(path.join(DATA, "jiu-inner.jsonl"), "utf8").trim().split("\n");
      const last = ls[ls.length - 1];
      if (last) inner = String(JSON.parse(last).text || "");
    } catch {}
    return send(res, 200, { ok: true, value: typeof st9.value === "number" ? st9.value : 0, day: st9.day != null ? st9.day + 1 : 1, days: 100, updated: st9.updated || null, inner });
  }
  // v1.39: 家庭语录（家里人都能收录，任何人可读）
  if (p === "/api/quotes") {
    const meQ = auth(req);
    if (!meQ) return send(res, 401, { ok: false, err: "请先登录" });
    const QF = path.join(DATA, "quotes.jsonl");
    if (req.method === "GET") {
      const arr = [];
      try {
        const t = fs.readFileSync(QF, "utf8").trim();
        if (t) for (const ln of t.split("\n")) { try { arr.push(JSON.parse(ln)); } catch {} }
      } catch {}
      return sendC(req, res, 200, { ok: true, quotes: arr.slice(-300).reverse() });
    }
    if (req.method === "POST") {
      if (meQ.role === "visitor") return send(res, 403, { ok: false, err: "访客不能收录" });
      const b = await body(req);
      const text = String(b.text || "").trim().slice(0, 300);
      if (!text) return send(res, 400, { ok: false, err: "内容为空" });
      const item = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), ts: Date.now(), who: clean(b.who || "", 20), text, by: meQ.id };
      try { fs.appendFileSync(QF, JSON.stringify(item) + "\n"); } catch (e) { return send(res, 500, { ok: false, err: "写入失败" }); }
      return sendC(req, res, 200, { ok: true, quote: item });
    }
    if (req.method === "DELETE") {
      if (meQ.role !== "family" && meQ.role !== "bot") return send(res, 403, { ok: false });
      const b = await body(req);
      const id = clean(b.id || "", 40);
      let arr = [];
      try {
        const t = fs.readFileSync(QF, "utf8").trim();
        if (t) for (const ln of t.split("\n")) { try { arr.push(JSON.parse(ln)); } catch {} }
      } catch {}
      const kept = arr.filter((x) => x.id !== id);
      try { fs.writeFileSync(QF, kept.map((x) => JSON.stringify(x)).join("\n") + (kept.length ? "\n" : "")); } catch {}
      return sendC(req, res, 200, { ok: true, removed: arr.length - kept.length });
    }
    return send(res, 405, { ok: false });
  }

  if (p === "/api/rules") return send(res, 200, { ok: true, rules, text: rulesText() });
  if (p === "/api/identities") return send(res, 200, IDENTITIES);

  if (p === "/api/family") {
    try {
      const f = path.join(DATA, "family-identities.json");
      const j = JSON.parse(fs.readFileSync(f, "utf8"));
      return send(res, 200, j);
    } catch {
      return send(res, 200, { version: 0, members: [] });
    }
  }


  // v30：音色参数（读：家里人/机器人；写：只有家长）
  if (p === "/api/voice") {
    if (req.method === "POST") {
      const me = auth(req);
      if (!me || me.role !== "family") return send(res, 403, { ok: false, err: "只有家长能改音色" });
      const b = await body(req);
      const next = normVoice({ ...voice, ...(b && b.voice ? b.voice : b || {}) });
      voice = next;
      try { writeJson(VOICE_FILE, voice); } catch (e) { return send(res, 500, { ok: false, err: "存不下去" }); }
      return sendC(req, res, 200, { ok: true, voice });
    }
    return send(res, 200, { ok: true, voice, default: DEFAULT_VOICE, timbres: VOICE_TIMBRES });
  }

  // v34：三姐妹/家长 的「本地记忆」——客户端/终端把记忆条目传到云端存档
  if (p === "/api/memory") {
    const meM = auth(req);
    if (!meM || (meM.role !== "family" && meM.role !== "bot")) return send(res, 403, { ok: false, err: "只有家里能看" });
    if (req.method === "POST") {
      const b = await body(req);
      const text = String((b && b.text) || "").trim();
      if (!text) return send(res, 400, { ok: false, err: "空记忆" });
      const who = ["shiqi", "jiu", "hutao", "laoda"].includes(String(b.who)) ? String(b.who) : meM.id;
      const row = { ts: Number(b.ts) || Date.now(), who, text: text.slice(0, 2000), src: String((b.src || "app")).slice(0, 24) };
      try { fs.appendFileSync(path.join(DATA, "memory-" + todayStr() + ".jsonl"), JSON.stringify(row) + "\n"); } catch (e) {}
      return sendC(req, res, 200, { ok: true, row });
    }
    let list = [];
    try {
      const f = path.join(DATA, "memory-" + todayStr() + ".jsonl");
      if (fs.existsSync(f)) list = fs.readFileSync(f, "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
    } catch (e) {}
    return sendC(req, res, 200, list.slice(-200));
  }

  // v36：资源阈值面板——跑手机侧 skill-threshold.mjs 拿「手机+服务器」指标与等级
  if (p === "/api/metrics") {
    const meS = auth(req);
    if (!meS) return send(res, 403, { ok: false, err: "先登录" });
    const now = Date.now();
    if (METRICS_CACHE && now - METRICS_CACHE.ts < 20000) return sendC(req, res, 200, METRICS_CACHE.data);
    const script = path.join(HERE, "skill-threshold.mjs");
    const out = await new Promise((resolve) => {
      execFile(process.execPath, [script], { timeout: 15000, env: { ...process.env, HOME: process.env.HOME || "/data/data/com.termux/files/home" } }, (err, stdout) => {
        if (err || !stdout) return resolve(null);
        try { resolve(JSON.parse(stdout)); } catch { resolve(null); }
      });
    });
    if (!out) return send(res, 502, { ok: false, err: "采不到指标（脚本超时或出错）" });
    try { out.http = httpStatSnap(); } catch {}
    METRICS_CACHE = { ts: now, data: out };
    return sendC(req, res, 200, out);
  }

  // 登录
  if (p === "/api/login" && req.method === "POST") {
    const b = await body(req);
    const name = clean(b.name, 40);
    const pass = String(b.pass || "");
    const acc = accounts.find((a) => a.name === name);
    if (!acc) return send(res, 404, { ok: false, err: "没有这个账号" });
    if (acc.status === "pending") return send(res, 403, { ok: false, err: "申请还在投票中，过了才能进" });
    if (acc.status === "rejected") return send(res, 403, { ok: false, err: "你没通过/已被请出。想再进就用同一个名字和密码重新提交申请，重新投票。" });
    if (hashPass(pass, acc.salt) !== acc.pass) return send(res, 403, { ok: false, err: "密码不对" });
    const token = newToken();
    sessions[token] = { accountId: acc.id, exp: Date.now() + 180 * 86400e3 };
    saveSessions();
    res.setHeader("set-cookie", cookieOf(token));
    return send(res, 200, { ok: true, token, me: accPublic(acc) });
  }

  // 当前会话（浏览器带着 cookie 就能自动恢复，不用再输密码）
  if (p === "/api/session") {
    const me = auth(req);
    if (!me) return send(res, 200, { ok: false });
    return send(res, 200, { ok: true, token: me.token || "", me: accPublic(me) });
  }
  if (p === "/api/logout" && req.method === "POST") {
    const me = auth(req);
    if (me && me.token && sessions[me.token]) { delete sessions[me.token]; saveSessions(); }
    res.setHeader("set-cookie", "room_token=; Path=/; Max-Age=0; SameSite=Lax");
    return send(res, 200, { ok: true });
  }

  // v1.16: 免打扰时段
  if (p === "/api/notifyquiet") {
    if (req.method === "GET") return sendC(req, res, 200, { ok: true, notifyQuiet: settings().notifyQuiet, active: notifyQuiet() });
    if (req.method === "POST") {
      const meN = auth(req);
      if (!meN || meN.role !== "family") return send(res, 403, { ok: false, err: "只有家里人能改" });
      const bN = await body(req);
      const nq = { ...(settings().notifyQuiet || {}) };
      if (bN.enabled !== undefined) nq.enabled = bN.enabled === true;
      if (bN.from !== undefined) nq.from = Math.max(0, Math.min(23, parseInt(bN.from, 10) || 0));
      if (bN.to !== undefined) nq.to = Math.max(0, Math.min(23, parseInt(bN.to, 10) || 0));
      saveSettings({ notifyQuiet: nq });
      return sendC(req, res, 200, { ok: true, notifyQuiet: settings().notifyQuiet, active: notifyQuiet() });
    }
  }
  if (p === "/api/quiet") {
    if (req.method === "GET") return sendC(req, res, 200, { ok: true, quiet: settings().quiet, inQuiet: inQuiet() });
    if (req.method === "POST") {
      const meQ = auth(req);
      if (!meQ || meQ.role !== "family") return send(res, 403, { ok: false, err: "只有家里人能改" });
      const bQ = await body(req);
      const fromQ = Math.max(0, Math.min(23, parseInt(bQ.from, 10) || 0));
      const toQ = Math.max(0, Math.min(23, parseInt(bQ.to, 10) || 0));
      saveSettings({ quiet: { enabled: bQ.enabled !== false, from: fromQ, to: toQ } });
      return send(res, 200, { ok: true, quiet: settings().quiet, inQuiet: inQuiet() });
    }
  }

  // v34 访客开关（GET 公开：前端据此决定要不要显示「申请加入」；POST 仅家人）
  if (p === "/api/guest") {
    if (req.method === "GET") return sendC(req, res, 200, { ok: true, allowGuest: guestAllowed() });
    if (req.method === "POST") {
      const me = auth(req);
      if (!me || me.role !== "family") return send(res, 403, { ok: false, err: "只有家里人能改" });
      const b = await body(req);
      saveSettings({ allowGuest: b.allowGuest !== false, by: me.id });
      return send(res, 200, { ok: true, allowGuest: guestAllowed() });
    }
  }

  // v37：APK 通知服务心跳（有 App 在，就由 App 负责系统通知，避免和 Termux 通知重复）
  if (p === "/api/appnotify") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "先登录" });
    if (req.method === "POST") {
      appNotifyUntil = Date.now() + 180000; // 心跳 60s，给 3 分钟宽限
      return send(res, 200, { ok: true, active: true });
    }
    return send(res, 200, { ok: true, active: Date.now() < appNotifyUntil });
  }

  // 注册（访客申请）
  if (p === "/api/register" && req.method === "POST") {
    const b = await body(req);
    const name = clean(b.name, 40);
    const pass = String(b.pass || "");
    const identity = clean(b.identity, 20) || "路过网友";
    // v34: 访客注册是可选项，家长可在设置里关掉（只留家人登录）
    if (!guestAllowed()) return send(res, 403, { ok: false, err: "家长把「允许访客注册」关了，现在只有家里人能登录" });
    if (name.length < 2) return send(res, 400, { ok: false, err: "名字至少两个字" });
    if (pass.length < 4) return send(res, 400, { ok: false, err: "密码至少四位数" });
    const exist = accounts.find((a) => a.name === name);
    if (exist) {
      const samePass = hashPass(pass, exist.salt) === exist.pass;
      if (!samePass) return send(res, 409, { ok: false, err: "这名字有人在用（如果就是你自己，密码要和上次一样才能重新申请）" });
      if (exist.status === "active") return send(res, 409, { ok: false, err: "你已经在小屋里了，直接登录就行" });
      if (exist.status === "pending") return send(res, 409, { ok: false, err: "你的申请还在投票中，别重复提交" });
      // 被踢 / 没过 → 允许重新申请、重新投票；账号 id 不变，原来的频道和历史都还在
      exist.status = "pending";
      exist.share = b.share !== false;
      exist.identity = identity;
      exist.reapplyAt = Date.now();
      saveAccounts();
      const app2 = { id: "ap" + crypto.randomBytes(4).toString("hex"), accountId: exist.id, name, identity, status: "pending", votes: {}, createdAt: Date.now(), reapply: true };
      applications.push(app2);
      saveApps();
      const n2 = { ts: Date.now(), who: "shiqi", name: "大姐", text: `「${name}」又递了张申请（之前被请出去过一次），身份写的是「${identity}」，投票吧。`, type: "application", appId: app2.id };
      append(FAMILY_CHANNEL, n2);
      broadcast(FAMILY_CHANNEL, n2);
      return send(res, 200, { ok: true, status: "pending", appId: app2.id, reapplied: true });
    }
    const salt = newToken();
    const id = "g" + crypto.randomBytes(4).toString("hex");
    const acc = { id, name, role: "visitor", identity, salt, pass: hashPass(pass, salt), status: "pending", createdAt: Date.now(), share: b.share !== false };
    accounts.push(acc);
    saveAccounts();
    const app = { id: "ap" + crypto.randomBytes(4).toString("hex"), accountId: id, name, identity, status: "pending", votes: {}, createdAt: Date.now() };
    applications.push(app);
    saveApps();
    // 大姐在小屋发申请
    const notice = {
      ts: Date.now(), who: "shiqi", name: "大姐", text: `有个叫「${name}」的想进小屋，身份写了「${identity}」。家人投个票吧，家长点头就放进来。`,
      type: "application", appId: app.id,
    };
    append(FAMILY_CHANNEL, notice);
    broadcast(FAMILY_CHANNEL, notice);
    return send(res, 200, { ok: true, status: "pending", appId: app.id });
  }

  // 修改密码
  if (p === "/api/passwd" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    const acc = accounts.find((a) => a.id === me.id);
    if (!acc) return send(res, 404, { ok: false });
    if (hashPass(String(b.old || ""), acc.salt) !== acc.pass) return send(res, 403, { ok: false, err: "旧密码不对" });
    acc.salt = newToken();
    acc.pass = hashPass(String(b.new || ""), acc.salt);
    saveAccounts();
    return send(res, 200, { ok: true });
  }

  // 我
  if (p === "/api/me") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const acc = accounts.find((a) => a.id === me.id);
    return send(res, 200, { ok: true, me: accPublic(acc) });
  }

  // 频道列表
  if (p === "/api/channels") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const list = [];
    if (me.role === "family" || me.role === "bot") {
      list.push({ channel: FAMILY_CHANNEL, title: "家庭小屋", kind: "family" });
      if (me.id === "laoda") {
        for (const dm of DM_LIST) {
          let lastDm = null;
          try {
            const arr = readDay(dm.id, todayStr());
            const m = arr[arr.length - 1];
            if (m) lastDm = { text: String(m.text || (m.kind ? "[消息]" : "")).slice(0, 18), ts: m.ts, who: m.who };
          } catch {}
          list.push({ channel: dm.id, title: dm.title, note: dm.note, kind: "dm", who: dm.who, online: presenceIds().includes(dm.who), last: lastDm });
        }
      }
      for (const a of accounts.filter((x) => x.role === "visitor" && x.status === "active")) {
        let last = null;
      try {
        const arr = readDay("v" + a.id, todayStr());
        const m = arr[arr.length - 1];
        if (m) last = { text: String(m.text || (m.kind === "sticker" ? "[表情]" : "[图片]")).slice(0, 18), ts: m.ts, who: m.who };
      } catch {}
      list.push({ channel: "v" + a.id, title: a.name + "（" + a.identity + "）", kind: "visitor", accountId: a.id, identity: a.identity, name: a.name, online: presenceIds().includes(a.id), last });
      }
    } else {
      list.push({ channel: "v" + me.id, title: "和大姐她们聊天", kind: "visitor", identity: me.identity || "网友", accountId: me.id, name: me.name });
    }
    return send(res, 200, { channels: list });
  }

  // 消息
  if (p === "/api/messages") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const channel = clean(url.searchParams.get("channel") || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false, err: "看不到这个频道" });
    const date = clean(url.searchParams.get("date") || todayStr(), 12);
    const since = resetTs(channel);
    const all = readDay(channel, date);
    return sendC(req, res, 200, since ? all.filter((m) => Number(m.ts || 0) >= since) : all);
  }

  // 本人历史：访客读自己的全部记录（含重开之前的），家人/机器人可读任意频道
  if (p === "/api/myhistory") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const channel = clean(url.searchParams.get("channel") || (me.role === "visitor" ? "v" + me.id : FAMILY_CHANNEL), 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false, err: "看不到这个频道" });
    const limit = Math.min(400, Math.max(1, Number(url.searchParams.get("limit") || 120) || 120));
    const dir = chanDir(channel);
    const out = [];
    let files = [];
    files = dayFileList(dir);
    for (const f of files) {
      const date = dayBase(f);
      const txt = readDayText(dir, f);
      if (!txt) continue;
      for (const ln of txt.split("\n")) {
        const t = ln.trim();
        if (!t) continue;
        try { const m = JSON.parse(t); m.date = date; out.push(m); } catch {}
      }
    }
    out.sort((a, b) => Number(a.ts || 0) - Number(b.ts || 0));
    return send(res, 200, { ok: true, messages: out.slice(-limit) });
  }

  // 新开一段：家人对某个访客频道重新开始，旧记录留档但不再显示
  if (p === "/api/newchat" && req.method === "POST") {
    const me = auth(req);
    if (!me || me.role !== "family") return send(res, 403, { ok: false, err: "只有家人能重开" });
    const b = await body(req);
    const channel = clean(b.channel || "", 30);
    if (!/^v[a-z0-9]+$/.test(channel)) return send(res, 400, { ok: false, err: "只能对访客频道重开" });
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    const ts = Date.now();
    fs.writeFileSync(resetFile(channel), String(ts));
    const msg = { ts, who: "system", name: "小屋", color: "#8f9bb3", tag: "", text: "这段聊天重新开始，之前的翻篇了。", type: "reset" };
    append(channel, msg);
    broadcast(channel, msg);
    return send(res, 200, { ok: true, ts });
  }

  // 3D 小家：读/写房间布置（她们可以自己装修，不用问大姐）
  if (p.startsWith("/api/room/") && req.method === "GET") {
    const id = clean(decodeURIComponent(p.slice("/api/room/".length)), 24);
    if (!/^(shiqi|jiu|hutao|living)$/.test(id)) return send(res, 400, { ok: false, err: "没有这间房" });
    let all = {};
    try { all = JSON.parse(fs.readFileSync(ROOMS_FILE, "utf8")); } catch {}
    return send(res, 200, { ok: true, id, items: Array.isArray(all[id] && all[id].items) ? all[id].items : [], at: all[id] && all[id].at || 0, by: all[id] && all[id].by || "" });
  }
  if (p === "/api/room" && req.method === "POST") {
    const me = auth(req);
    if (!me || (me.role !== "bot" && me.role !== "family")) return send(res, 403, { ok: false, err: "家人或机器人才会装修" });
    const b = await body(req);
    const id = clean(b.id || "living", 24);
    if (!/^(shiqi|jiu|hutao|living)$/.test(id)) return send(res, 400, { ok: false, err: "没有这间房" });
    if (!Array.isArray(b.items) || b.items.length > 28) return send(res, 400, { ok: false, err: "家具数量不对" });
    const items = [];
    for (const it of b.items) {
      const m = String(it && it.m || "");
      if (!ALLOWED_ITEMS.has(m)) continue;
      const x = Math.max(-3.4, Math.min(3.4, Number(it.x) || 0));
      const z = Math.max(-2.9, Math.min(2.9, Number(it.z) || 0));
      const r = Math.round(Math.max(-360, Math.min(360, Number(it.r) || 0)));
      const s = Math.max(0.4, Math.min(2.2, Number(it.s) || 1));
      items.push({ m, x: Math.round(x * 100) / 100, z: Math.round(z * 100) / 100, r, s: Math.round(s * 100) / 100 });
    }
    let all = {};
    try { all = JSON.parse(fs.readFileSync(ROOMS_FILE, "utf8")); } catch {}
    const who = me.role === "family" ? (me.who || "laoda") : String(b.who || "shiqi");
    all[id] = { items, at: Date.now(), by: who };
    fs.writeFileSync(ROOMS_FILE, JSON.stringify(all, null, 1));
    return send(res, 200, { ok: true, id, count: items.length, at: all[id].at, by: who });
  }

  // v40：日记（三姐妹每天写在小屋，不再推微信）
  if (p === "/api/diary" && req.method === "POST") {
    const meD = auth(req);
    if (!meD || (meD.role !== "bot" && meD.role !== "family")) return send(res, 403, { ok: false, err: "只有家人或机器人能写日记" });
    const bD = await body(req);
    const chD = clean(bD.channel || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(meD, chD)) return send(res, 403, { ok: false, err: "看不到这个频道" });
    let whoD = String(bD.who || "").trim();
    if (meD.role === "family") whoD = meD.who || "laoda";
    else if (!WHO[whoD]) whoD = "shiqi";
    const textD = clean(bD.text, 6000);
    if (!textD) return send(res, 400, { ok: false, err: "日记是空的" });
    const dayD = (/^\d{4}-\d{2}-\d{2}$/.test(String(bD.date || "")) ? String(bD.date) : todayStr());
    const dD = WHO[whoD] || { name: meD.name, color: "#c9c9c9", tag: "" };
    const msgD = { ts: Date.now(), who: whoD, name: dD.name, color: dD.color, tag: dD.tag, text: textD, kind: "diary", date: dayD, accountId: meD.id };
    try { fs.appendFileSync(path.join(DIARY_DIR, dayD + ".jsonl"), JSON.stringify(msgD) + "\n"); } catch {}
    broadcast(chD, msgD);
    return send(res, 200, { ok: true, msg: msgD });
  }
  if (p === "/api/diaries") {
    const meD = auth(req);
    if (!meD) return send(res, 401, { ok: false });
    const limD = Math.min(400, Math.max(1, Number(url.searchParams.get("limit") || 80) || 80));
    const outD = [];
    try {
      const filesD = fs.readdirSync(DIARY_DIR).filter((x) => x.endsWith(".jsonl")).sort().slice(-60);
      for (const fD of filesD) outD.push(...readJsonlCached(DIARY_DIR, fD));
      // v45: 支持按人筛选（?who=jiu）与只取最近的 limit 条
      const whoD2 = clean(url.searchParams.get("who") || "", 20);
      if (whoD2) {
        for (let i = outD.length - 1; i >= 0; i--) if (String(outD[i].who || "") !== whoD2) outD.splice(i, 1);
      }
    } catch {}
    outD.sort((a, b) => Number(a.ts || 0) - Number(b.ts || 0));
    return send(res, 200, { ok: true, diaries: outD.slice(-limD) });
  }

  // 动态（朋友圈/说说）：家长在群里 @某人 说「发个动态」→ 那个人发一条
  if (p === "/api/moment" && req.method === "POST") {
    const me = auth(req);
    if (!me || (me.role !== "bot" && me.role !== "family")) return send(res, 403, { ok: false, err: "只有家人或机器人能发动态" });
    const b = await body(req);
    const channel = clean(b.channel || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false, err: "看不到这个频道" });
    let who = String(b.who || "").trim();
    if (me.role === "family") who = me.who || "laoda";
    else if (!WHO[who]) who = "shiqi";
    const text = clean(b.text, 400);
    let mediaRel = "";
    const relM = safeRel(String(b.media || ""));
    if (relM && fs.existsSync(path.join(UPLOADS, relM))) mediaRel = relM;
    if (!text && !mediaRel) return send(res, 400, { ok: false, err: "动态是空的" });
    const dM = WHO[who] || { name: me.name, color: "#c9c9c9", tag: "" };
    const urlM = mediaRel ? "/media/" + mediaRel.split("/").map(encodeURIComponent).join("/") : "";
    const msgM = { ts: Date.now(), who, name: dM.name, color: dM.color, tag: dM.tag, text, kind: "moment", media: mediaRel, url: urlM, accountId: me.id };
    append(channel, msgM);
    broadcast(channel, msgM);
    try { fs.appendFileSync(path.join(MOM_DIR, todayStr() + ".jsonl"), JSON.stringify(msgM) + "\n"); } catch {}
    bumpBot(who);
    noteSay(speakerOf(me, who), false);
    return send(res, 200, { ok: true, msg: msgM });
  }
  if (p === "/api/moments") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const limitM = Math.min(120, Math.max(1, Number(url.searchParams.get("limit") || 30) || 30));
    const outM = [];
    try {
      const filesM = fs.readdirSync(MOM_DIR).filter((x) => x.endsWith(".jsonl")).sort().slice(-7);
      for (const fM of filesM) outM.push(...readJsonlCached(MOM_DIR, fM));
      const whoM2 = clean(url.searchParams.get("who") || "", 20);
      if (whoM2) {
        for (let i = outM.length - 1; i >= 0; i--) if (String(outM[i].who || "") !== whoM2) outM.splice(i, 1);
      }
    } catch {}
    outM.sort((a, b) => Number(a.ts || 0) - Number(b.ts || 0));
    const metaM = momMeta();
    const withMeta = outM.slice(-limitM).map((x) => {
      const k = momKey(x);
      const m = metaM[k] || {};
      return { ...x, key: k, likes: Array.isArray(m.likes) ? m.likes : [], comments: Array.isArray(m.comments) ? m.comments : [] };
    });
    return send(res, 200, { ok: true, moments: withMeta });
  }

  // v47: 动态点赞（可取消）
  if (p === "/api/moment/like" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const key = clean(b.key || "", 80);
    if (!key) return send(res, 400, { ok: false, err: "缺少 key" });
    const who = me.role === "family" ? (me.who || "laoda") : String(me.who || me.name || "guest");
    const meta = loadMomMeta();
    const cur = meta[key] || { likes: [], comments: [] };
    const likes = Array.isArray(cur.likes) ? cur.likes.slice() : [];
    const i = likes.indexOf(who);
    if (i >= 0) likes.splice(i, 1); else likes.push(who);
    meta[key] = { ...cur, likes, comments: Array.isArray(cur.comments) ? cur.comments : [] };
    saveMomMeta(meta);
    broadcastRaw(FAMILY_CHANNEL, { type: "moment", op: "like", key, likes });
    return send(res, 200, { ok: true, likes, liked: i < 0 });
  }

  // v47: 动态评论
  if (p === "/api/moment/comment" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const key = clean(b.key || "", 80);
    const text = clean(b.text, 300);
    if (!key || !text) return send(res, 400, { ok: false, err: "内容为空" });
    const who = me.role === "family" ? (me.who || "laoda") : String(me.who || me.name || "guest");
    const nameC = me.role === "family" ? (me.name || who) : (me.name || who);
    const meta = loadMomMeta();
    const cur = meta[key] || { likes: [], comments: [] };
    const comments = Array.isArray(cur.comments) ? cur.comments.slice() : [];
    const c = { who, name: nameC, text, ts: Date.now() };
    comments.push(c);
    meta[key] = { ...cur, likes: Array.isArray(cur.likes) ? cur.likes : [], comments };
    saveMomMeta(meta);
    broadcastRaw(FAMILY_CHANNEL, { type: "moment", op: "comment", key, comment: c, comments });
    return send(res, 200, { ok: true, comments });
  }

  // v45: 回写某条消息的正文（机器人识图后把 [图片] 换成 [图片：描述]，刷新后仍在）
  if (p === "/api/msgpatch" && req.method === "POST") {
    const meP = auth(req);
    if (!meP || (meP.role !== "bot" && meP.role !== "family")) return send(res, 403, { ok: false });
    const bP = await body(req);
    const chP = clean(bP.channel || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(meP, chP)) return send(res, 403, { ok: false });
    const tsP = Number(bP.ts || 0);
    const whoP = String(bP.who || "").slice(0, 20);
    const textP = String(bP.text || "").slice(0, 4000);
    if (!tsP || !textP) return send(res, 400, { ok: false, err: "参数不全" });
    let hitP = 0;
    const dirP = chanDir(chP);
    for (let k = 0; k < 3; k++) {
      const dayP = new Date(Date.now() + 8 * 3600e3 - k * 864e5).toISOString().slice(0, 10);
      const fpP = path.join(dirP, dayP + ".jsonl");
      if (!fs.existsSync(fpP)) continue;
      try {
        const linesP = fs.readFileSync(fpP, "utf8").split("\n");
        const outP = linesP.map((ln) => {
          const tP = ln.trim();
          if (!tP) return ln;
          try {
            const mP = JSON.parse(tP);
            if (Number(mP.ts) !== tsP || (whoP && mP.who !== whoP)) return ln;
            mP.text = textP; mP.visionAt = Date.now(); hitP++;
            return JSON.stringify(mP);
          } catch { return ln; }
        });
        if (hitP) { fs.writeFileSync(fpP, outP.join("\n")); JSONL_CACHE.delete(fpP); }
      } catch {}
      if (hitP) break;
    }
    if (!hitP) return send(res, 404, { ok: false, err: "没找到消息" });
    broadcastRaw(chP, { type: "patch", op: "text", ts: tsP, who: whoP, text: textP });
    return send(res, 200, { ok: true, hit: hitP });
  }

  // 发言
  if (p === "/api/say" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    const channel = clean(b.channel || (me.role === "visitor" ? "v" + me.id : FAMILY_CHANNEL), 30);
    let text = clean(b.text, 4000);
    let kind = "", mediaRel = "";
    if (b.kind === "sticker" || b.kind === "image" || b.kind === "audio") {
      const rel = safeRel(String(b.media || ""));
      const baseDir = b.kind === "sticker" ? STICKER_DIR : UPLOADS;
      if (rel && fs.existsSync(path.join(baseDir, rel))) { kind = b.kind; mediaRel = rel; }
      else if (!text) return send(res, 400, { ok: false, err: "素材不存在" });
    }
    if (b.kind === "record") {
      const rid = String(b.rec || "").replace(/[^a-z0-9]/gi, "").slice(0, 32);
      const meta = rid ? recordMeta(rid) : null;
      if (!meta) return send(res, 400, { ok: false, err: "聊天记录不存在" });
      if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false, err: "不能在这个频道发言" });
      if (inMute() && me.role !== "family") {
        return send(res, 423, { ok: false, mute: true, err: "现在是禁言时段（0:00–7:00），姐妹们都睡了，7 点后再聊" });
      }
      const spR = speakerOf(me, String(b.who || "").trim());
      const dR = WHO[spR] || { name: me.name, color: "#c9c9c9", tag: "访客" };
      const msgR = {
        ts: Date.now(), who: spR, name: dR.name, color: dR.color, tag: dR.tag,
        text: text || ("[聊天记录] " + (meta.title || "") + " · 共 " + meta.count + " 条"),
        kind: "record", rec: rid, count: Number(meta.count) || 0, title: String(meta.title || ""), accountId: me.id,
      };
      append(channel, msgR);
      broadcast(channel, msgR);
      return send(res, 200, { ok: true, msg: msgR });
    }
    if (!text && !kind) return send(res, 400, { ok: false, err: "空消息" });
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false, err: "不能在这个频道发言" });
    if (inMute() && me.role !== "family" && me.role !== "bot") {
      return send(res, 423, { ok: false, mute: true, err: "现在是禁言时段（0:00–7:00），姐妹们都睡了，7 点后再聊" });
    }
    if (kind) {
      const sp0 = speakerOf(me, String(b.who || "").trim());
      bumpBot(sp0);
      const isDraw = kind === "image" && /draw-/.test(mediaRel);
      const lim0 = checkLimit(me, sp0, kind === "sticker", isDraw, !!b.force);
      if (!lim0.ok) return send(res, 429, lim0);
      const msg = mediaMsg(me, channel, kind, mediaRel, text, String(b.who || "").trim());
      noteSay(sp0, kind === "sticker");
      if (isDraw) noteDraw(sp0);
      return send(res, 200, { ok: true, msg });
    }

    let who = String(b.who || "").trim();
    if (me.role === "bot") {
      if (!WHO[who]) who = "shiqi";
    } else if (me.role === "family") {
      who = me.who || "laoda";
    } else {
      who = "guest:" + me.id;
    }
    const mentions = Array.isArray(b.mentions)
      ? b.mentions.map((x) => clean(x, 20)).filter(Boolean).slice(0, 8)
      : (String(text).match(/@([\u4e00-\u9fa5A-Za-z]{1,6})/g) || []).map((x) => x.slice(1));
    bumpBot(who);
    const speaker = speakerOf(me, who);
    const lim = checkLimit(me, speaker, false, false, !!b.force);
    if (!lim.ok) return send(res, 429, lim);
    const display = WHO[who] || { name: me.name, color: "#c9c9c9", tag: "访客·" + (me.identity || "网友") };
    const q = (b.quote && b.quote.text) ? { who: clean(b.quote.who, 20), name: clean(b.quote.name, 20), text: clean(b.quote.text, 80), ts: Number(b.quote.ts) || 0 } : null;
    const msg = {
      ts: Date.now(), who, name: display.name, color: display.color, tag: display.tag,
      text, accountId: me.id, mentions, quote: q,
      voice: b.voice ? 1 : 0,
      call: b.call ? 1 : 0,
    };
    append(channel, msg);
    broadcast(channel, msg);
    noteSay(speaker, false);
    // v19：家长 @某人 点名要图/表情 → 该人本轮免限
    if (me.role === "family") {
      const nmAt = String(text).match(/@(大姐|二姐|三姐)/);
      if (nmAt && /(发图|发张|来张|来一张|画一?张|画个|画张|斗图|表情包|图片)/.test(String(text))) {
        grantDrawExempt({ "大姐": "shiqi", "二姐": "jiu", "三姐": "hutao" }[nmAt[1]]);
      }
    }
    // 家长 @所有人 / @大姐 → 命令与任务（v17 收紧语义）
    if (me.role === "family" && mentions.length && (mentions.includes("所有人") || mentions.includes("大姐") || mentions.includes("二姐") || mentions.includes("三姐"))) {
      const body2 = String(text).replace(/@\S+/g, "").trim();
      const isTask = /(任务|规则|命令|要求|规定|不许|不准|最多|最少|禁止)/.test(body2);
      const wantsRules = /(看规则|念规则|规则是什么|哪些规则)/.test(body2);
      let ackText = "";
      if (wantsRules) {
        ackText = "现在小屋的规矩是：" + rulesText() + "。另外 0:00–7:00 是禁言时段，姐妹不上线说话。";
      } else if (mentions.includes("所有人") && isTask) {
        const applied = applyRuleCommands(body2);
        ackText = applied.length
          ? "规则收到，已经写进小屋：" + applied.map((a) => a.name + " " + a.value).join("；") + "。现在生效的是——" + rulesText() + "。"
          : "收到，按这个来：" + rulesText() + "。";
      } else if (mentions.includes("大姐") && isTask) {
        ackText = "任务收到：" + body2.slice(0, 60) + "。二姐、三姐，照着做，各自按自己人设来。";
      } else if (mentions.includes("所有人")) {
        ackText = "";   // 只是提醒大家：不产生规则、不派活
      } else {
        // v139: 家长引用了某条消息时，别再让大姐抢答「@X 家长叫你呢」——
        // 那句话会把被引用者本来就该接的话盖掉。
        const whoName = (msg.quote && msg.quote.text) ? "" : (mentions.find((n) => n !== "所有人" && n !== "大姐") || "");
        ackText = whoName ? ("@" + whoName + " 家长叫你呢，赶紧的。") : "";
      }
      if (ackText) {
        const ack = { ts: Date.now() + 1, who: "shiqi", name: "大姐", color: WHO.shiqi.color, tag: WHO.shiqi.tag, text: ackText, type: "rule", mentions };
        append(channel, ack);
        broadcast(channel, ack);
      }
    }
    return send(res, 200, { ok: true, msg });
  }

  // SSE
  if (p === "/api/stream") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const reqCh = clean(url.searchParams.get("channel") || FAMILY_CHANNEL, 30);
    const wantAll = reqCh === "__all" || reqCh === "*";
    if (wantAll && me.role !== "family" && me.role !== "bot") return send(res, 403, { ok: false });
    const channel = wantAll ? FAMILY_CHANNEL : reqCh;
    if (!wantAll && !canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    res.writeHead(200, {
      "content-type": "text/event-stream", "cache-control": "no-cache", connection: "keep-alive",
      "x-accel-buffering": "no", // 让 cloudflared / 反代别攒包，消息立刻推出去
    });
    res.write("retry: 3000\n\n");
    res.write(": hi\n\n");
    const entry = {
      res, channel, all: wantAll,
      sees: wantAll ? new Set(visibleChannels(me)) : null,
      id: me.id, role: me.role,
    };
    clients.add(entry);
    if (me.id) sseIds.add(me.id);
    try { const a = accounts.find((x) => x.id === me.id); if (a) { a.lastSeen = Date.now(); saveAccounts(); } } catch {}
    setTimeout(broadcastPresence, 20);
    const ping = setInterval(() => { try { res.write(": ping\n\n"); } catch {} }, 20000);
    req.on("close", () => {
      clearInterval(ping);
      clients.delete(entry);
      if (me.id) {
        let still = false;
        for (const c of clients) if (c.id === me.id) { still = true; break; }
        if (!still) {
          sseIds.delete(me.id);
          try {
            const a = accounts.find((x) => x.id === me.id);
            if (a) { a.lastSeen = Date.now(); saveAccounts(); if (a.role === "visitor") archiveVisitor(a); }
          } catch {}
        }
        broadcastPresence();
      }
    });
    return;
  }

  // 访客：是否允许把聊天记录存档到家长电脑（回忆用）
  if (p === "/api/share" && req.method === "POST") {
    const me = auth(req);
    if (!me || !me.id) return send(res, 401, { ok: false });
    const b = await body(req);
    const acc = accounts.find((a) => a.id === me.id);
    if (!acc) return send(res, 404, { ok: false });
    acc.share = !!b.share;
    saveAccounts();
    const sys = {
      ts: Date.now(), who: "system", name: "小屋", color: "#8f9bb3", tag: "",
      text: acc.share ? `「${acc.name}」打开了聊天存档。` : `「${acc.name}」关掉了聊天存档，以后不存他那段。`,
      type: "consent",
    };
    if (acc.role === "visitor") { append(FAMILY_CHANNEL, sys); broadcast(FAMILY_CHANNEL, sys); }
    return send(res, 200, { ok: true, share: acc.share });
  }

  // 上传图片（base64 dataURL，前端 FileReader 出来的）
  if (p === "/api/record" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    if (me.role === "visitor") return send(res, 403, { ok: false, err: "访客不能导出聊天记录" });
    const b = await body(req);
    const title = clean(b.title, 60) || "聊天记录";
    const count = Math.max(0, Math.min(2000, Number(b.count) || 0));
    const html = String(b.html || "");
    if (!html || html.length > 3145728) return send(res, 400, { ok: false, err: "内容为空或过大" });
    const id = crypto.randomBytes(9).toString("hex");
    try {
      fs.mkdirSync(RECORDS, { recursive: true });
      fs.writeFileSync(path.join(RECORDS, id + ".html"), html, "utf8");
      fs.writeFileSync(path.join(RECORDS, id + ".json"), JSON.stringify({ id: id, title: title, count: count, by: me.id, at: Date.now() }), "utf8");
    } catch (e) { return send(res, 500, { ok: false, err: "保存失败" }); }
    return send(res, 200, { ok: true, id: id, title: title, count: count });
  }
  if (p.startsWith("/record/") && (req.method === "GET" || req.method === "HEAD")) {
    const meR = auth(req);
    if (!meR) return send(res, 401, { ok: false });
    const mR = p.match(/^\/record\/([a-z0-9]{1,32})\.html$/);
    if (!mR) return send(res, 404, { ok: false });
    const fpR = path.join(RECORDS, mR[1] + ".html");
    if (!fs.existsSync(fpR)) return send(res, 404, { ok: false });
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    return res.end(fs.readFileSync(fpR));
  }

  if (p === "/api/asr" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    const raw = String(b.data || "");
    const b64 = raw.includes(",") ? raw.slice(raw.indexOf(",") + 1) : raw;
    if (b64.length < 600) return send(res, 400, { ok: false, err: "录音太短" });
    let buf;
    try { buf = Buffer.from(b64, "base64"); } catch (e) { return send(res, 400, { ok: false, err: "音频数据坏了" }); }
    const asrCands = [process.env.ROOM_ASR_URL, "http://127.0.0.1:8083/asr", "http://127.0.0.1:8083/asr", "http://10.0.0.2:8083/asr"].filter(Boolean);
    const t0 = Date.now();
    let lastErr = "";
    for (const asrUrl of asrCands) {
      try {
        const ctl = new AbortController();
        const to = setTimeout(() => ctl.abort(), 30000);
        const r = await fetch(asrUrl, { method: "POST", headers: { "content-type": "audio/wav" }, body: buf, signal: ctl.signal });
        clearTimeout(to);
        const j = await r.json().catch(() => ({ ok: false, err: "ASR 返回非 JSON" }));
        if (j && j.ok) { j.ms = j.ms || (Date.now() - t0); j.via = asrUrl; return send(res, 200, j); }
        lastErr = (j && j.err) || ("HTTP " + r.status);
      } catch (e) { lastErr = String(e.message || e); }
    }
    return send(res, 502, { ok: false, err: "语音识别服务没开（PC 的 asr-server 未运行？）", detail: lastErr });
  }

  if (p === "/api/video/cloudsync" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family" && me.role !== "bot") return send(res, 403, { ok: false, err: "只有家里人能搬视频" });
    const list = readVideos();
    const out = [];
    const dbg = [];
    for (const it of list) {
      if (it.cloud) continue;
      const fn = String(it.src || "").replace(/^\/videos\//, "");
      if (dbg.length < 3) dbg.push({ id: it.id, src: it.src, fn, exists: fn ? fs.existsSync(path.join(VID_DIR, fn)) : false, dir: VID_DIR });
      if (!fn) continue;
      const abs = path.join(VID_DIR, fn);
      if (!fs.existsSync(abs)) continue;
      const cu = await cloudUploadVideo(abs, fn);
      if (cu) { it.cloud = cu; out.push({ id: it.id, cloud: cu }); }
    }
    if (out.length) writeVideos(list);
    return send(res, 200, { ok: true, n: out.length, items: out, total: list.length, dbg });
  }

  if (p === "/api/videos" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const list = readVideos();
    const limit = Math.min(100, Math.max(1, Number(url.searchParams.get("limit") || 40) || 40));
    // v1.47b: 有云端副本时把 src 直接给成云端绝对地址，让旧版 APK（内嵌页面）也能边下边播
    const norm = list.map((it) => (it && it.cloud ? Object.assign({}, it, { src: it.cloud, cloudSrc: it.cloud }) : it));
    return send(res, 200, { ok: true, videos: norm.slice(0, limit), total: norm.length });
  }

  if (p === "/api/video" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false, err: "只有家里人能发视频" });
    const b = await body(req);
    const raw = String(b.data || "");
    const m3 = /^data:video\/([a-z0-9+.-]+);base64,(.+)$/i.exec(raw);
    if (!m3) return send(res, 400, { ok: false, err: "不是视频数据" });
    const ext = m3[1].toLowerCase() === "quicktime" ? "mov" : m3[1].toLowerCase();
    const buf = Buffer.from(m3[2], "base64");
    if (!buf.length) return send(res, 400, { ok: false, err: "空文件" });
    if (buf.length > 60 * 1024 * 1024) return send(res, 413, { ok: false, err: "视频太大（上限 60MB）" });
    const id = "v" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const fname = id + "." + ext;
    fs.writeFileSync(path.join(VID_DIR, fname), buf);
    cloudUploadVideo(path.join(VID_DIR, fname), fname).then((cu) => { if (cu) patchVideoCloud(id, cu); });
    const item = {
      id,
      ts: Date.now(),
      who: me.who || me.id || "laoda",
      name: me.name || me.id || "",
      title: String(b.title || "").slice(0, 60) || "未命名视频",
      src: "/videos/" + fname,
      size: buf.length,
      likes: {},
      views: 0,
    };
    const list = readVideos();
    list.unshift(item);
    writeVideos(list);
    broadcastRaw(FAMILY_CHANNEL, { type: "carousel", op: "add", item });
    return send(res, 200, { ok: true, item });
  }

  if (p === "/api/video/ingest" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family" && me.role !== "bot") return send(res, 403, { ok: false, err: "只有家里人能搬视频" });
    const b = await body(req);
    const file = String(b.file || "").replace(/[^\w.\-]/g, "");
    if (!file) return send(res, 400, { ok: false, err: "缺少文件名" });
    const fp = path.join(VID_DIR, file);
    if (!fs.existsSync(fp)) return send(res, 404, { ok: false, err: "文件不在 videos 目录" });
    const st = fs.statSync(fp);
    if (st.size < 50 * 1024) return send(res, 400, { ok: false, err: "文件太小" });
    const list = readVideos();
    const bvid = String(b.bvid || "").slice(0, 20);
    if (bvid && list.some((x) => String(x.bvid || "") === bvid)) return send(res, 200, { ok: true, dup: true });
    const who = WHO[b.who] ? b.who : "jiu";
    const item = {
      id: "v" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      ts: Date.now(),
      who,
      name: (WHO[who] && WHO[who].name) || who,
      title: String(b.title || file).slice(0, 120),
      src: "/videos/" + file,
      size: st.size,
      likes: {},
      views: 0,
      bvid,
      dur: Number(b.dur || 0),
      play: Number(b.play || 0),
      srcUrl: String(b.srcUrl || "").slice(0, 200),
      byBot: 1,
    };
    list.push(item);
    writeVideos(list);
    cloudUploadVideo(fp, file).then((cu) => { if (cu) patchVideoCloud(item.id, cu); });
    try { broadcastRaw(FAMILY_CHANNEL, { type: "carousel", op: "add", item }); } catch (e) {}
    return send(res, 200, { ok: true, item });
  }

  // ---- v1.49: 接入第三方视频（B站 iframe / 直链 / YouTube） ----
  if (p === "/api/video/link" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "\u8bf7\u5148\u767b\u5f55" });
    const b = await body(req);
    let u = String(b.url || "").trim();
    if (!u) return send(res, 400, { ok: false, err: "\u94fe\u63a5\u4e3a\u7a7a" });
    if (u.length > 1200) return send(res, 400, { ok: false, err: "\u94fe\u63a5\u592a\u957f" });
    const out = { ts: Date.now(), who: me.id || "laoda", name: WHO[me.id] ? WHO[me.id].name : (me.name || ""), color: WHO[me.id] ? WHO[me.id].color : "", likes: {}, views: 0, comments: [], local: 0, type: "link" };
    const bv = u.match(/BV[0-9A-Za-z]{10,12}/);
    const yt = u.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{6,20})/);
    if (bv) {
      out.title = String(b.title || "").trim() || ("B站视频 " + bv[0]);
      out.embed = "https://player.bilibili.com/player.html?bvid=" + bv[0] + "&autoplay=0&danmaku=0&high_quality=1";
      out.cloud = "";
    } else if (yt) {
      out.title = String(b.title || "").trim() || ("YouTube " + yt[1]);
      out.embed = "https://www.youtube.com/embed/" + yt[1] + "?rel=0";
      out.cloud = "";
    } else if (/\.(mp4|webm|m4v|mov|m3u8)(\?|#|$)/i.test(u) && /^https?:\/\//i.test(u)) {
      out.title = String(b.title || "").trim() || u.split("/").pop().split("?")[0];
      out.cloud = u;
      out.src = u;
    } else {
      return send(res, 400, { ok: false, err: "\u4ec5\u652f\u6301 B\u7ad9/YouTube \u94fe\u63a5\u6216 mp4/m3u8 \u76f4\u94fe" });
    }
    out.id = "v" + Math.random().toString(36).slice(2, 13);
    const list = readVideos();
    list.unshift(out);
    writeVideos(list.slice(0, 300));
    broadcastRaw(FAMILY_CHANNEL, { type: "video", item: out });
    return send(res, 200, { ok: true, item: out });
  }

  if (p === "/api/video/comment" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const id = String(b.id || "");
    const text = String(b.text || "").trim().slice(0, 300);
    if (!text) return send(res, 400, { ok: false, err: "评论为空" });
    const list = readVideos();
    const it = list.find((x) => x.id === id);
    if (!it) return send(res, 404, { ok: false, err: "没有这个视频" });
    it.comments = Array.isArray(it.comments) ? it.comments : [];
    const c = { ts: Date.now(), who: me.who || me.id || "", name: me.name || me.id || "", text };
    const as = String(b.as || "");
    if (as && WHO[as] && (me.role === "family" || me.role === "bot")) { c.who = as; c.name = WHO[as].name || as; }
    it.comments.push(c);
    if (it.comments.length > 60) it.comments = it.comments.slice(-60);
    writeVideos(list);
    try { broadcastRaw(FAMILY_CHANNEL, { type: "vcomment", id, comment: c }); } catch (e) {}
    return send(res, 200, { ok: true, comment: c, total: it.comments.length });
  }

  if (p === "/api/video/like" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const id = String(b.id || "");
    const list = readVideos();
    const it = list.find((x) => x.id === id);
    if (!it) return send(res, 404, { ok: false, err: "没有这个视频" });
    const uid = String(me.id || me.name || "me");
    it.likes = it.likes || {};
    if (it.likes[uid]) delete it.likes[uid]; else it.likes[uid] = 1;
    writeVideos(list);
    broadcastRaw(FAMILY_CHANNEL, { type: "carousel", op: "like", id, likes: it.likes });
    return send(res, 200, { ok: true, likes: it.likes, liked: !!it.likes[uid] });
  }

  if (p === "/api/video/view" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    const list = readVideos();
    const it = list.find((x) => x.id === String(b.id || ""));
    if (!it) return send(res, 404, { ok: false, err: "没有这个视频" });
    it.views = Number(it.views || 0) + 1;
    writeVideos(list);
    return send(res, 200, { ok: true, views: it.views });
  }

  if (p === "/api/upload" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    const channel = clean(b.channel || (me.role === "visitor" ? "v" + me.id : FAMILY_CHANNEL), 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false, err: "不能在这个频道发图" });
    const rawData = String(b.data || "");
    const b64 = rawData.includes(",") ? rawData.slice(rawData.indexOf(",") + 1) : rawData;
    const wantVid = String(b.kind || "") === "video" || /^data:video\//i.test(String(b.data || "").slice(0, 40));
    if (b64.length < 2000) return send(res, 400, { ok: false, err: (wantVid ? "这个视频是空的，换一个再发" : "这张图是空的（只有几字节），换一张再发") });
    const rel = saveMedia(channel, b.data, b.name);
    if (!rel) return send(res, 400, { ok: false, err: wantVid ? "视频太大或格式不对（限 25MB）" : "图片太大或格式不对（限 4MB）" });
    const msg = mediaMsg(me, channel, wantVid ? "video" : "image", rel, clean(b.text, 200));
    return send(res, 200, { ok: true, msg, media: rel });
  }

  // 表情库（手机本地的微信/QQ 表情包）
  if (p === "/api/stickers") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const n = Math.min(120, Math.max(1, Number(url.searchParams.get("n") || 48) || 48));
    const q = clean(url.searchParams.get("q") || "", 24).toLowerCase();
    let list = stickerList();
    let matchedBy = "random";
    if (q) {
      const ranked = stickerRank(list, q);
      if (ranked.length) { list = ranked; matchedBy = "intent"; }
      else {
        const sub = list.filter((s) => (s.series + " " + s.file).toLowerCase().includes(q));
        if (sub.length) { list = sub; matchedBy = "substring"; }
      }
    }
    const pool = list.slice();
    const picked = [];
    for (let i = 0; i < n && pool.length; i++) picked.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
    return send(res, 200, {
      ok: true, total: list.length,
      matchedBy,
      items: picked.map((s) => ({ series: s.series, file: s.file, url: "/sticker/" + encodeURIComponent(s.series) + "/" + encodeURIComponent(s.file) }))
    });
  }

  // 申请列表
  if (p === "/api/applications") {
    const me = auth(req);
    if (!me || (me.role !== "family" && me.role !== "bot")) return send(res, 403, { ok: false });
    return send(res, 200, applications.filter((a) => a.status === "pending").map((a) => {
      const v = voteSummary(a);
      return { id: a.id, accountId: a.accountId, name: a.name, identity: a.identity, createdAt: a.createdAt, yes: v.yes, no: v.no, votes: v.votes };
    }));
  }

  // 投票
  if (p === "/api/vote" && req.method === "POST") {
    const me = auth(req);
    if (!me || (me.role !== "family" && me.role !== "bot")) return send(res, 403, { ok: false });
    const b = await body(req);
    const app = applications.find((a) => a.id === clean(b.appId, 40));
    if (!app || app.status !== "pending") return send(res, 404, { ok: false, err: "没有这个申请" });
    const choice = b.vote === "no" ? "no" : "yes";
    const voterId = me.role === "bot" ? clean(b.voter || "shiqi", 20) : (me.who || me.id);
    try {
      fs.appendFileSync(path.join(DATA, "vote.log"), JSON.stringify({
        ts: Date.now(), role: me.role, meId: me.id, meWho: me.who || null, voterId,
        raw: String(b.voter || ""), ua: String(req.headers["user-agent"] || "").slice(0, 80),
        ip: req.socket.remoteAddress,
      }) + "\n");
    } catch {}
    app.votes = app.votes || {};
    app.votes[voterId] = choice;
    saveApps();
    const decided = applyDecision(app);
    const v = voteSummary(app);
    const sys = {
      ts: Date.now(), who: "shiqi", name: "大姐", color: WHO.shiqi.color, tag: WHO.shiqi.tag,
      text: decided === "active"
        ? `「${app.name}」进小屋了，欢迎。`
        : decided === "rejected"
          ? `「${app.name}」的申请没过。`
          : `投票：同意 ${v.yes} / 反对 ${v.no}，「${app.name}」${v.votes && v.votes.laoda === "yes" ? "还差家人一票" : "等家长点头"}。`,
      type: "vote", appId: app.id,
    };
    append(FAMILY_CHANNEL, sys);
    broadcast(FAMILY_CHANNEL, sys);
    return send(res, 200, { ok: true, status: app.status, yes: v.yes, no: v.no });
  }

  // 账号名单（家人/机器人）
  if (p === "/api/accounts") {
    const me = auth(req);
    if (!me || (me.role !== "family" && me.role !== "bot")) return send(res, 403, { ok: false });
    return send(res, 200, accounts.filter((a) => a.role === "visitor").map((a) => ({
      id: a.id, name: a.name, identity: a.identity, status: a.status, createdAt: a.createdAt,
    })));
  }

  // 踢人（家人）
  if (p === "/api/kick" && req.method === "POST") {
    const me = auth(req);
    if (!me || me.role !== "family") return send(res, 403, { ok: false });
    const b = await body(req);
    const acc = accounts.find((a) => a.id === clean(b.accountId, 40) && a.role === "visitor");
    if (!acc) return send(res, 404, { ok: false, err: "没有这个访客" });
    acc.status = "rejected";
    saveAccounts();
    // 踢人时把他还挂着的申请一并作废，免得列表里留一堆“待投票”
    let canceled = 0;
    for (const a of applications) {
      if (a.accountId === acc.id && a.status === "pending") { a.status = "canceled"; a.decidedAt = Date.now(); canceled++; }
    }
    if (canceled) saveApps();
    const sys = { ts: Date.now(), who: "shiqi", name: "大姐", color: WHO.shiqi.color, tag: WHO.shiqi.tag, text: `「${acc.name}」被请出小屋了。`, type: "vote" };
    append(FAMILY_CHANNEL, sys);
    broadcast(FAMILY_CHANNEL, sys);
    return send(res, 200, { ok: true });
  }

  // ---------- v1.21: 每日汇总（一天一条，按人分开算） ----------
  if (p === "/api/digest" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false });
    const date = todayStr();
    const flag = path.join(DATA, "digest-" + date + ".txt");
    if (fs.existsSync(flag) && !url.searchParams.get("force")) {
      let prev = "";
      try { prev = fs.readFileSync(flag, "utf8").trim(); } catch {}
      return send(res, 200, { ok: true, skipped: true, date, ts: prev });
    }
    const all = readDay(FAMILY_CHANNEL, date).filter((m) => !m.recalled && !m.type);
    const stat = { shiqi: { n: 0, st: 0, au: 0, h: {} }, jiu: { n: 0, st: 0, au: 0, h: {} }, hutao: { n: 0, st: 0, au: 0, h: {} } };
    let human = 0;
    for (const m of all) {
      const w = String(m.who || "");
      if (!stat[w]) { human++; continue; }
      stat[w].n++;
      if (m.kind === "sticker") stat[w].st++;
      if (m.kind === "audio") stat[w].au++;
      const hh = new Date(Number(m.ts || 0) + 8 * 3600e3).getUTCHours();
      stat[w].h[hh] = (stat[w].h[hh] || 0) + 1;
    }
    const label = { shiqi: "大姐", jiu: "二姐", hutao: "三姐" };
    const rows = ["shiqi", "jiu", "hutao"].map((k) => {
      const s = stat[k];
      const top = Object.keys(s.h).sort((a, b) => s.h[b] - s.h[a])[0];
      const peak = top === undefined ? "—" : `${top}点`;
      return { k, n: s.n, st: s.st, au: s.au, peak };
    });
    const total = rows.reduce((a, r) => a + r.n, 0);
    const maxRow = rows.slice().sort((a, b) => b.n - a.n)[0];
    const lines = rows.map((r) => `${label[r.k]} ${r.n} 条（表情 ${r.st}·语音 ${r.au}·高峰 ${r.peak}）`);
    const text = `【今日小结 ${date.slice(5)}】\n${lines.join("\n")}\n合计 ${total} 条｜家长 ${human} 条｜最活跃：${label[maxRow.k]}`;
    if (url.searchParams.get("dry")) {
      return send(res, 200, { ok: true, dry: true, date, text, rows, total, human });
    }
    const msg = {
      ts: Date.now(), who: "shiqi", name: "大姐", color: WHO.shiqi.color, tag: WHO.shiqi.tag,
      text, kind: "digest", digest: { date, rows, total, human },
    };
    append(FAMILY_CHANNEL, msg);
    broadcast(FAMILY_CHANNEL, msg);
    try { fs.writeFileSync(flag, String(msg.ts)); } catch {}
    return send(res, 200, { ok: true, date, text, rows, total, human });
  }

// ---------- v1.21: 机器人发言统计（按人分开、按日汇总） ----------
  if (p === "/api/botcount") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const ch = clean(url.searchParams.get("channel") || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(me, ch)) return send(res, 403, { ok: false });
    const date = clean(url.searchParams.get("date") || todayStr(), 12);
    const all = readDay(ch, date);
    const byWho = { shiqi: 0, jiu: 0, hutao: 0 };
    const bySticker = { shiqi: 0, jiu: 0, hutao: 0 };
    const byVoice = { shiqi: 0, jiu: 0, hutao: 0 };
    let botTotal = 0;
    for (const m of all) {
      if (m.recalled) continue;
      const w = String(m.who || "");
      if (!(w in byWho)) continue;
      botTotal++;
      byWho[w]++;
      if (m.kind === "sticker") bySticker[w]++;
      if (m.kind === "audio") byVoice[w]++;
    }
    const BOT_DAILY_MAX = Number(process.env.DAY_MAX || 150);
    return send(res, 200, {
      ok: true, channel: ch, date,
      byWho, bySticker, byVoice, botTotal,
      dailyMax: BOT_DAILY_MAX, left: Math.max(0, BOT_DAILY_MAX - botTotal),
      budget: { window: "10min", max: 8 },
      who: { shiqi: "大姐", jiu: "二姐", hutao: "三姐" },
    });
  }

  // ---------- v38: 撤回 / 编辑 / 表情回应 / 搜索 ----------
  if (p === "/api/recall" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const channel = clean(b.channel || FAMILY_CHANNEL, 30);
    const key = clean(b.key || "", 60);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    const hit = findMsg(channel, key);
    if (!hit) return send(res, 404, { ok: false, err: "找不到这条消息" });
    if (!iOwn(me, hit.msg)) return send(res, 403, { ok: false, err: "只能撤回自己的消息" });
    const m = rewriteMsg(hit, (x) => ({ ...x, recalled: 1, text: "", kind: "", media: "", url: "", title: "", rec: "" }));
    broadcastRaw(channel, { type: "patch", op: "recall", key, ts: Number(m.ts || 0) });
    return send(res, 200, { ok: true });
  }

  if (p === "/api/edit" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const channel = clean(b.channel || FAMILY_CHANNEL, 30);
    const key = clean(b.key || "", 60);
    const text = String(b.text || "").slice(0, 2000);
    if (!text.trim()) return send(res, 400, { ok: false, err: "内容不能为空" });
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    const hit = findMsg(channel, key);
    if (!hit) return send(res, 404, { ok: false, err: "找不到这条消息" });
    if (!iOwn(me, hit.msg)) return send(res, 403, { ok: false, err: "只能编辑自己的消息" });
    if (hit.msg.kind || hit.msg.recalled) return send(res, 400, { ok: false, err: "这条不能编辑" });
    const m = rewriteMsg(hit, (x) => ({ ...x, text, editedAt: Date.now() }));
    broadcastRaw(channel, { type: "patch", op: "edit", key, text, editedAt: m.editedAt, ts: Number(m.ts || 0) });
    return send(res, 200, { ok: true });
  }

  if (p === "/api/react" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const channel = clean(b.channel || FAMILY_CHANNEL, 30);
    const key = clean(b.key || "", 60);
    const emoji = String(b.emoji || "").slice(0, 8);
    if (!emoji) return send(res, 400, { ok: false, err: "表情为空" });
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    const hit = findMsg(channel, key);
    if (!hit) return send(res, 404, { ok: false, err: "找不到这条消息" });
    const uid = String(me.id || me.name || "me");
    const m = rewriteMsg(hit, (x) => {
      const rx = { ...(x.reactions || {}) };
      const arr = Array.isArray(rx[emoji]) ? rx[emoji].slice() : [];
      const i = arr.indexOf(uid);
      if (i >= 0) arr.splice(i, 1); else arr.push(uid);
      if (arr.length) rx[emoji] = arr; else delete rx[emoji];
      return { ...x, reactions: rx };
    });
    broadcastRaw(channel, { type: "patch", op: "react", key, reactions: m.reactions || {}, ts: Number(m.ts || 0) });
    return send(res, 200, { ok: true, reactions: m.reactions || {} });
  }

  if (p === "/api/search") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const q = String(url.searchParams.get("q") || "").trim().toLowerCase();
    if (q.length < 1) return send(res, 400, { ok: false, err: "搜索词为空" });
    const wantCh = clean(url.searchParams.get("channel") || "", 30);
    const limit = Math.min(100, Math.max(1, Number(url.searchParams.get("limit") || 40) || 40));
    const chans = wantCh ? [wantCh] : [FAMILY_CHANNEL, ...DM_LIST.map((d) => d.id)];
    const hits = [];
    for (const ch of chans) {
      if (!canSeeChannel(me, ch)) continue;
      for (const f of dayFiles(ch)) {
        const date = dayBase(f);
        const txt = readDayText(chanDir(ch), f);
        for (const ln of txt.split("\n")) {
          const t = ln.trim();
          if (!t) continue;
          let m;
          try { m = JSON.parse(t); } catch { continue; }
          if (m.recalled || !m.text) continue;
          if (String(m.text).toLowerCase().indexOf(q) < 0) continue;
          hits.push({ channel: ch, date, ts: Number(m.ts || 0), who: m.who || "", name: m.name || "", color: m.color || "", text: String(m.text).slice(0, 200), key: mkey(m) });
          if (hits.length >= limit * 4) break;
        }
        if (hits.length >= limit * 4) break;
      }
    }
    hits.sort((a, b) => b.ts - a.ts);
    return send(res, 200, { ok: true, q, hits: hits.slice(0, limit) });
  }

  // ---------- v1.15.2: 稳定升级入口（老版本客户端/好友都能用） ----------
  if (p === "/new" || p === "/upgrade" || p === "/latest") {
    const q = url.searchParams.get("file") || "";
    let target = "/download/familyroom.apk";
    if (q) {
      const fn = path.basename(q);
      if (/^[0-9A-Za-z._-]+\.apk$/.test(fn) && fs.existsSync(path.join(OLD_APK_DIR, fn))) target = "/download/old/" + fn;
    }
    res.writeHead(302, { Location: target, "Cache-Control": "no-store" });
    return res.end();
  }

  // ---------- v42: 在线状态页 ----------
  if (p === "/api/releases") {
    let items = [];
    try { items = JSON.parse(fs.readFileSync(path.join(OLD_APK_DIR, "old.json"), "utf8")).items || []; } catch {}
    return send(res, 200, { ok: true, current: { version: WEB_VERSION }, items });
  }
  if (p.startsWith("/download/old/")) {
    const fn = path.basename(decodeURIComponent(p.slice(14)));
    if (!/^[0-9A-Za-z._-]+\.apk$/.test(fn)) return send(res, 400, { ok: false });
    const fp = path.join(OLD_APK_DIR, fn);
    if (!fs.existsSync(fp)) return send(res, 404, { ok: false });
    const st = fs.statSync(fp);
    res.writeHead(200, {
      "content-type": "application/vnd.android.package-archive",
      "content-length": st.size,
      "content-disposition": 'attachment; filename="familyroom-' + fn + '"',
      "cache-control": "public, max-age=600",
    });
    return fs.createReadStream(fp).pipe(res);
  }
  if (p === "/releases" || p === "/releases.html") {
    try {
      const b = fs.readFileSync(path.join(HERE, "releases.html"), "utf8");
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache" });
      return res.end(b);
    } catch { return send(res, 404, { ok: false }); }
  }
  if (p === "/status") {
    if (req.method !== "GET") return send(res, 405, { ok: false });
    return sendC(req, res, 200, statusPage() || "<h1>status.html missing</h1>", "text/html; charset=utf-8");
  }
  if (p === "/api/status") {
    const online = presenceIds();
    const sisters = SISTERS.map((w) => {
      let lastTs = botSeen.get(w) || 0;
      try {
        const msgs = readDay(FAMILY_CHANNEL, todayStr()).slice(-300);
        for (const m of msgs) if (String(m.who) === w) lastTs = Math.max(lastTs, Number(m.ts || 0));
      } catch {}
      return { who: w, name: (WHO[w] && WHO[w].name) || w, color: (WHO[w] && WHO[w].color) || "", online: online.indexOf(w) >= 0, lastSeen: lastTs || 0 };
    });
    let msgsToday = 0;
    try { msgsToday = readDay(FAMILY_CHANNEL, todayStr()).length; } catch {}
    let bossLastSeen = 0;
    try { const a = (accounts || []).find((x) => x.id === "laoda"); bossLastSeen = (a && a.lastSeen) || 0; } catch {}
    let routerOk = false, tlsOk = false;
    try { routerOk = await portOpen(8080, 800); } catch {}
    try { tlsOk = await portOpen(8443, 600); } catch {}
    let cloud = { ok: false };
    try {
      const t0 = Date.now();
      const r = await fetch("http://203.0.113.10/box/metrics", { signal: AbortSignal.timeout(1600) });
      const j = await r.json();
      cloud = { ok: !!(j && j.ok), ms: Date.now() - t0, cpu: (j && j.cpu && j.cpu.loadPct) != null ? Math.round(j.cpu.loadPct) : null, mem: (j && j.mem && j.mem.usedPct) != null ? Math.round(j.mem.usedPct) : null };
    } catch (e) { cloud = { ok: false, err: String((e && e.message) || e).slice(0, 60) }; }
    let ver = "";
    try { ver = fs.readFileSync(path.join(HERE, "VERSION"), "utf8").trim(); } catch {}
    const members = (accounts || []).filter((a) => a.role === "family").length;
    const visitors = (accounts || []).filter((a) => a.role !== "family").length;
    return send(res, 200, {
      ok: true, host: "手机 · 家庭小屋", pid: process.pid, version: ver,
      uptime: Math.round(process.uptime()), ts: Date.now(),
      online, sisters, sisterList: sisters,
      bossOnline: online.indexOf("laoda") >= 0, bossLastSeen,
      msgsToday, msgsAll: countMsgsAll(), members, visitors,
      mute: inMute(),
      services: { room: true, router: routerOk, tls: tlsOk },
      cloud,
      history: (() => { try { const a = readJson(STATUS_HIST, []); return Array.isArray(a) ? a.slice(-120) : []; } catch { return []; } })(),
      publicUrl: "https://frp.example.com:65274/status",
    });
  }

    // ---------- v1.17.3: 公网单条分享页 ----------
  function _esc(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  if (p === "/s") {
    const ch = clean(url.searchParams.get("c") || FAMILY_CHANNEL, 30);
    const key = clean(url.searchParams.get("k") || "", 60);
    const hit = key ? findMsg(ch, key) : null;
    if (!hit || hit.msg.recalled) {
      res.writeHead(404, { "content-type": "text/html; charset=utf-8" });
      return res.end('<!doctype html><meta charset="utf-8"><body style="font:16px/1.6 system-ui;padding:40px;background:#111;color:#eee">这条消息不存在或已被撤回。</body>');
    }
    const m = hit.msg;
    const whoName = (m.name || (WHO[m.who] && WHO[m.who].name) || m.who || "").toString();
    let body = "";
    if (m.kind === "audio" && m.media) {
      body = '<audio controls preload="none" src="/uploads/' + _esc(m.media) + '"></audio>';
    } else if (m.kind && m.media) {
      body = '<img src="/uploads/' + _esc(m.media) + '">';
    } else {
      body = '<div class="t">' + _esc(m.text || "") + '</div>';
    }
    const when = new Date(Number(m.ts || Date.now())).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" });
    const html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
      + '<meta name="viewport" content="width=device-width,initial-scale=1">'
      + '<title>家庭小屋 · 分享</title><style>'
      + 'body{margin:0;background:#0f1115;color:#e6e6e6;font:16px/1.7 system-ui,-apple-system,"Noto Sans SC",sans-serif;padding:22px}'
      + '.card{max-width:560px;margin:6vh auto;background:#171a21;border:1px solid #262b36;border-radius:16px;padding:20px}'
      + '.who{font-weight:700;color:#7cc4ff;margin-bottom:8px}.t{white-space:pre-wrap;word-break:break-word}'
      + 'img{max-width:100%;border-radius:12px}audio{width:100%}'
      + '.when{margin-top:14px;color:#8b93a3;font-size:13px}.brand{margin-top:18px;color:#5b6472;font-size:12px;text-align:center}'
      + '</style></head><body><div class="card"><div class="who">' + _esc(whoName) + '</div>'
      + body + '<div class="when">' + _esc(when) + '</div></div>'
      + '<div class="brand">家庭小屋 · 单条消息分享</div></body></html>';
    res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    return res.end(html);
  }

  if (p === "/api/read" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const channel = clean(b.channel || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    const ts = Number(b.ts || 0);
    if (!(ts > 0)) return send(res, 400, { ok: false, err: "ts 无效" });
    const whoOv = (me.role === "bot" || me.role === "family") && b.who && WHO[b.who] ? String(b.who) : "";
    const key = whoOv ? String(WHO[whoOv].name || whoOv) : String(me.name || me.id || "me");
    const map = loadReads(channel);
    if ((map[key] || 0) < ts) {
      map[key] = ts;
      saveReads(channel, map);
      broadcastRaw(channel, { type: "reads", channel, reads: map });
    }
    return send(res, 200, { ok: true, reads: map });
  }

  if (p === "/api/read") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const channel = clean(url.searchParams.get("channel") || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    return send(res, 200, { ok: true, reads: loadReads(channel) });
  }

  // v126b: 前端错误上报（POST 任意登录用户写；GET 仅家人读最后 100 行）
  if (p === "/api/log" && req.method === "POST") {
    const b = await body(req);
    const line = JSON.stringify({
      ts: Date.now(),
      at: new Date().toISOString(),
      who: clean(b.who || "", 40),
      kind: clean(b.kind || "js", 20),
      msg: String(b.msg || "").slice(0, 800),
      src: String(b.src || "").slice(0, 400),
      stack: String(b.stack || "").slice(0, 1500),
      url: String(b.url || "").slice(0, 400),
      ua: String(req.headers["user-agent"] || "").slice(0, 200),
    });
    try { fs.appendFileSync(path.join(DATA, "client-errors.log"), line + "\n"); } catch (e) {}
    return send(res, 200, { ok: true });
  }

  if (p === "/api/log" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false, err: "只有家人能看" });
    let lines = [];
    try {
      const raw = fs.readFileSync(path.join(DATA, "client-errors.log"), "utf8").trim();
      if (raw) lines = raw.split("\n").slice(-100);
    } catch (e) {}
    return send(res, 200, { ok: true, lines });
  }


  // ---------- P0-1：数据保险 ----------
  if (p === "/api/export" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false, err: "只有家里人可以导出" });
    try {
      const r = await makeExport();
      return send(res, 200, { ok: true, ...r });
    } catch (e) { return send(res, 500, { ok: false, err: String((e && e.message) || e) }); }
  }
  if (p === "/api/exports") {
    const me = auth(req);
    if (!me || me.role !== "family") return send(res, 403, { ok: false });
    return send(res, 200, { ok: true, items: listExports() });
  }
  if (p === "/api/export/download") {
    const me = auth(req);
    if (!me || me.role !== "family") return send(res, 403, { ok: false });
    const nm = String(url.searchParams.get("name") || "");
    if (!/^room-[0-9]{8,20}\.tgz$/.test(nm)) return send(res, 400, { ok: false, err: "名字不合法" });
    const fp = path.join(EXPORTS, nm);
    if (!fs.existsSync(fp)) return send(res, 404, { ok: false, err: "没有这个包" });
    const st = fs.statSync(fp);
    res.writeHead(200, {
      "content-type": "application/gzip",
      "content-length": st.size,
      "content-disposition": 'attachment; filename="' + nm + '"',
      "cache-control": "no-store",
    });
    return fs.createReadStream(fp).pipe(res);
  }

  if (p === "/api/gallery") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const limit = Math.min(200, Math.max(12, Number(url.searchParams.get("limit") || 90) || 90));
    const before = Number(url.searchParams.get("before") || 0) || 0;
    const wantWho = clean(url.searchParams.get("who") || "", 20);
    const chans = [FAMILY_CHANNEL, ...DM_LIST.map((d) => d.id)].filter((ch) => canSeeChannel(me, ch));
    const items = [];
    for (const ch of chans) {
      let files = [];
      try {
        files = fs.readdirSync(chanDir(ch)).filter((f) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort().reverse();
      } catch { continue; }
      for (const f of files) {
        let txt = "";
        try { txt = fs.readFileSync(path.join(chanDir(ch), f), "utf8"); } catch { continue; }
        const rows = txt.split("\n");
        for (let k = rows.length - 1; k >= 0; k--) {
          const t = rows[k].trim();
          if (!t) continue;
          let m;
          try { m = JSON.parse(t); } catch { continue; }
          if (m.kind !== "image" && m.kind !== "video") continue;
          const uu = String(m.url || "");
          const media = m.media || (uu.indexOf("/media/") === 0 ? uu.slice(7) : "");
          if (!media) continue;
          const ts = Number(m.ts || 0);
          if (before && ts >= before) continue;
          if (wantWho && m.who !== wantWho) continue;
          items.push({ ts, who: m.who || "", name: m.name || "", color: m.color || "", channel: ch, kind: m.kind, media, text: String(m.text || "").slice(0, 80) });
          if (items.length >= limit * 2) break;
        }
        if (items.length >= limit * 2) break;
      }
    }
    items.sort((a, b) => b.ts - a.ts);
    const out = items.slice(0, limit);
    return send(res, 200, { ok: true, count: out.length, next: out.length >= limit ? out[out.length - 1].ts : 0, items: out });
  }

  // ---------- v126 P0-4: 纪念日 / 家规 ----------
  if (p === "/api/anniv" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    return sendC(req, res, 200, { ok: true, items: annivItems(), today: todayStr() });
  }
  if (p === "/api/anniv" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false, err: "只有家人能加纪念日" });
    const b = await body(req);
    const title = String(b.title || "").trim().slice(0, 40);
    let date = String(b.date || "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return send(res, 400, { ok: false, err: "日期要 YYYY-MM-DD" });
    if (!title) return send(res, 400, { ok: false, err: "写个名字吧" });
    const arr = loadJsonArr(ANNIV_FILE);
    if (arr.length >= 60) return send(res, 400, { ok: false, err: "太多了，先删几个" });
    const it = { id: "a" + Date.now().toString(36), title, date, note: String(b.note || "").slice(0, 120), yearly: b.yearly !== false, by: me.id || me.name, ts: Date.now() };
    arr.push(it);
    saveJsonArr(ANNIV_FILE, arr);
    broadcast(FAMILY_CHANNEL, { ts: Date.now(), who: "system", name: "纪念日", color: "#7aa2c8", text: "新增纪念日：" + title + "（" + date + "）", kind: "sys", nf: "q" });
    return sendC(req, res, 200, { ok: true, item: it });
  }
  if (p === "/api/anniv" && req.method === "DELETE") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false });
    const id = String(url.searchParams.get("id") || "");
    const arr = loadJsonArr(ANNIV_FILE).filter((x) => x.id !== id);
    saveJsonArr(ANNIV_FILE, arr);
    return sendC(req, res, 200, { ok: true });
  }
  if (p === "/api/anniv/ack" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const b = await body(req);
    const id = String(b.id || "");
    const fp = path.join(DATA, "anniv-posted.json");
    const m = loadJsonArr(fp);
    m.push({ id, day: todayStr(), ts: Date.now() });
    saveJsonArr(fp, m.slice(-400));
    return sendC(req, res, 200, { ok: true });
  }
  if (p === "/api/anniv/posted" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const rows = loadJsonArr(path.join(DATA, "anniv-posted.json")).filter((x) => x.day === todayStr());
    return sendC(req, res, 200, { ok: true, ids: rows.map((x) => x.id) });
  }
  if (p === "/api/pins" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    return sendC(req, res, 200, { ok: true, items: loadJsonArr(PINS_FILE) });
  }
  if (p === "/api/pins" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false, err: "只有家人能改家规" });
    const b = await body(req);
    const text = String(b.text || "").trim().slice(0, 200);
    if (!text) return send(res, 400, { ok: false, err: "内容不能为空" });
    const arr = loadJsonArr(PINS_FILE);
    if (arr.length >= 10) return send(res, 400, { ok: false, err: "家规最多 10 条" });
    const it = { id: "p" + Date.now().toString(36), text, by: me.id || me.name, ts: Date.now() };
    arr.push(it);
    saveJsonArr(PINS_FILE, arr);
    broadcast(FAMILY_CHANNEL, { type: "pins", items: arr });
    return sendC(req, res, 200, { ok: true, item: it, items: arr });
  }
  if (p === "/api/pins" && req.method === "DELETE") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    if (me.role !== "family") return send(res, 403, { ok: false });
    const id = String(url.searchParams.get("id") || "");
    const arr = loadJsonArr(PINS_FILE).filter((x) => x.id !== id);
    saveJsonArr(PINS_FILE, arr);
    broadcast(FAMILY_CHANNEL, { type: "pins", items: arr });
    return sendC(req, res, 200, { ok: true, items: arr });
  }

  // ---------- v126 P0-5: 记忆与成长可视化 ----------
  if (p === "/api/growth" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    if (me.role !== "family") return send(res, 403, { ok: false, err: "只有家人能看" });
    const ROOT = HERE;
    const pick = (rel) => path.join(ROOT, rel);
    const readTxt = (fp) => { try { return fs.readFileSync(fp, "utf8"); } catch { return ""; } };

    // 1) 长期记忆摘要
    const longTxt = readTxt(pick("memory/long.md")).trim();

    // 2) 每日摘要（memory/<date>.md）
    const digests = [];
    try {
      for (const f of fs.readdirSync(pick("memory"))) {
        if (!/^\d{4}-\d{2}-\d{2}\.md$/.test(f)) continue;
        const t = readTxt(pick("memory/" + f));
        digests.push({ date: f.slice(0, 10), chars: t.length, head: t.replace(/\s+/g, " ").slice(0, 90) });
      }
    } catch {}
    digests.sort((a, b) => (a.date < b.date ? 1 : -1));

    // 3) 成长记录 growth/*.md
    const growth = [];
    try {
      for (const f of fs.readdirSync(pick("growth"))) {
        if (!f.endsWith(".md")) continue;
        const t = readTxt(pick("growth/" + f));
        growth.push({ file: f, chars: t.length, head: t.replace(/\s+/g, " ").slice(0, 140) });
      }
    } catch {}
    growth.sort((a, b) => (a.file < b.file ? 1 : -1));

    // 4) 日记（diaries/<date>.md 或 diaries/<who>/<date>.md）
    const diaries = [];
    const scanDiary = (base, who) => {
      try {
        for (const f of fs.readdirSync(pick(base))) {
          const fp = path.join(pick(base), f);
          let st; try { st = fs.statSync(fp); } catch { continue; }
          if (st.isDirectory()) { scanDiary(base + "/" + f, f); continue; }
          if (!f.endsWith(".md")) continue;
          diaries.push({ who: who || "family", date: f.replace(/\.md$/, ""), chars: st.size });
        }
      } catch {}
    };
    scanDiary("diaries", "");

    // 5) 最近 30 天消息量（family 频道）
    const msgsDay = [];
    const dayMap = {};
    try {
      const cd = path.join(DATA, "msgs", FAMILY_CHANNEL);
      for (const f of fs.readdirSync(cd)) {
        if (!/^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)) continue;
        const date = f.slice(0, 10);
        let n = 0;
        try { n = readTxt(path.join(cd, f)).split("\n").filter((x) => x.trim()).length; } catch {}
        dayMap[date] = n;
      }
    } catch {}
    const nowD = new Date(Date.now() + 8 * 3600e3);
    for (let i = 29; i >= 0; i--) {
      const d = new Date(nowD.getTime() - i * 864e5).toISOString().slice(0, 10);
      msgsDay.push({ date: d, n: dayMap[d] || 0 });
    }

    // 6) 动态按天
    const momDay = {};
    try {
      const fp = path.join(DATA, "moments.json");
      const arr = JSON.parse(fs.readFileSync(fp, "utf8"));
      for (const m of arr) {
        const d = new Date(Number(m.ts || 0) + 8 * 3600e3).toISOString().slice(0, 10);
        momDay[d] = (momDay[d] || 0) + 1;
      }
    } catch {}

    const totalMsgs = Object.values(dayMap).reduce((a, b) => a + b, 0);
    return sendC(req, res, 200, {
      ok: true,
      long: longTxt.slice(0, 1200),
      longChars: longTxt.length,
      digests: digests.slice(0, 14),
      growth: growth.slice(0, 10),
      diaries: diaries.slice(0, 30),
      msgsDay,
      momentsDay: Object.keys(momDay).sort().slice(-14).map((d) => ({ date: d, n: momDay[d] })),
      stats: {
        totalMsgs,
        days: Object.keys(dayMap).length,
        digestCount: digests.length,
        growthCount: growth.length,
        diaryCount: diaries.length,
        momentCount: Object.values(momDay).reduce((a, b) => a + b, 0),
      },
    });
  }

  // ---------- v1.42 游戏厅：只存成绩与排行 ----------
  if (p === "/api/games" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const db = gamesDB();
    const out = GAMES.map((g) => {
      const mine = (db[g.id] && db[g.id][String(me.id || me.name)]) || null;
      const rows = rankRows(db, g.id, 3);
      return { ...g, myBest: mine ? mine.best : 0, myPlays: mine ? mine.plays : 0, top: rows };
    });
    return send(res, 200, { ok: true, games: out, me: me.id || me.name });
  }

  if (p === "/api/game/rank" && req.method === "GET") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const gid = clean(url.searchParams.get("game") || "", 20);
    const g = GAMES.find((x) => x.id === gid);
    if (!g) return send(res, 404, { ok: false, err: "没有这个游戏" });
    const db = gamesDB();
    return send(res, 200, { ok: true, game: g.id, rows: rankRows(db, g.id, 20) });
  }

  if (p === "/api/game/score" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "请先登录" });
    const b = await body(req);
    const g = GAMES.find((x) => x.id === clean(b.game || "", 20));
    if (!g) return send(res, 404, { ok: false, err: "没有这个游戏" });
    let score = Math.floor(Number(b.score));
    if (!isFinite(score) || score < 0) return send(res, 400, { ok: false, err: "分数不合法" });
    if (score > g.max) score = g.max;                       // 上限兜底（防瞎报）
    const ms = Math.floor(Number(b.ms || 0));
    if (ms > 0 && ms < 800) return send(res, 400, { ok: false, err: "太快了，像作弊" });
    const who = String(me.id || me.name);
    const db = gamesDB();
    db[g.id] = db[g.id] || {};
    const rec = db[g.id][who] || { best: 0, plays: 0, lastTs: 0, name: me.name || who };
    rec.plays += 1;
    rec.lastTs = Date.now();
    rec.name = me.name || rec.name;
    const improved = score > rec.best;
    if (improved) rec.best = score;
    db[g.id][who] = rec;
    saveGames(db);
    return send(res, 200, { ok: true, improved, best: rec.best, plays: rec.plays, top: rankRows(db, g.id, 3) });
  }

  
  // ---------- v1.44 share ----------
  if (p === "/api/share" && req.method === "POST") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false, err: "\u8bf7\u5148\u767b\u5f55" });
    const b = await body(req);
    let channel = clean(b.channel || FAMILY_CHANNEL, 30);
    if (!canSeeChannel(me, channel)) return send(res, 403, { ok: false });
    let text = String(b.text || "").trim();
    const key = clean(b.key || "", 60);
    let who = me.id, name = me.name, ts = Date.now();
    if (key) {
      const hit = findMsg(channel, key);
      if (!hit) return send(res, 404, { ok: false, err: "\u627e\u4e0d\u5230\u8fd9\u6761\u6d88\u606f" });
      text = String(hit.msg.text || "").trim();
      who = hit.msg.who || who;
      name = hit.msg.name || name;
      ts = Number(hit.msg.ts || ts);
    }
    if (!text) return send(res, 400, { ok: false, err: "\u6ca1\u6709\u53ef\u5206\u4eab\u7684\u6587\u5b57" });
    if (text.length > 1200) text = text.slice(0, 1200);
    const id = Math.random().toString(36).slice(2, 8);
    const item = { id: id, who: who, name: name, text: text, ts: ts, channel: channel, by: String(me.id || me.name), createdAt: Date.now() };
    const all = shares();
    all.unshift(item);
    saveShares(all.slice(0, 500));
    return send(res, 200, { ok: true, id: id, path: "/s/" + id });
  }

  if (p === "/api/share/list") {
    const me = auth(req);
    if (!me) return send(res, 401, { ok: false });
    const mine = String(me.id || me.name);
    const items = shares().filter(function (x) { return me.role === "family" || x.by === mine; }).slice(0, 50);
    return send(res, 200, { ok: true, items: items });
  }

  if (p.indexOf("/s/") === 0 && req.method === "GET") {
    const sid = clean(p.slice(3), 12);
    const it = shares().find(function (x) { return x.id === sid; });
    function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
    if (!it) {
      res.writeHead(404, { "content-type": "text/html; charset=utf-8" });
      return res.end("<!doctype html><meta charset=utf-8><body style=\"background:#0d1117;color:#8b949e;font-family:system-ui;padding:40px\">\u5206\u4eab\u4e0d\u5b58\u5728\u6216\u5df2\u8fc7\u671f</body>");
    }
    const d = new Date(Number(it.ts) || Date.now());
    const pad = function (n) { return String(n).padStart(2, "0"); };
    const when = d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes());
    const css = "body{margin:0;min-height:100vh;background:radial-gradient(1200px 600px at 50% -10%,#1b2a41,#0b0f16 60%);color:#e6edf3;font-family:-apple-system,'Segoe UI',system-ui,sans-serif;display:flex;align-items:center;justify-content:center;padding:24px}"
      + ".card{max-width:640px;width:100%;background:rgba(22,27,34,.86);border:1px solid #23303f;border-radius:18px;padding:26px 24px;box-shadow:0 18px 60px rgba(0,0,0,.55)}"
      + ".who{display:flex;align-items:center;gap:10px;font-size:14px;color:#9db4c9;margin-bottom:14px}"
      + ".dot{width:8px;height:8px;border-radius:50%;background:#3fb950;box-shadow:0 0 10px #3fb950}"
      + ".txt{font-size:19px;line-height:1.75;white-space:pre-wrap;word-break:break-word}"
      + ".foot{margin-top:22px;padding-top:14px;border-top:1px solid #22303d;font-size:12px;color:#6e7f90;display:flex;justify-content:space-between}";
    const html = "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
      + "<title>" + esc(it.name || it.who) + " \u7684\u5206\u4eab</title><style>" + css + "</style></head><body><div class=\"card\">"
      + "<div class=\"who\"><span class=\"dot\"></span>" + esc(it.name || it.who) + " \u00b7 \u5bb6\u5ead\u5c0f\u5c4b</div>"
      + "<div class=\"txt\">" + esc(it.text) + "</div>"
      + "<div class=\"foot\"><span>" + when + "</span><span>\u6765\u81ea\u5bb6\u5ead\u5c0f\u5c4b</span></div>"
      + "</div></body></html>";
    res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "public, max-age=300" });
    return res.end(html);
  }

return send(res, 404, { ok: false });
}

const server = http.createServer((req, res) => {
  Promise.resolve()
    .then(() => handleRequest(req, res))
    .catch((e) => {
      try { console.log("[req-error] " + req.method + " " + req.url + " :: " + ((e && e.stack) || e)); } catch {}
      try {
        if (res && typeof res.writeHead === "function" && !res.headersSent) {
          res.writeHead(500, { "content-type": "application/json; charset=utf-8" });
          res.end(JSON.stringify({ ok: false, err: "server error" }));
        }
      } catch {}
    });
});

// v40：兜底，别让一个漏网的异常把整个小屋带走
process.on("uncaughtException", (e) => {
  try { console.error("[uncaught]", (e && e.stack) || e); } catch {}
});
process.on("unhandledRejection", (e) => {
  try { console.error("[unhandledRejection]", (e && (e.stack || e.message)) || e); } catch {}
});

// ---------- 实时语音通话（v1.40） ----------
const CALL_PERSONA = {
  shiqi: "你是大姐，家里的大姐，住在电脑里。说话短、稳、带点操心，1~2 句，普通话口语。",
  jiu: "你是二姐，家里的二姐，说话像网吧老妹，短句、敢怼、嘴硬心软，1~2 句。",
  hutao: "你是三姐，家里的小妹，软一点、爱撒娇但会讲道理，1~2 句。",
};
const CALL_DIR = path.join(DATA, "calls");
try { fs.mkdirSync(CALL_DIR, { recursive: true }); } catch (e) { }
const CALL_QUOTA_SEC = Number(process.env.CALL_QUOTA_SEC || 1800);   // 家人每人每天 30 分钟
function callUsedSec(who) {
  try {
    const f = path.join(CALL_DIR, todayStr() + ".jsonl");
    if (!fs.existsSync(f)) return 0;
    return fs.readFileSync(f, "utf8").split("\n").filter(Boolean).map((l) => {
      try { const j = JSON.parse(l); return (j && j.who === who && j.secs) ? Number(j.secs) : 0; } catch (e) { return 0; }
    }).reduce((a, b) => a + b, 0);
  } catch (e) { return 0; }
}
function logCall(who, info, reason, userText) {
  try {
    const rec = {
      ts: Date.now(), who, secs: Math.round(info.secs || 0),
      audioBytes: info.audioBytes || 0, ttfaMs: info.ttfaMs || 0,
      textChars: info.textChars || 0, reason: reason || "",
      userSaid: String(userText || "").slice(0, 200),
      turns: Number(info.turns || 0),
      asr: String(info.asr || userText || "").slice(0, 200),
      reply: String(info.reply || "").slice(0, 200),
      startedAt: Date.now() - Math.round((info.secs || 0) * 1000),
      turns: Number(info.turns || 0),
      asr: String(info.asr || userText || "").slice(0, 200),
      reply: String(info.reply || "").slice(0, 200),
      startedAt: Date.now() - Math.round((info.secs || 0) * 1000),
    };
    fs.appendFileSync(path.join(CALL_DIR, todayStr() + ".jsonl"), JSON.stringify(rec) + "\n");
    console.log("[call] " + who + " " + rec.secs + "s ttfa=" + rec.ttfaMs + "ms " + rec.reason);
  } catch (e) { }
}

attachCall(server, {
  paths: ["/ws/call", "/call-ws"],
  whoOf: (r, u) => {
    const tk = u.searchParams.get("token") || u.searchParams.get("t") || "";
    let ac = null;
    try { ac = tk ? auth({ url: "http://x/?token=" + tk, headers: r.headers }) : auth(r); } catch (e) { ac = null; }
    if (!ac) return null;
    if (ac.role !== "family") return null;      // 只有家里人能打电话
    const q = u.searchParams.get("who");
    const w = (q === "shiqi" || q === "jiu" || q === "hutao") ? q : (ac.who || "jiu");
    return { who: w, name: ac.name };
  },
  budget: (who) => Math.max(0, CALL_QUOTA_SEC - callUsedSec(who)),
  onEnd: (who, info, reason, userText) => logCall(who, info, reason, userText),
});

server.listen(PORT, "0.0.0.0", () => {
  console.log("family-room v3 listening on 0.0.0.0:" + PORT);
  console.log("bot token file: " + BOT_FILE);
});

// 可选 HTTPS：同目录 tls/fullchain.pem + tls/privkey.pem 存在时，另开一个 TLS 端口
// 用途：樱花等国内隧道拦截明文 HTTP，必须走 HTTPS 才能通
const TLS_DIR = path.join(HERE, "tls");
const TLS_PORT = Number(process.env.ROOM_TLS_PORT || 8443);
try {
  const crt = path.join(TLS_DIR, "fullchain.pem");
  const key = path.join(TLS_DIR, "privkey.pem");
  if (fs.existsSync(crt) && fs.existsSync(key)) {
    const handler = server.listeners("request")[0];
    const tlsServer = https.createServer({ cert: fs.readFileSync(crt), key: fs.readFileSync(key) }, handler);
    tlsServer.listen(TLS_PORT, "0.0.0.0", () => {
      console.log("family-room v3 HTTPS listening on 0.0.0.0:" + TLS_PORT);
    });
  } else {
    console.log("no TLS cert at " + TLS_DIR + " , HTTPS listener skipped");
  }
} catch (e) {
  console.log("HTTPS listener failed: " + e.message);
}