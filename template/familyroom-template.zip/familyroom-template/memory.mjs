// family-room/memory.mjs —— 小屋「永存记忆」（跑在手机 Termux ~/familyroom，PC 上也能跑）
// 目的：让三姐妹在小屋里不是只有 16 条记忆，而是有长期记忆，且重启/重新开始都不丢。
// 用法：
//   node memory.mjs digest [YYYY-MM-DD]   # 把当天 family 频道聊天总结成 memory/<date>.md
//   node memory.mjs long                  # 把全部日记合并进 memory/long.md（永存，只增不减结构）
//   node memory.mjs auto                  # 缺今天的就总结；long 超过 7 天就合并（供 bot 自动调用）
//   node memory.mjs status                # 看现状
// 环境变量：HOME_DIR（默认 ~/familyroom）、MEM_LLM、MEM_KEY、MEM_MODEL
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const HOME = process.env.HOME_DIR || path.join(os.homedir(), "familyroom");
const MSGS = path.join(HOME, "data", "msgs");
const MEM = path.join(HOME, "memory");
const LONG = path.join(MEM, "long.md");
const LOG = path.join(HOME, "memory.log");

fs.mkdirSync(MEM, { recursive: true });

function log(m) {
  const line = new Date().toISOString() + " " + m;
  try { fs.appendFileSync(LOG, line + "\n"); } catch {}
  console.log(line);
}

// ---------- LLM 配置：优先环境变量，其次手机 ~/.router.json，最后手机本地 router ----------
function llmConf() {
  let c = {};
  try { c = JSON.parse(fs.readFileSync(path.join(os.homedir(), ".router.json"), "utf8")); } catch {}
  const base = process.env.MEM_LLM || (c.base ? String(c.base).replace(/\/$/, "") + "/chat/completions" : "http://127.0.0.1:8080/v1/chat/completions");
  const key = process.env.MEM_KEY || c.key || "sk-local-change-me";
  const model = process.env.MEM_MODEL || "deepseek-v4.1-flash";
  return { base, key, model };
}

async function ask(sys, user, maxTokens = 400) {
  const { base, key, model } = llmConf();
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 120000);
  try {
    const r = await fetch(base, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer " + key, "x-dsh-room": "1" },
      body: JSON.stringify({
        model,
        messages: [{ role: "system", content: sys }, { role: "user", content: user }],
        max_tokens: maxTokens, temperature: 0.4, enable_thinking: false, stream: false,
      }),
      signal: ctl.signal,
    });
    if (!r.ok) throw new Error("llm " + r.status + " " + (await r.text()).slice(0, 100));
    const o = await r.json();
    return String(o.choices?.[0]?.message?.content || "").trim();
  } finally { clearTimeout(t); }
}

// ---------- 读当天消息（不受 .reset 影响：记忆要保留被“重新开始”那段） ----------
function dayFile(date) { return path.join(MSGS, "family", date + ".jsonl"); }

function readDay(date) {
  const f = dayFile(date);
  if (!fs.existsSync(f)) return [];
  const out = [];
  for (const ln of fs.readFileSync(f, "utf8").split("\n")) {
    if (!ln.trim()) continue;
    let m; try { m = JSON.parse(ln); } catch { continue; }
    if (m.type) continue; // 只记人说的话，系统/投票提示不入记忆
    const txt = String(m.text || "").replace(/\s+/g, " ").trim();
    if (!txt) continue;
    out.push({ who: m.who === "laoda" ? "家长" : (m.name || m.who), text: txt, ts: m.ts || 0 });
  }
  return out;
}

function ymd(d) { return new Date(d.getTime() + 8 * 3600e3).toISOString().slice(0, 10); }

// ---------- 一天的小结 ----------
async function digest(date) {
  const date2 = date || ymd(new Date());
  const msgs = readDay(date2);
  const out = path.join(MEM, date2 + ".md");
  if (!msgs.length) { log("digest " + date2 + ": 没有消息，跳过"); return null; }
  if (fs.existsSync(out) && process.env.MEM_FORCE !== "1") { log("digest " + date2 + ": 已存在，跳过"); return out; }

  const lines = msgs.slice(-320).map((m) => m.who + "：" + m.text.slice(0, 200));
  const sys = "你在给一个家庭群聊写「当天记忆」，给三姐妹（大姐/玖/三姐）和家长以后回忆用。"
    + "只记录事实与情绪，不要编造，不要复述每句话。";
  const user = "日期：" + date2 + "\n聊天记录（从旧到新）：\n" + lines.join("\n")
    + "\n\n请输出 200~300 字的中文小结，分三小块，用短横线开头：\n"
    + "- 今天聊了什么（主要话题）\n- 家长的事（他说了什么、需要什么）\n- 姐妹们各自的近况/情绪（谁开心/谁闹别扭/谁被夸）\n"
    + "不要写“以上”“总之”，不要 markdown 标题。";

  let body = "";
  try { body = await ask(sys, user, 500); } catch (e) { log("digest llm fail: " + e.message); }
  if (!body) body = msgs.slice(-40).map((m) => m.who + "：" + m.text.slice(0, 60)).join("\n");

  const md = "# 小屋记忆 · " + date2 + "\n\n" + body.trim() + "\n";
  fs.writeFileSync(out, md, "utf8");
  log("digest " + date2 + " ok (" + body.length + " 字, " + msgs.length + " 条消息)");
  return out;
}

// ---------- 长期记忆：把每天的 md 融进一份永不重置的长记忆 ----------
function digestFiles() {
  if (!fs.existsSync(MEM)) return [];
  return fs.readdirSync(MEM).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f)).sort();
}

async function long(force) {
  const files = digestFiles();
  if (!files.length) { log("long: 还没有每日记忆"); return null; }
  const st = fs.existsSync(LONG) ? fs.statSync(LONG) : null;
  const newest = fs.statSync(path.join(MEM, files[files.length - 1])).mtimeMs;
  if (!force && st && st.mtimeMs > newest && Date.now() - st.mtimeMs < 7 * 86400e3) {
    log("long: 还新鲜，跳过"); return LONG;
  }
  const old = fs.existsSync(LONG) ? fs.readFileSync(LONG, "utf8").trim() : "";
  const fresh = files.slice(-4).map((f) => fs.readFileSync(path.join(MEM, f), "utf8").trim()).join("\n\n");
  const sys = "你在维护一份家庭群聊的长期记忆，给三姐妹和家长用。规则：只增不减——旧的重要事实必须保留，"
    + "新的变化在原条目上更新；删掉重复和鸡毛蒜皮；不编造。总长不超过 2500 字。";
  const user = (old ? "【已有长期记忆】\n" + old + "\n\n" : "")
    + "【最近的每日记忆】\n" + fresh
    + "\n\n输出更新后的长期记忆，用这些分块（有内容就写，没有就不写）：\n"
    + "## 家长\n## 大姐（大姐·电脑）\n## 玖（二姐·手机微信）\n## 三姐（小妹·QQ）\n## 家里的事\n## 约定与习惯\n"
    + "每条一行，短句，带日期（如 10-23）。";

  let body = "";
  try { body = await ask(sys, user, 1200); } catch (e) { log("long llm fail: " + e.message); }
  if (!body) {
    body = (old ? old + "\n\n" : "") + files.slice(-4).map((f) => fs.readFileSync(path.join(MEM, f), "utf8").trim()).join("\n\n");
    body = body.slice(-3000);
  }
  const md = "# 小屋长期记忆（永存）\n\n> 由 memory.mjs 自动合并；不是聊天上下文，不会因“重新开始”清空。\n\n" + body.trim() + "\n\n<!-- updated " + new Date().toISOString() + " -->\n";
  fs.writeFileSync(LONG, md, "utf8");
  log("long merged <- " + files.slice(-4).join(","));
  return LONG;
}

async function auto() {
  const today = ymd(new Date());
  await digest(today);
  // 昨天没写也补一下（跨零点的情况）
  const y = ymd(new Date(Date.now() - 86400e3));
  await digest(y);
  const st = fs.existsSync(LONG) ? fs.statSync(LONG) : null;
  if (!st || Date.now() - st.mtimeMs > 7 * 86400e3) await long(false);
}

function status() {
  const files = digestFiles();
  console.log("HOME =", HOME);
  console.log("每日记忆 =", files.length, files.slice(-5).join(","));
  console.log("long.md =", fs.existsSync(LONG) ? fs.statSync(LONG).size + " B" : "无");
  const t = ymd(new Date());
  console.log("今日(" + t + ")消息 =", readDay(t).length, "条");
}

const cmd = process.argv[2] || "status";
if (cmd === "digest") { await digest(process.argv[3]); }
else if (cmd === "long") { await long(true); }
else if (cmd === "auto") { await auto(); }
else { status(); }