// backfill-history.mjs —— 把「过去 36 小时」机器人说过的话补进 quality/history.jsonl
// 目的：v28 刚上线时历史为空，去重拿不到今天之前说过的话；先补一波，重复率才能立刻降下来。
// 用法：node backfill-history.mjs [天数=2]
import fs from "node:fs";
import path from "node:path";

const BASE = process.env.FAMILY_BASE || path.join(process.env.HOME || "/data/data/com.termux/files/home", "familyroom");
const QDIR = path.join(BASE, "quality");
const HIST = path.join(QDIR, "history.jsonl");
const MSG = path.join(BASE, "data", "msgs", "family");
const days = Number(process.argv[2] || 2);
const NOW = Date.now();
const WINDOW = 36 * 3600e3;

function norm(s) { return String(s || "").toLowerCase().replace(/[^\u4e00-\u9fa5a-z0-9]/gu, ""); }
function sk(t) {
  const s = norm(t);
  return s.slice(0, 4) + "|" + (/[?？吗呢吧]/.test(t) ? "Q" : /[!！]/.test(t) ? "!" : ".");
}

fs.mkdirSync(QDIR, { recursive: true });
const have = new Set();
try {
  for (const l of fs.readFileSync(HIST, "utf8").trim().split("\n")) {
    try { const o = JSON.parse(l); have.add(o.ts); } catch {}
  }
} catch {}

const files = fs.existsSync(MSG) ? fs.readdirSync(MSG).filter((f) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort().slice(-days - 1) : [];
const add = [];
for (const f of files) {
  const lines = fs.readFileSync(path.join(MSG, f), "utf8").trim().split("\n");
  for (const l of lines) {
    let m; try { m = JSON.parse(l); } catch { continue; }
    if (m.accountId !== "bot") continue;
    if (m.kind) continue;                 // 表情/图片不算“说过的话”
    const t = String(m.text || "").trim();
    if (!t || t.length < 2) continue;
    if (NOW - (m.ts || 0) > WINDOW) continue;
    if (have.has(m.ts)) continue;
    add.push({ ts: m.ts, who: m.who, text: t.slice(0, 200), sk: sk(t), backfill: 1 });
  }
}
add.sort((a, b) => a.ts - b.ts);
if (add.length) fs.appendFileSync(HIST, add.map((x) => JSON.stringify(x)).join("\n") + "\n");
console.log(JSON.stringify({ files: files.length, added: add.length, total: have.size + add.length, first: add[0] && add[0].text, last: add[add.length - 1] && add[add.length - 1].text }, null, 1));