// singify.mjs — 把 TTS 念出来的歌词变成"唱"出来（纯 Node，无依赖）
//
// 思路：逐句拿 TTS 音频 → 按字切音节 → 估每个音节的原音高 → 把音节重采样到旋律音符
//       （带颤音）→ 加一段简单的伴奏（和弦垫 + 贝斯 + 沙锤）→ 混音输出 wav。
// 这样音高跟着旋律走，就不再是平铺直叙的念。

const NOTE = (semi) => 261.6256 * Math.pow(2, semi / 12); // C4 = 0

// ---------- wav ----------
export function decodeWav(buf) {
  if (!buf || buf.length < 44 || buf.toString("ascii", 0, 4) !== "RIFF") throw new Error("not wav");
  let off = 12, fmt = null, data = null;
  while (off + 8 <= buf.length) {
    const id = buf.toString("ascii", off, off + 4);
    const sz = buf.readUInt32LE(off + 4);
    if (id === "fmt ") fmt = buf.slice(off + 8, off + 8 + sz);
    else if (id === "data") data = buf.slice(off + 8, off + 8 + sz);
    off += 8 + sz + (sz % 2);
  }
  if (!fmt || !data) throw new Error("wav chunks missing");
  const channels = fmt.readUInt16LE(2), sr = fmt.readUInt32LE(4), bits = fmt.readUInt16LE(14);
  const bytes = bits / 8;
  const frames = Math.floor(data.length / (bytes * channels));
  const x = new Float32Array(frames);
  for (let i = 0; i < frames; i++) {
    let s = 0;
    for (let c = 0; c < channels; c++) {
      const p = (i * channels + c) * bytes;
      if (bits === 16) s += data.readInt16LE(p) / 32768;
      else if (bits === 8) s += (data.readUInt8(p) - 128) / 128;
      else if (bits === 24) s += ((data.readUInt8(p) | (data.readUInt8(p + 1) << 8) | (data.readInt8(p + 2) << 16)) / 8388608);
      else if (bits === 32) s += data.readFloatLE(p);
    }
    x[i] = s / channels;
  }
  return { sr, x };
}

export function encodeWav(sr, x) {
  const n = x.length, data = Buffer.alloc(n * 2);
  for (let i = 0; i < n; i++) {
    let v = Math.max(-1, Math.min(1, x[i]));
    data.writeInt16LE(Math.round(v * 32767), i * 2);
  }
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(sr, 24); h.writeUInt32LE(sr * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
}

// ---------- 基础测量 ----------
function trim(x, sr, th = 0.004) {
  const n = x.length;
  let a = 0, b = n - 1;
  while (a < n - 1 && Math.abs(x[a]) < th) a++;
  while (b > a && Math.abs(x[b]) < th) b--;
  const padA = Math.max(0, a - Math.round(sr * 0.02)), padB = Math.min(n - 1, b + Math.round(sr * 0.04));
  return x.slice(padA, padB + 1);
}

function envelope(x, sr) {
  const hop = Math.max(1, Math.round(sr * 0.01)), win = Math.round(sr * 0.025);
  const frames = Math.max(1, Math.floor((x.length - win) / hop));
  const env = new Float32Array(frames);
  for (let k = 0; k < frames; k++) {
    let s = 0; const st = k * hop;
    for (let i = 0; i < win; i++) { const v = x[st + i] || 0; s += v * v; }
    env[k] = Math.sqrt(s / win);
  }
  return { env, hop };
}

// 在 [lo,hi) 内找能量最低点（幅度包络的局部极小）
function lowest(env, hop, lo, hi) {
  const a = Math.max(1, Math.floor(lo / hop)), b = Math.min(env.length - 2, Math.ceil(hi / hop));
  let bi = a, bv = Infinity;
  for (let i = a; i <= b; i++) if (env[i] < bv) { bv = env[i]; bi = i; }
  return bi * hop;
}

export function splitSyllables(x, sr, n) {
  const { env, hop } = envelope(x, sr);
  const seg = x.length / n;
  const cuts = [0];
  for (let i = 1; i < n; i++) {
    const exp = i * seg;
    const lo = Math.max(cuts[cuts.length - 1] + sr * 0.07, exp - seg * 0.32);
    const hi = Math.min(x.length - sr * 0.07, exp + seg * 0.32);
    let c = lo >= hi ? exp : lowest(env, hop, lo, hi);
    if (c <= cuts[cuts.length - 1] + sr * 0.05) c = cuts[cuts.length - 1] + sr * 0.05;
    cuts.push(Math.round(c));
  }
  cuts.push(x.length);
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = cuts[i], b = cuts[i + 1];
    if (b - a > sr * 0.03) out.push(x.slice(a, b));
  }
  return out;
}

// 归一化自相关估音高，返回 f0（Hz），无浊音返回 0
export function f0Of(x, sr, fmin = 70, fmax = 520) {
  const win = Math.round(sr * 0.04), hop = Math.round(sr * 0.02);
  const vals = [];
  const lagMin = Math.floor(sr / fmax), lagMax = Math.ceil(sr / fmin);
  for (let st = 0; st + win <= x.length; st += hop) {
    let e = 0;
    for (let i = 0; i < win; i++) e += x[st + i] * x[st + i];
    if (e < 1e-6) continue;
    let best = 0, bestLag = 0;
    for (let lag = lagMin; lag <= lagMax; lag++) {
      let s = 0;
      for (let i = 0; i < win - lag; i += 2) s += x[st + i] * x[st + i + lag];
      const r = s / (e * (1 - lag / win) + 1e-9);
      if (r > best) { best = r; bestLag = lag; }
    }
    if (best > 0.33 && bestLag > 0) {
      // 抛物线插值
      const y0 = bestLag > lagMin ? bestLag - 1 : bestLag, y2 = bestLag < lagMax ? bestLag + 1 : bestLag;
      const a1 = y0 === bestLag ? 0 : 0, a2 = 0;
      void a1; void a2;
      vals.push(sr / bestLag);
    }
  }
  if (!vals.length) return 0;
  vals.sort((a, b) => a - b);
  return vals[Math.floor(vals.length / 2)];
}

// ---------- 变调（带颤音）----------
function shift(chunk, sr, ratio, vibRate = 5.4, vibDepth = 0.012) {
  const n = Math.max(1, Math.floor(chunk.length / ratio));
  const out = new Float32Array(n);
  let pos = 0;
  for (let i = 0; i < n; i++) {
    const j = Math.floor(pos), f = pos - j;
    const a = chunk[j] || 0, b = chunk[j + 1] || 0;
    out[i] = a + (b - a) * f;
    pos += ratio * (1 + vibDepth * Math.sin((2 * Math.PI * vibRate * i) / sr));
    if (pos >= chunk.length - 2) { out.fill(0, i + 1); break; }
  }
  return out;
}

// ---------- TD-PSOLA：保共振峰地把音节“摁”到目标音高（唱，而不是念/花栗鼠） ----------
function frameF0s(x, sr, hopMs = 10, winMs = 40, fmin = 80, fmax = 600) {
  const hop = Math.max(1, Math.round((sr * hopMs) / 1000));
  const win = Math.max(hop * 2, Math.round((sr * winMs) / 1000));
  const n = Math.max(1, Math.ceil(x.length / hop));
  const f0 = new Float32Array(n);
  for (let k = 0; k < n; k++) {
    const st = k * hop;
    const len = Math.min(win, x.length - st);
    if (len < win * 0.5) break;
    let e = 0;
    for (let i = 0; i < len; i++) e += x[st + i] * x[st + i];
    if (e < 1e-5) continue;
    const lagMin = Math.floor(sr / fmax), lagMax = Math.min(Math.ceil(sr / fmin), len - 2);
    let best = 0, bestLag = 0;
    for (let lag = lagMin; lag <= lagMax; lag++) {
      let s = 0;
      for (let i = 0; i < len - lag; i++) s += x[st + i] * x[st + i + lag];
      const r = s / (e * (1 - lag / len) + 1e-9);
      if (r > best) { best = r; bestLag = lag; }
    }
    if (best > 0.3 && bestLag > 0) f0[k] = sr / bestLag;
  }
  return { f0, hop };
}

// 基音标记：从第一个浊音帧起，按局部周期前进，并在 ±T/3 内吸附到 |x| 最大的点（相位对齐，避免叠加抵消）
function pitchMarks(chunk, sr, f0, hop) {
  const marks = [];
  let k = 0;
  while (k < f0.length && !(f0[k] > 60)) k++;
  if (k >= f0.length) return marks;
  let m = k * hop;
  let guard = 0;
  while (m < chunk.length - 8 && guard++ < 4000) {
    const fi = Math.max(0, Math.min(f0.length - 1, Math.round(m / hop)));
    const f = f0[fi];
    if (!(f > 60)) { m += Math.round(sr / 180); continue; }
    const T = Math.round(sr / f);
    const lo = Math.max(1, m - Math.round(T / 3));
    const hi2 = Math.min(chunk.length - 2, m + Math.round(T / 3));
    let bestM = m, bestV = -1;
    for (let i = lo; i <= hi2; i++) { const v = Math.abs(chunk[i]); if (v > bestV) { bestV = v; bestM = i; } }
    marks.push(bestM);
    m = bestM + T;
  }
  return marks;
}

function psola(chunk, sr, ft, opt = {}) {
  const { f0, hop } = frameF0s(chunk, sr);
  const pos = [];
  for (let k = 0; k < f0.length; k++) if (f0[k] > 60) { pos.push(k * hop); }
  if (pos.length < 3) return shift(chunk, sr, 1);
  const marks = pitchMarks(chunk, sr, f0, hop);
  if (marks.length < 3) return shift(chunk, sr, 1);
  const first = pos[0];
  const last = Math.min(chunk.length, pos[pos.length - 1] + hop);
  const fsAvg = (() => { let s = 0, n = 0; for (const v of f0) if (v > 60) { s += v; n++; } return n ? s / n : 200; })();
  const Ts = sr / fsAvg;               // 源平均周期
  const Tt = sr / ft;                  // 目标平均周期
  const W = Math.max(8, Math.round(Ts * 2));
  const coreLen = Math.round((last - first) * (Tt / Ts));
  const out = new Float32Array(first + coreLen + (chunk.length - last) + W);
  for (let i = 0; i < first; i++) out[i] = chunk[i];
  for (let i = last; i < chunk.length; i++) out[first + coreLen + (i - last)] = chunk[i];
  const nOut = Math.max(2, Math.round(coreLen / Tt));
  const vibRate = opt.vibRate ?? 5.2, vibDepth = opt.vibDepth ?? 0.01;
  const gain = Tt / Ts;                // Hann 叠加的归一化
  let tOut = first;
  let mi = 0;
  for (let j = 0; j < nOut; j++) {
    const vib = 1 + vibDepth * Math.sin((2 * Math.PI * vibRate * tOut) / sr);
    const Ttj = Tt / vib;
    const tgt = Math.round((marks.length - 1) * (j / Math.max(1, nOut - 1)));
    mi = Math.max(0, Math.min(marks.length - 1, tgt));
    const m = marks[mi];
    const a = m - (W >> 1);
    for (let i = 0; i < W; i++) {
      const si = a + i;
      if (si < 0 || si >= chunk.length) continue;
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / W);
      const oi = Math.round(tOut + i);
      if (oi >= 0 && oi < out.length) out[oi] += chunk[si] * w;
    }
    tOut += Ttj;
  }
  for (let i = 0; i < out.length; i++) out[i] *= gain;
  return out;
}
function fade(x, sr, head = 0.012, tail = 0.035) {
  const h = Math.min(Math.round(sr * head), Math.floor(x.length / 2));
  const t = Math.min(Math.round(sr * tail), Math.floor(x.length / 2));
  for (let i = 0; i < h; i++) x[i] *= i / h;
  for (let i = 0; i < t; i++) x[x.length - 1 - i] *= i / t;
  return x;
}

// ---------- 旋律 ----------
const SCALE = { 1: 0, 2: 2, 3: 4, 5: 7, 6: 9 }; // C 大调五声（1 2 3 5 6），4/7 不用
const CELLS = [
  [[5, 1], [6, 1]],
  [[1, 1], [6, 1]],
  [[6, 0.5], [5, 0.5], [3, 1]],
  [[2, 0.5], [3, 0.5], [5, 1]],
  [[3, 1], [2, 1]],
  [[5, 0.5], [6, 0.5], [1, 1]],
  [[5, 1], [3, 1]],
  [[6, 1], [5, 1]],
  [[1, 0.5], [2, 0.5], [3, 1]],
  [[3, 1], [1, 1]],
];
function rng(seed) { let s = seed >>> 0 || 1; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; }

// 谱一段“歌”：按 2 拍一个动机拼句子，最后落在主音上
function melodyFor(n, seed) {
  const r = rng(seed);
  const out = [];
  let i = 0;
  while (out.length < n) {
    const cell = CELLS[Math.floor(r() * CELLS.length)];
    for (const [deg, beats] of cell) { if (out.length >= n) break; out.push({ deg, beats: Math.max(1, Math.min(2, Math.round(beats * 1.35))) }); }
    i++;
  }
  if (out.length) { out[out.length - 1].deg = 1; out[out.length - 1].beats = 2; }
  return out;
}

// 把一段采样时间伸缩到 outLen（不变调）
function resampleTo(x, outLen) {
  const y = new Float32Array(outLen);
  if (!x.length || outLen <= 0) return y;
  const step = x.length / outLen;
  for (let i = 0; i < outLen; i++) {
    const p = i * step;
    const i0 = Math.floor(p), f = p - i0;
    y[i] = (x[i0] || 0) * (1 - f) + (x[i0 + 1] || 0) * f;
  }
  return y;
}

// 时间伸缩 + 任意音高曲线：输出长度 outLen，音高由 ftFn(t秒) 给出（PSOLA，保共振峰）
export function psolaAt(chunk, sr, ftFn, outLen, opt = {}) {
  const { f0, hop } = frameF0s(chunk, sr);
  const pos = [];
  for (let k = 0; k < f0.length; k++) if (f0[k] > 60) pos.push(k * hop);
  if (pos.length < 3 || outLen < sr * 0.05) return resampleTo(chunk, Math.max(1, Math.round(outLen)));
  const marks = pitchMarks(chunk, sr, f0, hop);
  if (marks.length < 3) return resampleTo(chunk, Math.round(outLen));
  let fs = 0, cnt = 0;
  for (const v of f0) if (v > 60) { fs += v; cnt++; }
  const Ts = sr / (cnt ? fs / cnt : 200);
  const W = Math.max(8, Math.round(Ts * 2));
  const out = new Float32Array(Math.round(outLen) + W);
  const gain = 1; // Hann 叠加 ≈ 1
  let tOut = 0;
  let guard = 0;
  while (tOut < outLen - 1 && guard++ < 8000) {
    const tSec = tOut / sr;
    const ft = Math.max(60, Math.min(1200, ftFn(tSec)));
    const Tt = sr / ft;
    const ratio = Math.min(1, Math.max(0, tOut / Math.max(1, outLen)));
    const mi = Math.min(marks.length - 1, Math.round(ratio * (marks.length - 1)));
    const m = marks[mi];
    const a = m - (W >> 1);
    for (let i = 0; i < W; i++) {
      const si = a + i;
      if (si < 0 || si >= chunk.length) continue;
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / W);
      const oi = Math.round(tOut + i);
      if (oi >= 0 && oi < out.length) out[oi] += chunk[si] * w * gain;
    }
    tOut += Tt;
  }
  return out.subarray(0, Math.round(outLen));
}


// ---------- 伴奏（跟人声同一个节拍栅格） ----------
function accompaniment(totalSamples, sr, beatSec, beats, seed) {
  const acc = new Float32Array(totalSamples);
  const r = rng(seed + 7);
  const prog = [[0, 4, 7], [7, 11, 14], [9, 12, 16], [5, 9, 12]]; // I V vi IV
  const barBeats = 4;
  const barSamples = Math.round(beatSec * barBeats * sr);
  const add = (start, len, fn) => {
    for (let i = 0; i < len; i++) {
      const idx = start + i;
      if (idx >= 0 && idx < totalSamples) acc[idx] += fn(i);
    }
  };
  // 和弦垫（每小节一个）
  for (let b = 0, pos = 0; pos < totalSamples; b++, pos += barSamples) {
    const chord = prog[b % prog.length];
    const len = Math.min(barSamples, totalSamples - pos);
    for (const semi of chord) {
      const f = NOTE(semi + 12) * 0.5; // 中音区
      const ph = r() * 6.283;
      add(pos, len, (i) => {
        const t = i / sr;
        const env = Math.min(1, t / 0.08) * Math.exp(-t / 1.6);
        const trem = 0.85 + 0.15 * Math.sin(2 * Math.PI * 3.1 * t);
        return 0.035 * env * trem * Math.sin(ph + 2 * Math.PI * f * i / sr);
      });
    }
    // 贝斯：每小节 1、3 拍
    for (const beatOff of [0, 2]) {
      const bf = NOTE(chord[0] - 24);
      add(pos + Math.round(beatOff * beatSec * sr), Math.round(sr * 0.45), (i) => {
        const t = i / sr;
        return 0.11 * Math.exp(-t / 0.22) * (1 - Math.exp(-t / 0.004)) * Math.sin(2 * Math.PI * bf * i / sr);
      });
    }
    // 底鼓 1、3 拍；军鼓 2、4 拍
    for (const k of [0, 2]) add(pos + Math.round(k * beatSec * sr), Math.round(sr * 0.16), (i) => {
      const t = i / sr; return 0.16 * Math.exp(-t / 0.05) * Math.sin(2 * Math.PI * (52 + 90 * Math.exp(-t / 0.03)) * i / sr);
    });
    for (const s of [1, 3]) add(pos + Math.round(s * beatSec * sr), Math.round(sr * 0.14), (i) => {
      const t = i / sr; return 0.09 * Math.exp(-t / 0.045) * (r() * 2 - 1);
    });
  }
  // 八分音符沙锤
  const hat = Math.round(beatSec * sr * 0.5);
  for (let p = 0; p < totalSamples; p += hat) {
    add(p, Math.min(Math.round(sr * 0.035), totalSamples - p), (i) => 0.02 * Math.exp(-i / (sr * 0.009)) * (r() * 2 - 1));
  }
  return acc;
}

// ---------- 主流程 ----------
// lines: [{ text, wav: Buffer }]
export function singify(lines, opts = {}) {
  const wanted = opts.seed || 20261024;
  const bpm = opts.bpm || 76;
  const beatSec = 60 / bpm;
  const syl = [];
  let sr = 24000;
  for (const line of lines) {
    let dec;
    try { dec = decodeWav(line.wav); } catch { continue; }
    sr = dec.sr;
    const txt = String(line.text || "").replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, "");
    if (!txt) continue;
    const x = trim(dec.x, sr);
    const parts = splitSyllables(x, sr, txt.length);
    for (let i = 0; i < txt.length; i++) {
      const chunk = parts[Math.min(i, parts.length - 1)];
      if (!chunk || chunk.length < sr * 0.02) continue;
      syl.push({ ch: txt[i], chunk });
    }
  }
  if (!syl.length) throw new Error("no syllables");

  const notes = melodyFor(syl.length, wanted);
  const srcF = syl.map((s) => f0Of(s.chunk, sr) || 0);

  // 整体移调：旋律音程不变，只挑离人声本音最近的调（±12 半音内）
  let bestShift = 0, bestCost = Infinity;
  for (let k = -12; k <= 12; k++) {
    let cost = 0;
    for (let i = 0; i < syl.length; i++) {
      if (!srcF[i]) continue;
      const ft0 = NOTE(SCALE[notes[i].deg] + k);
      cost += Math.abs(12 * Math.log2(ft0 / srcF[i]));
    }
    if (cost < bestCost - 1e-6) { bestCost = cost; bestShift = k; }
  }

  // 栅格：每个音节占固定拍数，起点精确落在拍上（这才是“唱”的节奏）
  const plan = [];
  let tBeat = 0;
  for (let i = 0; i < syl.length; i++) {
    const n = notes[i];
    plan.push({
      ch: syl[i].ch, deg: n.deg, beats: n.beats,
      startBeat: tBeat, ftarget: NOTE(SCALE[n.deg] + bestShift),
      f0src: Math.round(srcF[i]),
    });
    tBeat += n.beats;
  }
  const totalBeats = tBeat;
  const totalSamples = Math.round(totalBeats * beatSec * sr);
  const vocal = new Float32Array(totalSamples);
  const VIB_RATE = 5.4, VIB_DEPTH = 0.014, VIB_DELAY = 0.28;

  let prevF = 0, prevEnd = -1e9;
  for (let i = 0; i < plan.length; i++) {
    const p = plan[i];
    const start = Math.round(p.startBeat * beatSec * sr);
    const outLen = Math.round(p.beats * beatSec * sr);
    const legato = i > 0 && start - prevEnd < sr * 0.06;
    const from = legato && prevF > 0 ? prevF : p.ftarget;
    if (srcF[i] > 0) {
      const ftFn = (t) => {
        const base = from * Math.pow(p.ftarget / from, Math.min(1, t / 0.09));
        const vd = VIB_DEPTH * Math.min(1, Math.max(0, (t - VIB_DELAY) / 0.25));
        return base * (1 + vd * Math.sin(2 * Math.PI * VIB_RATE * t));
      };
      const seg = psolaAt(syl[i].chunk, sr, ftFn, outLen);
      const n = Math.min(seg.length, totalSamples - start);
      for (let j = 0; j < n; j++) {
        const env = j < sr * 0.008 ? j / (sr * 0.008) : 1;
        vocal[start + j] += seg[j] * env;
      }
      prevF = p.ftarget;
    } else {
      const seg = resampleTo(syl[i].chunk, outLen);
      const n = Math.min(seg.length, totalSamples - start);
      for (let j = 0; j < n; j++) vocal[start + j] += seg[j] * 0.9;
      prevF = 0;
    }
    prevEnd = start + outLen;
  }

  // 句尾收淡
  const tail = Math.min(vocal.length, Math.round(sr * 0.25));
  for (let i = 0; i < tail; i++) vocal[vocal.length - 1 - i] *= i / tail;

  const acc = opts.accompaniment === false ? new Float32Array(totalSamples)
    : accompaniment(totalSamples, sr, beatSec, totalBeats, wanted);
  const mix = new Float32Array(totalSamples);
  let vp = 0, ap = 0;
  for (let i = 0; i < totalSamples; i++) {
    mix[i] = vocal[i];
    vp = Math.max(vp, Math.abs(vocal[i]));
    ap = Math.max(ap, Math.abs(acc[i]));
  }
  const vg = vp > 0 ? 0.85 / vp : 1;
  const ag = ap > 0 ? 0.30 / ap : 1; // 伴奏压到人声的 ~35%，不盖住唱
  for (let i = 0; i < totalSamples; i++) mix[i] = vocal[i] * vg + acc[i] * ag;
  let peak = 0;
  for (let i = 0; i < totalSamples; i++) peak = Math.max(peak, Math.abs(mix[i]));
  const g = peak > 0 ? 0.96 / peak : 1;
  for (let i = 0; i < totalSamples; i++) mix[i] *= g;

  return {
    wav: encodeWav(sr, mix), vocalWav: encodeWav(sr, vocal), sr,
    plan: plan.map((p) => ({ ch: p.ch, deg: p.deg, beats: p.beats, startBeat: p.startBeat, ftarget: Math.round(p.ftarget), f0src: p.f0src })),
    bpm, seconds: +(totalSamples / sr).toFixed(2),
  };
}

export function analyze(x, sr) {
  const f = f0Of(x, sr);
  return { f0: Math.round(f) };
}