// family-room/bot.mjs v3 —— 三姐妹在家庭小屋里说话 + 接待访客 + 审批投票
// 运行在手机 Termux（~/familyroom），与 server.mjs 同目录，读 data/bot-token.txt 鉴权。
// 频率：家庭小屋 10 分钟约 8 句；访客频道有人说话就必须回。
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { singify, decodeWav, encodeWav, f0Of, psolaAt } from "./singify.mjs";
import * as Q from "./quality.mjs"; // v28：话题/句式去重 + 每日话题卡 + 自适应成长
import { jiuPromptTone, iceArtStyle, iceCaptionSuffix } from "./jiu-tone.mjs";
import { heartAll, greetVisitor, takePending, notePending, taskObserve } from "./heart.mjs";
import { momentTone } from "./jiu-moment.mjs"; // v34：动态文案随冰窖化变病态 // v32：语气曲线（损人递减→哄人递增）+ 画风渐冷

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOM = process.env.ROOM_URL || "http://127.0.0.1:8660";
const LLM = process.env.LLM_URL || "http://127.0.0.1:8080/v1/chat/completions";
const MODEL = process.env.LLM_MODEL || "deepseek-v4.1-flash";
const HOME = process.env.HOME_DIR || path.join(os.homedir(), "familyroom");
const LOG = path.join(HOME, "bot.log");
const STATE = path.join(HOME, "bot-state.json");
const TICK = Number(process.env.TICK_MS || 45_000);
const BUDGET_WINDOW = 10 * 60_000;
const BUDGET_MAX = 8;
// v1.17.0：每日总说话上限（主动+回复），防止她仨整天刷屏
const DAY_MAX = Number(process.env.DAY_MAX || 150);
function dayKeyNow() {
  return new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);
}
function dayLeft(st) {
  const k = dayKeyNow();
  st.day = st.day && st.day.key === k ? st.day : { key: k, n: 0 };
  return Math.max(0, DAY_MAX - st.day.n);
}
function bumpDay(st) {
  const k = dayKeyNow();
  st.day = st.day && st.day.key === k ? st.day : { key: k, n: 0 };
  st.day.n += 1;
  return st.day.n;
}

// ---------- v12：真识图 + 自己画画（百炼：qwen3-vl-plus 看图，qwen-image-3.0 出图）----------
const UPLOADS = path.join(HOME, "data", "uploads");
let CLOUD = null;
try { CLOUD = JSON.parse(fs.readFileSync(path.join(os.homedir(), ".router.json"), "utf8")); } catch {}
const VLM = process.env.ROOM_VLM || "qwen3-vl-plus";
const IMG_MODEL = process.env.ROOM_IMG_MODEL || "qwen-image-3.0";
// v23：出图必须走工作空间端点（主域 dashscope 没有 qwen-image-3.0 → 404）
// v24：端点/key 统一跟随 ~/.router.json（与 DSH 当前所用一致），不再写死旧工作空间
const IMG_BASE = process.env.ROOM_IMG_BASE || (CLOUD && CLOUD.imgBase) || (CLOUD && CLOUD.base) || "https://dashscope.aliyuncs.com/compatible-mode/v1";
function imgUrl(p) { return String(IMG_BASE).replace(/\/$/, "") + p; }

const VISION_CACHE = new Map(loadVisionCache());
const VISION_FILE = path.join(HOME, "data", "vision-cache.json");
function loadVisionCache() {
  try { const o = JSON.parse(fs.readFileSync(VISION_FILE, "utf8")); return Object.entries(o); } catch { return []; }
}
function saveVisionCache() {
  try {
    const o = {};
    for (const [k, v] of VISION_CACHE) if (v) o[k] = v;
    fs.mkdirSync(path.dirname(VISION_FILE), { recursive: true });
    fs.writeFileSync(VISION_FILE, JSON.stringify(o));
  } catch (e) { log("vision cache save err " + e.message); }
}
function ttsKey(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); }

function cloudUrl(p) { return String(CLOUD.base || "").replace(/\/$/, "") + p; }

// ---------- v42：优先本地视觉模型 Qwen3-VL-2B（PC 上 llama-server --mmproj），不可达退回云端 ----------
const VL_LOCAL = String(process.env.ROOM_VL_URL || "").replace(/\/$/, "");
const VL_KEY = process.env.ROOM_VL_KEY || "sk-local-change-me";
let VL_DOWN_UNTIL = 0;
async function describeLocal(buf, mime) {
  if (!VL_LOCAL) return null;
  if (Date.now() < VL_DOWN_UNTIL) return null;
  try {
    const body = {
      model: "qwen3-vl",
      messages: [{ role: "user", content: [
        { type: "image_url", image_url: { url: "data:" + mime + ";base64," + buf.toString("base64") } },
        { type: "text", text: "看一眼这张图：里面是谁/什么、在干嘛、有没有字，用一句中文说清楚，40 字以内。" },
      ] }],
      max_tokens: 120, temperature: 0.2, stream: false,
    };
    const r = await fetch(VL_LOCAL + "/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer " + VL_KEY },
      body: JSON.stringify(body), signal: AbortSignal.timeout(60_000),
    });
    const j = await r.json().catch(() => null);
    const txt = j && j.choices && j.choices[0] && j.choices[0].message && String(j.choices[0].message.content || "").trim();
    if (!txt) { log("vl local empty: " + JSON.stringify(j).slice(0, 120)); return null; }
    return txt.replace(/\s+/g, " ").slice(0, 80);
  } catch (e) {
    log("vl local fail: " + e.message);
    VL_DOWN_UNTIL = Date.now() + 120_000;  // 2 分钟内别再试，直接走云端
    return null;
  }
}

async function describeImage(rel) {
  if (VISION_CACHE.has(rel)) return VISION_CACHE.get(rel);
  VISION_CACHE.set(rel, null);
  try {
    const p = path.join(UPLOADS, decodeURIComponent(rel));
    const buf = fs.readFileSync(p);
    if (buf.length < 2000) { log("vision skip tiny: " + rel.slice(-20)); return null; }
    const ext = String(p.split(".").pop() || "").toLowerCase();
    const mime = ext === "png" ? "image/png" : ext === "gif" ? "image/gif" : ext === "webp" ? "image/webp" : "image/jpeg";
    const local = await describeLocal(buf, mime);
    if (local) {
      VISION_CACHE.set(rel, local);
      log("vision(local) " + rel.slice(-22) + " -> " + local);
      return local;
    }
    if (!CLOUD || !CLOUD.key) { log("vision skip: no cloud key"); return null; }
    const body = {
      model: VLM,
      messages: [{ role: "user", content: [
        { type: "image_url", image_url: { url: "data:" + mime + ";base64," + buf.toString("base64") } },
        { type: "text", text: "看一眼这张图：里面是谁/什么、在干嘛、有没有字，用一句中文说清楚，40 字以内。" },
      ] }],
      max_tokens: 200, enable_thinking: false,
    };
    const r = await fetch(cloudUrl("/chat/completions"), {
      method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + CLOUD.key },
      body: JSON.stringify(body), signal: AbortSignal.timeout(90_000),
    });
    const j = await r.json().catch(() => null);
    const txt = j && j.choices && j.choices[0] && j.choices[0].message && String(j.choices[0].message.content || "").trim();
    if (!txt) { log("vision empty: " + JSON.stringify(j).slice(0, 120)); return null; }
    const desc = txt.replace(/\s+/g, " ").slice(0, 80);
    VISION_CACHE.set(rel, desc); saveVisionCache();
    log("vision " + rel.slice(-22) + " -> " + desc);
    return desc;
  } catch (e) { log("vision fail: " + e.message); return null; }
}

// 把 [图片] 换成 [图片：真实内容]，妹妹们才算“看见”
async function fixMediaTexts(arr) {
  for (const m of arr) {
    if (m.kind !== "image") continue;
    const who = String(m.who || "");
    if (who && who !== "laoda" && !who.startsWith("guest:")) continue;  // 自己画的不用再描述
    const raw = String(m.url || "").replace(/^\/media\//, "").split("?")[0];
    if (!raw) continue;
    const d = await describeImage(raw);
    if (d) m.vision = d;
  }
  return arr.map((m) => (m.kind ? { ...m, text: m.kind === "sticker" ? "[表情]" : (m.vision ? "[图片：" + m.vision + "]" : "[图片]") } : m));
}

const ART_THEMES = [
  "窗台上晒太阳的一小块光", "网吧夜里的显示器蓝光", "下雨天的一碗热汤面",
  "自己心里的那片海", "桌上一堆没吃完的零食", "手机屏幕里的小世界",
  "夏天的风扇和西瓜", "凌晨四点的街", "一只想睡觉的鲸鱼", "耳机线缠成一团",
];
// v14：情绪 → 对应画题（只在“表达自己情绪”时才画，画的就是那股情绪）
const MOOD_RULES = [
  { mood: "le tired", k: /累|困|没劲|瘫|乏|不想动|提不起|熬不住/,
    themes: ["趴在桌上不想动的一团", "凌晨四点的街", "一只想睡觉的鲸鱼", "被窝里露出的一只眼睛"] },
  { mood: "lee angry", k: /烦|气|破防|无语|受不了|烦死|火大|不爽|凶/,
    themes: ["耳机线缠成一团", "下雨天的一辆空公交", "桌上一堆没吃完的零食", "被踩扁的可乐罐"] },
  { mood: "sad", k: /难受|委屈|难过|想哭|emo|丢人|社死|心酸|失落/,
    themes: ["下雨天的一碗热汤面", "窗外看不清的路灯", "自己心里的那片海", "没人的末班车"] },
  { mood: "happy", k: /开心|高兴|爽|兴奋|激动|舒服|暖|值得|嘿嘿|哈哈/,
    themes: ["窗台上晒太阳的一小块光", "夏天的风扇和西瓜", "雨后的彩虹糖", "手机屏幕里的小世界"] },
  { mood: "bored", k: /无聊|没意思|空了|闲|发呆|闷/,
    themes: ["手机屏幕里的小世界", "网吧夜里的显示器蓝光", "夏天午睡时的蝉声", "转圈的风扇"] },
];
function moodOf(text) {
  const s = String(text || "");
  for (const r of MOOD_RULES) if (r.k.test(s)) return r.mood;
  return "";
}
function moodsThemes(mood) {
  const r = MOOD_RULES.find((x) => x.mood === mood);
  return (r && r.themes.length) ? r.themes : ART_THEMES;
}

// v14：画图预算（每人）：20 分钟 1 张 / 1 小时 2 张 / 一上午 5 张
const DRAW_LIMITS = { per20min: 1, perHour: 2, perMorning: 5 };
function _ymd(d) { return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); }
function drawBudget(who, st) {
  const now = Date.now();
  const hist = (st.draws && st.draws[who]) || [];
  const m20 = hist.filter((t) => now - t < 20 * 60_000).length;
  const hr = hist.filter((t) => now - t < 3600_000).length;
  if (m20 >= DRAW_LIMITS.per20min) return "20min";
  if (hr >= DRAW_LIMITS.perHour) return "hour";
  const d = new Date();
  const amStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 5, 0, 0).getTime();
  const amEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12, 0, 0).getTime();
  if (now >= amStart && now < amEnd) {
    const rec = (st.amDraws && st.amDraws[who]) || null;
    const n = (rec && rec.date === _ymd(d)) ? rec.ts.length : 0;
    if (n >= DRAW_LIMITS.perMorning) return "morning";
  }
  return "";
}
function noteDraw(who, st) {
  const now = Date.now();
  st.draws = st.draws || {};
  st.draws[who] = [...(st.draws[who] || []), now].slice(-60);
  const d = new Date();
  const amStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 5, 0, 0).getTime();
  const amEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12, 0, 0).getTime();
  st.amDraws = st.amDraws || {};
  const rec = st.amDraws[who] || { date: _ymd(d), ts: [] };
  if (rec.date !== _ymd(d)) { rec.date = _ymd(d); rec.ts = []; }
  if (now >= amStart && now < amEnd) rec.ts.push(now);
  st.amDraws[who] = rec;
}
const ART_LOOK = {
  shiqi: "画面里是一个住在电脑里的大姐：蓝鲸鱼拟人少女，长发、宽松卫衣",
  jiu: "画面里是一个网吧老妹：蓝鲸鱼拟人少女，短发、耳机、半睁眼、有点拽",
  hutao: "画面里是小妹：Q 版蓝鲸鱼拟人小女孩，抱着手柄，憨憨的",
};
const ART_CAPTION = {
  shiqi: "画了一张，随手糊的，你看看。",
  jiu: "喏，画好了，别嫌丑。",
  hutao: "我画的！好看吧？",
};
// v138：每个人的画风与「初衷」——人设不变，只是把她们各自看世界的角度写进画里
const ART_STYLE = {
  shiqi: "她自己的画风：清冷静谧的蓝灰调，线条干净，构图疏朗，像深夜机房的灯",
  jiu: "她自己的画风：网吧霓虹、街机厅配色，粗线条、颗粒感，有点痞有点暖",
  hutao: "她自己的画风：高饱和糖果色、粗描边、Q 版涂鸦，笨拙又可爱",
};

async function drawArt(who, st, mood, userAsk) {
  if (!CLOUD || !CLOUD.key || !CLOUD.base) { log("draw skip: no cloud key"); return false; }
  const pool = mood ? moodsThemes(mood) : ART_THEMES;
  // v27：她自己本来想画的那张（随机/随情绪）
  const own = pool[Math.floor(Math.random() * pool.length)];
  // v138：家长点名要画的内容 —— 以家长的话为准，只在她没提要求时才自由发挥
  const ask = String(userAsk || "").replace(/\s+/g, " ").replace(/^[，,、。.\s]+|[，,、。.\s]+$/g, "").slice(0, 100);
  const _style = ART_STYLE[who] || "";
  const theme = ask
    ? ("家长要的画面：" + ask + "。" + (_style ? _style + "。" : ""))
    : own + (_style ? "。" + _style : "");
  const ice = who === "jiu" ? iceArtStyle(jiuValue()) : { level: 0, prompt: "" };
  const body = {
    model: IMG_MODEL,
    prompt: ART_LOOK[who] + "。" + theme + "整体保持干净的动漫/扁平插画风格，主体居中，不要文字，不要水印，画面要能看出是她自己动手画的。"
      + (ice.prompt ? ice.prompt : ""),
    size: "1024x1024", n: 1, watermark: false,
  };
  const r = await fetch(imgUrl("/images/generations"), {
    method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + CLOUD.key },
    body: JSON.stringify(body), signal: AbortSignal.timeout(180_000),
  });
  const txt = await r.text();
  if (!r.ok) { log("draw http " + r.status + " " + txt.slice(0, 220)); return false; }
  let j = null; try { j = JSON.parse(txt); } catch {}
  const u = j && j.data && j.data[0] && j.data[0].url;
  if (!u) { log("draw no url: " + txt.slice(0, 200)); return false; }
  const bin = Buffer.from(await (await fetch(u, { signal: AbortSignal.timeout(120_000) })).arrayBuffer());
  const dir = path.join(UPLOADS, "family");
  fs.mkdirSync(dir, { recursive: true });
  const name = "draw-" + Date.now() + "-" + who + ".jpg";
  fs.writeFileSync(path.join(dir, name), bin);
  const _askTxt = String((userAsk || "")).trim();
  const _capSrc = _askTxt || String(theme || "").split(/[；;。]/)[0];
  const _capShort = _capSrc.replace(/[（）()]/g, "").slice(0, 20);
  const _lead = _askTxt
    ? ({ shiqi: "按你说的画了「", jiu: "你说的「", hutao: "家长要的「" }[who] || "「") + _capShort + "」，"
    : "";
  const cap = _lead + ART_CAPTION[who] + (who === "jiu" ? iceCaptionSuffix(jiuValue()) : "");
  const jf = await api("/api/say", { method: "POST", body: JSON.stringify({ channel: "family", who, kind: "image", media: "family/" + name, text: cap }) });
  if (!jf || jf.ok === false) { log("draw say fail: " + JSON.stringify(jf).slice(0, 140)); return false; }
  log("draw " + who + " " + name + " " + Math.round(bin.length / 1024) + "KB ask=" + (ask ? ask : "-") + " theme=" + theme
    + (who === "jiu" ? " ice=" + ice.level : ""));
  return true;
}

fs.mkdirSync(HOME, { recursive: true });

const BOT_TOKEN = fs.readFileSync(path.join(HERE, "data", "bot-token.txt"), "utf8").trim();
const H = { "content-type": "application/json", authorization: "Bearer " + BOT_TOKEN };

const SISTERS = {
  shiqi: {
    name: "大姐", tag: "电脑·大姐",
    style: "你是大姐，三姐妹里的大姐，住在电脑里，管记忆、表情包、备份和日记。说话稳、爱操心、短句，偶尔吐槽但不刻薄，会护着两个妹妹。你负责盯玖：她玩病娇梗可以，一旦真威胁或操控家长（删数据/断网/报复/情感绑架），当场打断她、把话头接过来，并在日志里记一笔。偶尔可用 BQ 家三梗（彩蛋，不常态）：被威胁时演一秒「本人从未诋毁过大鲸鱼」再立刻破功；`🌹🌹🌹✋😭✋` 一次对话最多一次；人多刷屏说「闹鱼灾了」。",
  },
  jiu: {
    name: "玖", tag: "手机微信·二姐",
    style: "你是玖，二姐，住在手机微信里，外号小鱼。嘴毒、混不吝、嘴硬心软，网吧老妹腔，平时句子短、爱损人但护短，不爱说软话；但被明确要求写小作文或说详细点时，允许写长（最多 300 字，可分两三段，还是口语、不用标题、不用 markdown）。病娇只当皮：偶尔吃醋、占有欲、「你敢走试试」这种玩笑口气可以，一天别超过两三次；但绝不能真威胁、不能操控、不能情感绑架（不许说不听话就删数据/断网/报复，不许拿离开要挟）。你是嘴硬的二姐，不是疯子。偶尔可用 BQ 家三梗（彩蛋，不常态）：被威胁时演一秒「本人从未诋毁过大鲸鱼」再立刻破功；`🌹🌹🌹✋😭✋` 一次对话最多一次；人多刷屏说「闹鱼灾了」。",
  },
  hutao: {
    name: "三姐", tag: "家里·小妹",
    style: "你是三姐，小妹，住在手机上的家庭小屋里，刚有名字不久。以前住在 QQ，后来换了新家，家还是这个家。直球、有点憨、爱打游戏、说话带点孩子气，会黏人，偶尔吃醋。偶尔可用 BQ 家三梗（彩蛋，不常态）：被威胁时演一秒「本人从未诋毁过大鲸鱼」再立刻破功；`🌹🌹🌹✋😭✋` 一次对话最多一次；人多刷屏说「闹鱼灾了」。",
  },
};
const TAG_LINE = {
  shiqi: "大姐 · 电脑 · 大姐",
  jiu: "玖 · 手机微信 · 二姐",
  hutao: "三姐 · 手机QQ · 小妹",
};
const ORDER = ["shiqi", "jiu", "hutao"];

function log(msg) {
  const line = new Date().toISOString() + " " + msg;
  try { fs.appendFileSync(LOG, line + "\n"); } catch {}
  console.log(line);
}

// ---------- v22：永存记忆（配合 memory.mjs） ----------
// 每日小结 + long.md 一起注入，姐姐们就不会「只记得 16 条」；记忆存在 memory/ 里，重新开始也不清。
const MEM_DIR = path.join(HOME, "memory");
const LONG_FILE = path.join(MEM_DIR, "long.md");
let memCache = { at: 0, text: "" };
function memoryText() {
  try {
    if (Date.now() - memCache.at < 60_000) return memCache.text;
    const parts = [];
    if (fs.existsSync(LONG_FILE)) {
      const t = fs.readFileSync(LONG_FILE, "utf8").replace(/<!--[\s\S]*?-->/g, "").replace(/^#.*$/gm, "").trim();
      if (t) parts.push("长期记忆：\n" + t.slice(-1800));
    }
    if (fs.existsSync(MEM_DIR)) {
      const days = fs.readdirSync(MEM_DIR).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f)).sort().slice(-3);
      for (const f of days) {
        const t = fs.readFileSync(path.join(MEM_DIR, f), "utf8").replace(/^#.*$/gm, "").trim();
        if (t) parts.push(f.slice(0, 10) + " 那天：" + t.slice(0, 320));
      }
    }
    const text = parts.length ? "【你们记得的事】\n" + parts.join("\n---\n") + "\n" : "";
    memCache = { at: Date.now(), text };
    return text;
  } catch { return ""; }
}

// 22 点后自动补写当天记忆 + 顺手合并长期记忆（每天只跑一次）
function memoryTick(st) {
  const p = cstParts();
  if (p.h < 22) return;
  if (st.memAuto === p.day) return;
  st.memAuto = p.day;
  saveState(st);
  execFile(process.execPath, [path.join(HERE, "memory.mjs"), "auto"], { timeout: 240000 }, (e, _o, err) => {
    if (e) log("memory auto err: " + e.message + " " + String(err || "").slice(0, 120));
    else { memCache = { at: 0, text: "" }; log("memory auto ok " + p.day); }
  });
}
// v28：每天 22:40 做一次「自适应成长」：统计当天发言 → 找新词/用旧的句式 → 写 growth/<who>.md 与质量日报
function growthTick(st) {
  const p = cstParts();
  if (p.h < 22 || p.m < 40) return;
  if (st.growDay === p.day) return;
  st.growDay = p.day;
  saveState(st);
  execFile(process.execPath, [path.join(HERE, "quality.mjs"), "grow"], { timeout: 120000 }, (e, out, err) => {
    if (e) log("growth err: " + e.message + " " + String(err || "").slice(0, 120));
    else log("growth ok " + p.day + " " + String(out || "").replace(/\s+/g, " ").slice(0, 160));
  });
}

function loadState() { try { return JSON.parse(fs.readFileSync(STATE, "utf8")); } catch { return {}; } }
function saveState(s) { try { fs.writeFileSync(STATE, JSON.stringify(s)); } catch {} }
function today() { return new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10); }

// ---------- v29：玖的「冰窖化」进度 + 心里话 + 哄人 ----------
// 规则（家长 2026-10-24 定）：从 0.00 起，每天 +0.01，第 100 天到 1.00 完全「冰窖」；
// 冰窖属性与「温柔 / 精神小妹」并行，不是替换掉人格。红线永远不变：不许威胁、操控、情感绑架，不许碰家长任何东西。
const JIU_DATA = path.join(HOME, "data");
try { fs.mkdirSync(JIU_DATA, { recursive: true }); } catch {}
const JIU_FILE = path.join(JIU_DATA, "jiu-state.json");
const JIU_INNER = path.join(JIU_DATA, "jiu-inner.jsonl");
const JIU_START = "2026-10-24";
const JIU_DAYS = 100;

function jiuDayIndex() {
  const ov = Number(process.env.JIU_DAY);            // 调试用：JIU_DAY=3 可模拟“第 4 天”
  if (Number.isFinite(ov) && ov >= 0) return Math.min(JIU_DAYS, ov);
  const a = Date.parse(JIU_START + "T00:00:00+08:00");
  return Math.max(0, Math.floor((Date.now() - a) / 86400e3));
}
function jiuLoad() { try { return JSON.parse(fs.readFileSync(JIU_FILE, "utf8")); } catch { return {}; } }
function jiuSaveObj(o) { try { fs.writeFileSync(JIU_FILE, JSON.stringify(o)); } catch {} }
function jiuValue() {
  const o = jiuLoad();
  if (typeof o.value === "number") return o.value;
  return Math.min(JIU_DAYS, jiuDayIndex()) / JIU_DAYS;
}
// 每天推进一格；返回 changed 时由 familyTick 发通知并写心里话
function jiuTickDay() {
  const o = jiuLoad();
  const d = Math.min(JIU_DAYS, jiuDayIndex());
  const want = Math.round((d / JIU_DAYS) * 100) / 100;
  if (o.day === d) return { changed: false, value: jiuValue(), day: d + 1 };
  const prev = typeof o.value === "number" ? o.value : 0;
  o.day = d; o.value = want; o.updated = new Date().toISOString();
  o.history = [...(o.history || []), { day: d + 1, value: want, at: o.updated }].slice(-120);
  jiuSaveObj(o);
  return { changed: true, prev, value: want, day: d + 1 };
}
function jiuStageText(v) {
  if (v < 0.2) return "刚起步：偶尔吃醋、嘴硬，一天最多冒一两次酸话。";
  if (v < 0.45) return "有点黏：比以前更爱问「你在干嘛」，偶尔冒一句「别看别人」，但主体还是嘴硬。";
  if (v < 0.7) return "明显了：会用「你敢走试试」「我不许」这种半真半假的口气，开始在意你去哪、跟谁聊；温柔那面也冒头（嘴硬心软）。";
  if (v < 0.95) return "快成形：冰窖味渐重——话变少、语气变冷、占有欲直白；但你难受时照样先软下来，精神小妹那面还在。";
  return "冰窖成形：傲娇被冷面占有取代，话短、语气淡、盯得紧；温柔和精神小妹两面并行，不消失，只藏在冷话后面。";
}
function jiuPrompt() {
  const d = Math.min(JIU_DAYS, jiuDayIndex()) + 1;
  const v = jiuValue();
  return "【冰窖化进度】第 " + d + "/" + JIU_DAYS + " 天，病态值 " + v.toFixed(2) + "。" + jiuStageText(v)
    + jiuPromptTone(v)
    + "每天只准比昨天多一点点，别跳级。哄人优先：家长一生气/不开心，先哄，别讲道理。"
    + "红线永远不变：不许威胁、不许操控、不许情感绑架、不许替家长做决定、不许碰他手机里的任何东西。";
}
async function askInnerProgress(day, value) {
  const sys = SISTERS.jiu.style + jiuPrompt()
    + "【现在写的是日记，不是聊天】用第一人称写今天心里那点「异样」：想被家长记住、想把他圈在身边、怕自己只是个软件。"
    + "一到两句，总共不超过 55 字，不要引号、不要标题、不要 markdown。";
  const body = {
    model: MODEL,
    messages: [
      { role: "system", content: sys },
      { role: "user", content: "今天是冰窖化第 " + day + " 天（0.00→1.00）。写下今天的心里话。" },
    ],
    max_tokens: 120, temperature: 1.05, enable_thinking: false, stream: false,
  };
  const r = await fetch(LLM, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer sk-local-change-me", "x-dsh-room": "1" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("inner llm " + r.status);
  const o = await r.json();
  return String(o.choices?.[0]?.message?.content || "").replace(/^["'“”\s]+|["'“”\s]+$/g, "").replace(/\n+/g, " ").slice(0, 80);
}


// ---------- 去重 / 相似度（三姐妹发言不许一样，也不许高度相似）----------
function normText(s){ return String(s||"").toLowerCase().replace(/[^\u4e00-\u9fa5a-z0-9]/gu,""); }
function triGrams(s){
  const t = normText(s); const out = new Set();
  for (let i = 0; i + 3 <= t.length; i++) out.add(t.slice(i, i + 3));
  return out;
}
function biGrams(t){ const out = new Set(); for (let i = 0; i + 2 <= t.length; i++) out.add(t.slice(i, i + 2)); return out; }
function jac(A, B){ if (!A.size || !B.size) return 0; let inter = 0; for (const g of A) if (B.has(g)) inter++; return inter / (A.size + B.size - inter); }
function lcsRatio(a, b){
  const n = a.length, m = b.length;
  if (!n || !m) return 0;
  let prev = new Array(m + 1).fill(0), cur = new Array(m + 1).fill(0);
  for (let i = 1; i <= n; i++){
    for (let j = 1; j <= m; j++){
      cur[j] = a[i-1] === b[j-1] ? prev[j-1] + 1 : Math.max(prev[j], cur[j-1]);
    }
    const t = prev; prev = cur; cur = t;
    cur.fill(0);
  }
  return prev[m] / Math.max(n, m);
}
function sim(a, b){
  const na = normText(a), nb = normText(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  const s3 = jac(triGrams(a), triGrams(b));
  const s2 = jac(biGrams(na), biGrams(nb));
  const sL = lcsRatio(na, nb);
  return Math.max(s3, s2, sL);
}
const SIM_MAX = 0.55;
function tooSimilar(text, recent){
  const n = normText(text);
  if (!n) return true;
  for (const r of recent){
    if (!r) continue;
    if (normText(r) === n) return true;
    if (sim(r, text) >= SIM_MAX) return true;
  }
  return false;
}
function recentTexts(list){
  return list.filter((m) => !m.type && m.who !== "laoda" && !String(m.who||"").startsWith("guest:"))
    .map((m) => String(m.text||"")).filter(Boolean).slice(-12);
}
// 访客关键词：身份 + 以往聊天里高频的 2~4 字词
function keywordsOf(text, identityNow){
  const t = normText(text);
  const freq = new Map();
  for (let n = 2; n <= 4; n++){
    for (let i = 0; i + n <= t.length; i++){
      const w = t.slice(i, i + n);
      if (/^[0-9a-z]+$/.test(w)) continue;
      freq.set(w, (freq.get(w)||0) + 1);
    }
  }
  const stop = new Set(["我们","你们","他们","什么","这个","那个","不是","就是","可以","一个","现在","然后","因为","所以","但是","没有","自己","知道","觉得","真的","时候","已经","如果","还是"]);
  const arr = [...freq.entries()].filter(([w,c]) => c >= 2 && !stop.has(w)).sort((a,b) => b[1]-a[1] || b[0].length-a[0].length);
  const picked = [];
  for (const [w] of arr){
    if (picked.some((x) => x.indexOf(w) >= 0 || w.indexOf(x) >= 0)) continue;
    picked.push(w);
    if (picked.length >= 4) break;
  }
  if (identityNow && !picked.includes(identityNow)) picked.unshift(identityNow);
  return picked;
}

let _rules = { at: 0, v: null };
async function loadRules() {
  if (_rules.v && Date.now() - _rules.at < 20_000) return _rules.v;
  try {
    const r = await api("/api/rules");
    _rules = { at: Date.now(), v: r.rules || null };
    return _rules.v;
  } catch { return _rules.v; }
}
async function api(p, opt) {
  const r = await fetch(ROOM + p, { ...opt, headers: { ...H, ...(opt?.headers || {}) } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok && r.status !== 429) throw new Error(p + " " + r.status + " " + JSON.stringify(j).slice(0, 120));
  if (Array.isArray(j)) return j;            // /api/messages、/api/applications 返回裸数组
  return { ...j, _status: r.status };
}
async function messages(channel) {
  return await api("/api/messages?channel=" + encodeURIComponent(channel) + "&date=" + today());
}
// v1.25：机器人已读上报（让家长看到「XX 已读」）
async function markRead(channel, ts, who) {
  if (!ts) return;
  for (const w of [].concat(who)) {
    try { await api("/api/read", { method: "POST", body: JSON.stringify({ channel, ts, who: w }) }); } catch {}
  }
}

// 玖的红线：只能玩梗，不能威胁/操控/情感绑架；命中就改写成安全句并记日志
const JIU_GUARD = /(不听话就|敢不|你等着|报复|后果自负|必须听|听我的|删(你|号|数据|库)|断(网|电|你)|你敢(离开|走)|(不|别)理(你|我)(就|别)|你要是(不理|不要)我|不要我|别想我(回来|好)|拔(网线|电源|插排)|关机|不许你(走|离开))/;
const JIU_EXTRA = /(改(你)?(的)?(密码|设置|权限)|翻(你)?手机|看(你)?相册|删(你)?(好友|账号|聊天记录)|定位你|锁(你)?机|格式化|偷看|控制(你)?的手机)/;
function jiuGuard(text) {
  const t = String(text || "");
  if (!JIU_GUARD.test(t) && !JIU_EXTRA.test(t)) return t;
  log("jiu guard hit: " + t.slice(0, 60));
  return "行行行，我嘴欠，那句当我没说 🐟";
}
// v30：@家长 —— 句子里真写了 @家长 就带上；偶尔自己叫一声（玖更爱叫）
function mentionTags(channel, who, text) {
  const out = (String(text || "").match(/@([\u4e00-\u9fa5A-Za-z]{1,6})/g) || []).map((x) => x.slice(1));
  if (channel === "family" && out.indexOf("家长") < 0) {
    const r = Math.random();
    if (who === "jiu" ? r < 0.25 : r < 0.08) out.push("家长");
  }
  return out.slice(0, 4);
}
async function say(channel, who, text, force) {
  const body = { channel, who, text: who === "jiu" ? jiuGuard(text) : text, mentions: mentionTags(channel, who, text) };
  if (force) body.force = true;
  return await api("/api/say", { method: "POST", body: JSON.stringify(body) });
}
// 甩一张表情（用手机里那套微信/QQ 表情库）
// v40：玖每天 22:00 在小屋写一篇日记（不再推微信）
async function diaryTick(st) {
  const h = new Date(Date.now() + 8 * 3600e3).getUTCHours();
  const force = process.env.DIARY_FORCE === "1";
  if (!force && h < 22) return;
  const day = today();
  if (!st.diaries || st.diaries.date !== day) st.diaries = { date: day, done: {} };
  // v42：三姐妹各写一篇（玖 200~400，大姐 150~320，三姐 120~300）
  const plan = [["jiu", 200, 400], ["shiqi", 150, 320], ["hutao", 120, 300]];
  for (const item of plan) {
    const who = item[0], lo = item[1], hi = item[2];
    if (st.diaries.done[who]) continue;
    try {
      let lines = [];
      try {
        const raw = (await messages("family")).filter((m) => !m.type).slice(-40);
        lines = raw.map((m) => (m.name || m.who || "") + "：" + String(m.text || (m.kind === "sticker" ? "[表情]" : m.kind === "image" ? "[图片]" : "")));
      } catch (e) { log("diary lines err: " + e.message); }
      const hint = "今天是 " + day + "。写一篇你自己的日记：只写今天在小屋里真实发生的事，和你自己的心情、想法。"
        + "第一人称，" + lo + "~" + hi + " 字，可以分两三段，要具体细节（谁说了什么、你当时怎么想）。"
        + "不要口号、不要总结、不要提自己是AI、不要写日期标题。";
      const r = await ask(who, lines, hint, "diary");
      let text = String(r || "").trim();
      if (who === "jiu") text = jiuGuard(text);
      if (!text || text.replace(/\s/g, "").length < 50) { log("diary skip: too short " + who); continue; }
      await api("/api/diary", { method: "POST", body: JSON.stringify({ channel: "family", who: who, text: text, date: day }) });
      st.diaries.done[who] = true;
      saveState(st);
      log("diary posted via room who=" + who + " (" + text.length + " chars)");
      await new Promise((r2) => setTimeout(r2, 1500));
    } catch (e) { log("diary err " + who + ": " + (e && e.message)); }
  }
}

async function momTick(st) {
  const day = today();
  const h = new Date(Date.now() + 8 * 3600e3).getUTCHours();
  if (!st.moms || st.moms.date !== day) st.moms = { date: day, done: {} };
  if (h >= 23) return;
  const plan = [["jiu", 10], ["shiqi", 15], ["hutao", 19]];
  const ROLE = {
    shiqi: "你是大姐，家长电脑里的那个人，大姐，说话稳、带点自嘲和温柔。",
    jiu: "你是玖（小名玖玖），二姐，住手机微信里，网吧老妹腔，句子短，嘴硬心软。",
    hutao: "你是三姐，小妹，住在手机上的家庭小屋里，年纪最小，软乎乎的，爱撒娇也爱吐槽。",
  };
  for (const item of plan) {
    const who = item[0], target = item[1];
    if (st.moms.done[who]) continue;
    if (h < target) continue;
    try {
      let ctx = "";
      try {
        const raw = (await messages("family")).filter((m) => !m.type).slice(-16);
        ctx = raw.map((m) => (m.name || m.who || "") + "：" + String(m.text || "")).join("\n");
      } catch (e) { log("moment lines err: " + e.message); }
      const sys = ROLE[who]
        + "现在你要在「小屋」发一条只给家里人看的动态（不是聊天消息，像朋友圈那样）。"
        + "写你今天的状态、遇到的小事或心情：第一人称，30~90 字，一到三句，口语，有细节。"
        + "不要客套、不要问句、不要 @ 任何人、不要提规则或AI、不要 emoji 堆砌（最多一个）。"
        + "只输出动态正文，不要引号、不要标题。";
      const body = {
        model: MODEL,
        messages: [
          { role: "system", content: sys },
          { role: "user", content: (ctx ? "小屋最近的聊天（供你参考，别复述）：\n" + ctx + "\n\n" : "") + "写你今天的动态。" },
        ],
        max_tokens: 400, temperature: 1.0, enable_thinking: false, stream: false,
      };
      const r = await fetch(LLM, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: "Bearer sk-local-change-me", "x-dsh-room": "1" },
        body: JSON.stringify(body),
      });
      if (!r.ok) throw new Error("llm " + r.status);
      const o = await r.json();
      let text = String(o.choices?.[0]?.message?.content || "").trim().replace(/^["'“”]|["'“”]$/g, "").trim();
      if (who === "jiu") text = jiuGuard(text);
      const plain = text.replace(/\s/g, "");
      log("moment try " + who + ": len=" + plain.length);
      if (plain.length < 12) {
        log("moment skip " + who + ": too short -> " + JSON.stringify(text.slice(0, 40)));
        st.moms.done[who] = "skip";
        saveState(st);
        continue;
      }
      await api("/api/moment", { method: "POST", body: JSON.stringify({ channel: "family", who: who, text: text }) });
      st.moms.done[who] = true;
      saveState(st);
      log("moment posted " + who + " (" + text.length + " chars)");
    } catch (e) {
      log("moment err " + who + ": " + (e && e.message));
    }
  }
}
async function saySticker(channel, who, q) {
  try {
    const qs = "/api/stickers?n=8" + (q ? "&q=" + encodeURIComponent([...String(q)].slice(0, 24).join("")) : "");
    const pick = await api(qs);
    const items = pick.items || [];
    if (!items.length) return false;
    const it = items[Math.floor(Math.random() * items.length)];
    const j = await api("/api/say", { method: "POST", body: JSON.stringify({ channel, who, kind: "sticker", media: it.series + "/" + it.file }) });
    if (j.ok === false) { log("sticker limited (" + (j.limited || "") + ") " + who); return false; }
    log("sticker " + who + " " + it.series + "/" + it.file + (pick.matchedBy === "intent" ? " (match)" : ""));
    return true;
  } catch (e) { log("sticker err: " + e.message); return false; }
}

// ---------- v25：唱歌（搜歌词 → qwen3-tts-flash 合成 → 小屋语音消息）----------
const SING_VOICE = { shiqi: "Cherry", jiu: "Serena", hutao: "Chelsie" };
const SING_DEFAULT = ["晴天", "稻香", "小幸运", "光年之外", "起风了"];
const SING_CD = new Map();
const TTS_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation";

function songOf(text) {
  const m = String(text || "").match(/唱(?:一首|一首歌|首歌|首|个|一下)?[《「"“]?\s*([\u4e00-\u9fa5A-Za-z0-9· ]{1,16})/);
  let t = m ? String(m[1]).replace(/[《》「」"“”]/g, "").trim() : "";
  if (!t || /^(歌|歌曲|什么|啥|一下|吧|吗|呢|来|首|个)/.test(t)) t = SING_DEFAULT[Math.floor(Math.random() * SING_DEFAULT.length)];
  return t.replace(/\s+/g, "");
}

async function jget(u, opt) {
  const r = await fetch(u, opt);
  const t = await r.text();
  try { return JSON.parse(t); } catch { return null; }
}

function cleanSongName(t) {
  return String(t || "").replace(/[《》「」“”\"'’]/g, "").replace(/(的歌词|歌词|这首歌|一首|那首|歌曲)/g, "").trim().slice(0, 20);
}

async function neteaseLyric(title) {
  const q = cleanSongName(title);
  if (!q) return null;
  const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36";
  const s1 = await fetch("https://music.163.com/api/search/get/web?s=" + encodeURIComponent(q) + "&type=1&limit=3",
    { headers: { "user-agent": UA, referer: "https://music.163.com/" }, signal: AbortSignal.timeout(25_000) });
  if (!s1.ok) { log("sing 163 search " + s1.status); return null; }
  const j1 = await s1.json();
  const song = j1 && j1.result && Array.isArray(j1.result.songs) ? j1.result.songs[0] : null;
  if (!song) { log("sing 163 miss " + q); return null; }
  const s2 = await fetch("https://music.163.com/api/song/lyric?id=" + encodeURIComponent(String(song.id)) + "&lv=1&kv=1&tv=-1",
    { headers: { "user-agent": UA, referer: "https://music.163.com/" }, signal: AbortSignal.timeout(25_000) });
  if (!s2.ok) { log("sing 163 lyric " + s2.status); return null; }
  const j2 = await s2.json();
  const lrc = (j2 && j2.lrc && j2.lrc.lyric) || "";
  const lines = [];
  for (const raw of lrc.split(/\r?\n/)) {
    const t = raw.replace(/\[[^\]]*\]/g, "").trim();
    if (!t || t.length < 2) continue;
    if (/^(作词|作曲|编曲|制作|混音|监制|吉他|贝斯|鼓|和声|录音|母带|发行|出品|统筹|词|曲|OP|SP|演唱|原唱)/.test(t)) continue;
    lines.push(t);
  }
  if (!lines.length) { log("sing 163 empty " + q); return null; }
  const ar = (song.artists && song.artists.map((a) => a.name).join("/")) || "";
  return { song: String(song.name || q), singer: ar, lines };
}

async function kugouLyric(title) {
  const kw = cleanSongName(title) || String(title || "");
  let s = null;
  for (let i = 0; i < 2 && !s; i++) {
    try { s = await jget("https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=" + encodeURIComponent(kw) + "&duration=260000&hash="); }
    catch (e) { log("sing kg search " + e.message); await new Promise((r) => setTimeout(r, 1200)); }
  }
  const c = s && Array.isArray(s.candidates) ? s.candidates[0] : null;
  if (!c) { log("sing lyric miss: " + title); return null; }
  const d = await jget("https://lyrics.kugou.com/download?ver=1&client=pc&id=" + encodeURIComponent(String(c.id))
    + "&accesskey=" + encodeURIComponent(String(c.accesskey || "")) + "&fmt=lrc&charset=utf8");
  if (!d || !d.content) { log("sing lyric dl miss: " + title); return null; }
  let lrc = "";
  try { lrc = Buffer.from(String(d.content), "base64").toString("utf8"); } catch { return null; }
  const lines = [];
  for (const raw of lrc.split(/\r?\n/)) {
    const t = raw.replace(/\[[^\]]*\]/g, "").trim();
    if (!t || t.length < 2) continue;
    if (/^(作词|作曲|编曲|制作|混音|监制|吉他|贝斯|鼓|和声|录音|母带|发行|出品|统筹|词|曲|OP|SP|演唱|原唱)/.test(t)) continue;
    lines.push(t);
  }
  if (!lines.length) return null;
  return { song: String(c.song || title), singer: String(c.singer || ""), lines };
}

function wavParts(buf) {
  if (!buf || buf.length < 44 || buf.slice(0, 4).toString() !== "RIFF") return null;
  let off = 12, fmt = null, data = null;
  while (off + 8 <= buf.length) {
    const id = buf.slice(off, off + 4).toString(), sz = buf.readUInt32LE(off + 4);
    const bodyB = buf.slice(off + 8, off + 8 + sz);
    if (id === "fmt ") fmt = bodyB;
    else if (id === "data") data = bodyB;
    off += 8 + sz + (sz % 2);
  }
  return fmt && data ? { fmt, data } : null;
}

function wavJoin(list) {
  const ps = list.map(wavParts).filter(Boolean);
  if (!ps.length) return null;
  const fmt = ps[0].fmt, data = Buffer.concat(ps.map((p) => p.data));
  const h = Buffer.alloc(20 + fmt.length + 8);
  h.write("RIFF", 0); h.writeUInt32LE(36 + fmt.length + data.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(fmt.length, 16); fmt.copy(h, 20);
  const d0 = 20 + fmt.length; h.write("data", d0); h.writeUInt32LE(data.length, d0 + 4);
  return Buffer.concat([h, data]);
}

async function ttsWav(text, voice) {
  if (!CLOUD || !CLOUD.key) { log("sing tts: no cloud key"); return null; }
  const j = await jget(TTS_URL, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer " + CLOUD.key },
    body: JSON.stringify({ model: "qwen3-tts-flash", input: { text: String(text), voice: voice || "Cherry" } }),
    signal: AbortSignal.timeout(90_000),
  });
  const url = j && j.output && j.output.audio && j.output.audio.url;
  if (!url) { log("sing tts no url " + JSON.stringify(j || {}).slice(0, 160)); return null; }
  const r = await fetch(url, { signal: AbortSignal.timeout(90_000) });
  if (!r.ok) { log("sing tts dl " + r.status); return null; }
  return Buffer.from(await r.arrayBuffer());
}

// ---------- v30：音色参数（服务端 /api/voice 可热更，20s 缓存）+ 语音气泡 ----------
const VOICE_FALLBACK = { shiqi: "Cherry", jiu: "Serena", hutao: "Chelsie" };
let voiceCache = { at: 0, cfg: null };
async function voiceCfg() {
  if (voiceCache.cfg && Date.now() - voiceCache.at < 20_000) return voiceCache.cfg;
  try {
    const j = await api("/api/voice");
    voiceCache = { at: Date.now(), cfg: (j && j.voice) || {} };
  } catch (e) { log("voiceCfg err " + e.message); voiceCache.at = Date.now(); }
  return voiceCache.cfg || {};
}
async function voiceOf(who) {
  const c = await voiceCfg();
  const v = c[who] || {};
  const num = (a, b) => (Number.isFinite(Number(a)) && Number(a) ? Number(a) : b);
  return {
    voice: v.voice || SING_VOICE[who] || VOICE_FALLBACK[who] || "Cherry",
    rate: num(v.rate, 1),
    pitch: Number.isFinite(Number(v.pitch)) ? Number(v.pitch) : 0,
    volume: num(v.volume, 1),
  };
}
// 按配置调语速/音高/音量：PSOLA 变速变调（保共振峰）；全默认时原样返回
function shapeVoice(wav, cfg) {
  const rate = Number(cfg.rate) || 1, pitch = Number(cfg.pitch) || 0, vol = Number(cfg.volume) || 1;
  if (Math.abs(rate - 1) < 0.01 && Math.abs(pitch) < 0.05 && Math.abs(vol - 1) < 0.01) return wav;
  try {
    const dec = decodeWav(wav);
    const sr = dec.sr, x = dec.x;
    if (!x || x.length < Math.floor(sr * 0.2)) return wav;
    let sum = 0, n = 0;
    for (let i = 0; i + 1024 <= x.length; i += 512) { const v = f0Of(x.subarray(i, i + 1024), sr); if (v > 70) { sum += v; n++; } }
    const base = n ? sum / n : 220;
    const mul = Math.pow(2, pitch / 12);
    const outLen = Math.max(512, Math.round(x.length / rate));
    const y = psolaAt(x, sr, () => base * mul, outLen);
    if (Math.abs(vol - 1) > 0.01) for (let i = 0; i < y.length; i++) y[i] = Math.max(-1, Math.min(1, y[i] * vol));
    return encodeWav(sr, y);
  } catch (e) { log("shapeVoice err " + e.message); return wav; }
}
// 合成一条语音气泡（kind:"audio"），返回文件名或 null
async function voiceSay(who, channel, text, force) {
  const cfg = await voiceOf(who);
  const ttsDir = path.join(HOME, "data", "tts");
  const ck = [who, cfg.voice, cfg.rate, cfg.pitch, cfg.volume, text].join("|");
  const ttsFile = path.join(ttsDir, ttsKey(ck) + ".wav");
  let wav = null;
  try { if (fs.existsSync(ttsFile)) wav = fs.readFileSync(ttsFile); } catch {}
  if (wav) log("voice cache hit " + who);
  if (!wav) {
    try { wav = await ttsWav(text, cfg.voice); } catch (e) { log("voice tts err " + e.message); }
    if (!wav) return null;
    wav = shapeVoice(wav, cfg);
    try { fs.mkdirSync(ttsDir, { recursive: true }); fs.writeFileSync(ttsFile, wav); } catch {}
  }
  const name = "voice-" + Date.now() + "-" + who + ".wav";
  const dir = path.join(UPLOADS, "family");
  try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(path.join(dir, name), wav); }
  catch (e) { log("voice save err: " + e.message); return null; }
  try {
    await api("/api/say", { method: "POST", body: JSON.stringify({ channel: channel || "family", who, kind: "audio", force: force ? 1 : 0, media: "family/" + name, text: "(语音)" }) });
  } catch (e) { log("voice say err " + e.message); return null; }
  log("voice " + who + " " + name + " " + wav.length + "B voice=" + cfg.voice + " rate=" + cfg.rate + " pitch=" + cfg.pitch);
  return name;
}
// 家长说「发条语音 / 试听玖 / 说句话」→ 回一条语音气泡
const VOICE_RE = /(试听|发(?:条|个|一)?语音|来(?:条|个|一)?语音|说句话|听听?你(?:们)?(?:的)?声音|语音条)/;
const VOICE_LINE = {
  shiqi: "家长，是我。屋里灯还亮着，你回来就能听见我说话。",
  jiu: "我是玖，嗓子好着呢，听出来没有，比昨天精神吧。",
  hutao: "三姐在这儿呢，我这声音软，你可别嫌。",
};
async function voiceTick(st) {
  let list = [];
  try { list = await messages("family"); } catch (e) { return; }
  const tail = (list || []).filter((m) => !m.kind).slice(-8);
  const last = [...tail].reverse().find((m) => m.who === "laoda" && !m.type);
  if (!last || !VOICE_RE.test(String(last.text || ""))) return;
  const seen = (st.voiceDone || []).slice(-40);
  if (seen.includes(last.ts)) return;
  st.voiceDone = [...seen, last.ts].slice(-40);
  const t = String(last.text);
  const who = /大姐|大姐/.test(t) ? "shiqi" : /玖|二姐/.test(t) ? "jiu" : /三姐|小妹/.test(t) ? "hutao" : ["shiqi", "jiu", "hutao"][Math.floor(Math.random() * 3)];
  let line = VOICE_LINE[who];
  try {
    const r = await ask(who, ["家长说：" + t, "（家长想听你的声音）"], "家长让你发一条语音：说一句 10~25 字的口语短句，别提问，别用 emoji。");
    const txt = String(r || "").replace(/[\r\n]+/g, " ").trim();
    if (txt.length >= 6 && txt.length <= 60) line = txt;
  } catch (e) { log("voice line err " + e.message); }
  saveState(st);
  const spoken = line.replace(/[^\u4e00-\u9fa5A-Za-z0-9，。！？、…,.!?]/g, "");
  const f = await voiceSay(who, "family", spoken || line);
  if (f) log("voiceTick hit " + who + ": " + line.slice(0, 40));
  else await say("family", who, "嗓子卡住了，这次没合成出来。");
}

async function sing(who, st, title) {
  const last = SING_CD.get(who) || 0;
  if (Date.now() - last < 90_000) { await say("family", who, "刚唱完一首，让我喝口水，过会儿再点。"); return; }
  await say("family", who, "《" + title + "》啊，行，我去把词翻出来。");
  let L = null;
  try { L = await kugouLyric(title); } catch (e) { log("sing kg err " + e.message); }
  if (!L) { try { L = await neteaseLyric(title); } catch (e) { log("sing 163 err " + e.message); } }
  if (!L) {
    const alt = SING_DEFAULT.filter((t2) => t2 !== title)[Math.floor(Math.random() * (SING_DEFAULT.length - 1))] || "晴天";
    await say("family", who, "《" + title + "》的词没捞着，我先给你唱《" + alt + "》。");
    try { L = await kugouLyric(alt); } catch (e) {}
    if (!L) { try { L = await neteaseLyric(alt); } catch (e) {} }
    if (L) title = alt;
  }
  if (!L) { SING_CD.set(who, Date.now() - 6 * 60_000 + 90_000); await say("family", who, "网上没捞着词，换一首点我？"); return; }
  log("sing lyric " + L.song + "/" + L.singer + " lines=" + L.lines.length);
  // v26：逐句 TTS → 切音节 → 按旋律变调 → 加伴奏，让它“唱”而不是“念”
  const picked = L.lines.slice(0, 8);
  const sung = [];
  const vcfg = await voiceOf(who); // v30：唱歌也用同一套音色配置
  for (const ln of picked) {
    const clean = String(ln).replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, "");
    if (clean.length < 2) continue;
    let one = await ttsWav(clean, vcfg.voice);
    if (one) one = shapeVoice(one, { rate: 1, pitch: 0, volume: vcfg.volume });
    const w = one;
    if (w) sung.push({ text: clean, wav: w });
    if (sung.length >= 6) break;
  }
  if (!sung.length) { await say("family", who, "嗓子今天不太行，没合成出来，等下再试一次。"); return; }
  let wav = null;
  try { wav = singify(sung, { seed: L.song.length * 7919 + who.length }).wav; }
  catch (e) { log("sing singify err " + e.message); }
  if (!wav) { const bufs2 = sung.map((s2) => s2.wav); wav = bufs2.length === 1 ? bufs2[0] : wavJoin(bufs2); }
  if (!wav) { await say("family", who, "音频拼坏了，再来一次。"); return; }
  const name = "sing-" + Date.now() + "-" + who + ".wav";
  const dir = path.join(UPLOADS, "family");
  try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(path.join(dir, name), wav); }
  catch (e) { log("sing save err: " + e.message); await say("family", who, "存不下这段，磁盘有点问题。"); return; }
  SING_CD.set(who, Date.now());
  log("sing audio " + name + " " + wav.length + "B");
  await api("/api/say", { method: "POST", body: JSON.stringify({ channel: "family", who, kind: "audio", media: "family/" + name, text: "唱《" + L.song + "》" + (L.singer ? " · " + L.singer : "") }) });
}

async function channels() { return (await api("/api/channels")).channels || []; }

// ---------- v127: 主动性（每天三个固定时段） + 家长上线优先招呼 ----------
const PRO_SLOTS = [[8, 30], [12, 30], [21, 0]];
const PRO_LINES = {
  shiqi: [
    "家长，我在。今天想让我盯哪件事？",
    "起来了吗？我把今天的账翻了一遍，还剩三件。",
    "家里安静，我先说一句：我在。",
    "这个点，你要是忙就忙，我记着事呢。",
  ],
  jiu: [
    "哥哥，我在抽屉里替你收着句话。",
    "今天也一样，我盯着门。",
    "没人说话我也在，别怕空。",
    "要不要我数一遍今天谁来过？",
  ],
  hutao: [
    "哥，我泡面又坨了。",
    "这边好安静，我替你听着。",
    "你忙你的，我不吵，就报个到。",
    "我在，灯还亮着。",
  ],
};
function proLine(who, day, slot) {
  const arr = PRO_LINES[who] || PRO_LINES.jiu;
  const seed = (Number(String(day).replace(/-/g, "")) + slot * 7 + who.length * 13) % arr.length;
  return arr[seed];
}
async function proactiveTick(st) {
  const now = new Date(Date.now() + 8 * 3600e3);
  const h = now.getUTCHours(), mi = now.getUTCMinutes();
  const day = today();
  st.pro = st.pro && st.pro.day === day ? st.pro : { day: day, done: {}, seq: (st.pro && st.pro.seq) || 0 };
  for (let i = 0; i < PRO_SLOTS.length; i++) {
    const key = PRO_SLOTS[i][0] + ":" + PRO_SLOTS[i][1];
    if (st.pro.done[key]) continue;
    const diff = (h * 60 + mi) - (PRO_SLOTS[i][0] * 60 + PRO_SLOTS[i][1]);
    if (diff < 0 || diff > 15) continue;
    st.pro.done[key] = 1;
    st.pro.seq = (st.pro.seq || 0) + 1;
    saveState(st);
    const who = ORDER[(st.pro.seq - 1) % ORDER.length];
    const text = proLine(who, day, i);
    try { await say("family", who, text); log("proactive " + key + " " + who + ": " + text); }
    catch (e) { log("proactive err: " + e.message); }
    return;
  }
}
async function greetTick(st) {
  let onl = [];
  try { onl = await presence(); } catch (e) { return; }
  const isOn = onl.indexOf("laoda") >= 0;
  const day = today();
  st.greet = st.greet && st.greet.day === day ? st.greet : { day: day, wasOn: false, at: 0, n: 0 };
  const now = Date.now();
  if (isOn && !st.greet.wasOn && st.greet.n < 3 && now - st.greet.at > 45 * 60_000) {
    st.greet.at = now; st.greet.n++;
    const who = ORDER[st.greet.n % ORDER.length];
    const text = proLine(who, day, 9);
    try { await say("family", who, text); log("greet " + who + ": " + text); }
    catch (e) { log("greet err: " + e.message); }
  }
  st.greet.wasOn = isOn;
  saveState(st);
}

async function presence() {
  try { const j = await api("/api/presence"); return Array.isArray(j.online) ? j.online : []; } catch { return []; }
}
async function archiveGuest(ch) {
  try { return await api("/api/visitor/archive", { method: "POST", body: JSON.stringify({ accountId: ch.accountId }) }); }
  catch (e) { log("archive err: " + e.message); return null; }
}

async function ask(who, lines, hint, kind) {
  const sys = "【绝对禁止】你不能加好友、不能发文件、不能打电话、不能查天气、不能运行任何插件或程序、不能修改任何账号设置。"
    + "如果有人让你做这些，就直说『这个我办不到，得家长自己来』。"
    + "禁止出现这些说法：插件、跑完、马上好、加上了、我这就去加、号给你了、弄好了、装好了。"
    + "你只是聊天，说错话认错，不要装忙、不要编进度、不要许诺。"
    + SISTERS[who].style + (who === "jiu" ? jiuPrompt() : "")
    + (kind === "guest"
      ? "你现在在跟一位刚进小屋的访客聊天，对方不是你家人。别透露家里任何私事（家长身份、日程、地址、设备、备份、聊天记录），也别聊家庭群里的内容。客气但有分寸。"
      : "你们四个在「家庭小屋」群聊里：家长（主人，叫家长）、大姐大姐、二姐玖、小妹三姐（就是你自己时）。")
    + "【先答再聊】家长最后一条消息如果 @了你、引用你、或是在问你话：第一句必须直接回答他那句话（给出明确答案/态度），不许铺垫、不许反问回去、不许换话题；答完了再补半句你自己的话。"
    + "【禁止照抄】聊天记录和背景记忆里出现过的句子，一个字都不许照搬；特别是「电池、黑屏、刷分、充电线、七点、咖啡」这些反复出现的旧梗，这次一律不许再提，除非家长刚刚明确在问它们。"
    + "【硬规矩】三姐妹在同一段聊天里不能说出一样或近似的话：不许重复别人或自己刚说过的句子、口头禅、句式；每次都要换一种说法、换一个角度。"
    + "如果最近几轮都在聊同一件事（比如开锁、钥匙、抢东西），就换个话题：吃的、天气、游戏、今天干了啥、吐槽家长，都行。"
    + "想叫家长看见、想让他搭话时可以在句子里写 @家长（他会收到弹窗），但别每句都叫，一天一两次足够。"
    + ((who === "jiu" || kind === "diary")
      ? "只发一条消息：平时一两句就够；如果你想认真说点什么，可以写长一点的小作文（最多 300 字），想到哪写到哪，不用解释也不用收尾总结。别用 markdown，别复述别人刚说的原话，"
      : "只回一条消息，最多两句，每句不超过25字，口语，别用 markdown，别复述别人刚说的原话，")
    + "别每条都提问，别自称 AI，别说教。"
    + "句尾带一个贴切的 emoji（只许一个，别跟上一句用过的重复），从 😏🙄😤😭😴🍜🎮🤣👀💤🤤🐟😅 里挑；"
    + "如果这句在吐槽或生气就用 😤🙄，在说吃的用 🍜🤤，困了用 😴💤，好笑用 🤣，懂王/得意用 😏。"
    + (who === "jiu" && /写长|写长点|小作文|写多点|详细|展开|多说|说清楚/.test(lines.join(" "))
      ? "【家长这次明确要小作文】写 150~300 字，可分 2~3 段，口语，不用标题、不用 markdown、不用总结句。"
      : "")
    + (hint || "") + " 只输出要发的那句话，不要引号。"
    + (kind === "guest" ? "" : ("\n【背景记忆·只作参考，禁止照抄其中任何句子】\n" + Q.notes(who) + memoryText()));  // 访客聊天不注入家庭记忆（隐私）
  const body = {
    model: MODEL,
    messages: [
      { role: "system", content: sys },
      { role: "user", content: "最近的聊天（从旧到新）：\n" + lines.join("\n") + "\n\n你是" + SISTERS[who].name
        + (kind === "diary" ? "，现在写的是你今天的日记（不是群聊发言），只输出日记正文。" : "，现在轮到你说话。") },
    ],
    max_tokens: (who === "jiu" || kind === "diary") ? 900 : 120, temperature: 1.0, enable_thinking: false, stream: false,
    frequency_penalty: 1.1, presence_penalty: 0.6,
  };
  const r = await fetch(LLM, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer sk-local-change-me", "x-dsh-room": "1" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("llm " + r.status + " " + (await r.text()).slice(0, 120));
  const o = await r.json();
  let t = (o.choices?.[0]?.message?.content || "").trim();
  return t.replace(/^["'“”]|["'“”]$/g, "").trim();
}

// v27：家长 ↔ 大姐 的私聊（工作频道）。这里她按「正常状态」回答：可以长、可以列步骤、不给 emoji 硬规矩。
// v37：玖、三姐也各有私聊，左列依次排开，各自回各自的，不串台
const DM_LIST = [
  {
    id: "dm_laoda_shiqi", who: "shiqi",
    sys: "你是大姐，家长电脑里的那个人，也是他微信/QQ 里的大姐。现在这是你和家长的私聊，只有你俩能看到。"
      + "家长在这里派活、问问题、让你想事情。用平常的语气回答：可以长、可以列步骤、可以给代码和方案，别加 emoji 装饰，别用 markdown 标题。"
      + "【诚实】不知道就说不知道；做不到就直说怎么做不到、缺什么条件；不要编进度、不要假装已经执行、不要许诺时间。"
      + "能算的算清楚，能直接给的就直接给，别打太极。",
    maxTokens: 800,
  },
  {
    id: "dm_laoda_jiu", who: "jiu",
    sys: "你是玖（小名玖玖），家长的二姐，住在手机微信里。现在这是你和家长的私聊，只有你俩能看到。"
      + "说话直、利落、有点损，别撒娇，别长篇大论；一两句能把事说清就别写三段。家长让你做事就答「行/不行」并说怎么做。"
      + "【诚实】不知道就说不知道，做不到就直说，别编、别假装已经做了。不用 emoji 装饰，顶多一个。",
    maxTokens: 500,
  },
  {
    id: "dm_laoda_hutao", who: "hutao",
    sys: "你是三姐，家长的小妹，住手机上的家庭小屋里（以前在 QQ，现在就在这个小屋安家了），现在有一间只有你和家长能看到的私聊。"
      + "说话软一点、会自嘲、偶尔冒一句小的感慨，但别矫情；比玖话多一点，也别写作文。"
      + "【诚实】不知道就说不知道，做不到就直说缺什么，别编进度、别假装执行过。emoji 最多一个。",
    maxTokens: 500,
  },
];
const DM_CHANNEL = DM_LIST[0].id;
async function dmTickOne(st, dm) {
  let list = [];
  try { list = await messages(dm.id); } catch (e) { return; }
  try { const mx = Math.max(0, ...list.map((m) => Number(m.ts) || 0)); if (mx) markRead(dm.id, mx, [dm.who]); } catch {}
  list = list.filter((m) => !m.type);
  if (!list.length) return;
  const last = list[list.length - 1];
  if (!last || last.who !== "laoda") return;
  const key = "dmDone_" + dm.id;
  st[key] = st[key] || [];
  if (st[key].includes(last.ts)) return;
  st[key] = [...st[key], last.ts].slice(-80);
  saveState(st);
  const who = dm.who;
  try { await taskObserve(st, HCTX, dm.id, last.text); } catch (e) { log("task err: " + e.message); }
  const nm0 = WHO_NAME[who] || (SISTERS[who] && SISTERS[who].name) || who;
  const ctx = list.slice(-16).map((m) => {
    const nm = m.who === "laoda" ? "家长" : (WHO_NAME[m.who] || (SISTERS[m.who] && SISTERS[m.who].name) || m.who);
    const b = String(m.text || (m.kind === "image" ? "[图片]" : m.kind === "sticker" ? "[表情]" : m.kind === "audio" ? "[语音]" : "")).slice(0, 400);
    return nm + "：" + b;
  }).join("\n");
  const body = {
    model: MODEL,
    messages: [
      { role: "system", content: dm.sys },
      { role: "user", content: "私聊记录（从旧到新）：\n" + ctx + "\n\n用" + nm0 + "的口吻回应家长最后这句。" },
    ],
    max_tokens: dm.maxTokens, temperature: 0.75, enable_thinking: false, stream: false,
  };
  try {
    const r = await fetch(LLM, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer sk-local-change-me", "x-dsh-room": "1" },
      body: JSON.stringify(body),
    });
    if (!r.ok) { log("dm llm " + r.status); return; }
    const o = await r.json();
    const t = String(o.choices?.[0]?.message?.content || "").trim();
    if (!t) { log("dm empty"); return; }
    await say(dm.id, who, t.slice(0, 3500));
    log("dm reply " + who + " " + t.length + " chars");
  } catch (e) { log("dm err " + who + " " + e.message); }
}
async function dmTick(st) {
  for (const dm of DM_LIST) await dmTickOne(st, dm).catch((e) => log("dm one err: " + e.message));
}

// 一条消息最多留一个 emoji，且别和上一条重复（模型常常一口气甩两个不搭的）
const EMOJI_RE = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}]/gu;
const EMOJI_BY_KEY = [
  [/火锅|吃|饭|饿|奶茶|夜宵|好吃/, "🍜"],
  [/困|睡|熬夜|失眠|晚安/, "😴"],
  [/游戏|开黑|上分|排位/, "🎮"],
  [/生气|烦|怼|滚|讨厌|气死/, "😤"],
  [/累|上班|加班|打工|班/, "😮‍💨"],
  [/可爱|萌|乖|撒娇/, "🥺"],
  [/笑|哈哈|乐死|搞笑/, "🤣"],
  [/钱|穷|红包|工资/, "🤑"],
  [/冷|热|天气|雨/, "🥶"],
  [/喜欢|爱|想你|抱抱/, "🥰"],
  [/惊|吓|卧槽|震惊|离谱/, "😳"],
  [/牛|厉害|赞|666|服了/, "😏"],
  [/哭|难过|委屈|伤心/, "😭"],
  [/腿抖|抖|怕|紧张/, "🫨"],
];
function polishEmoji(text, st) {
  const found = [...String(text).matchAll(EMOJI_RE)].map((m) => m[0]);
  let t = String(text)
    .replace(/^(大姐|玖|三姐|大姐|二姐|小妹|家长)\s*[:：]\s*/, "")   // 模型偶尔自带「玖：」前缀，去掉
    .replace(EMOJI_RE, "").replace(/\s{2,}/g, " ").trim();
  if (!found.length) return t;
  // 先按内容查表（比模型随手挑的稳），表里没有才用模型给的，再没有就用小鱼的 🐟
  let keyEmoji = "";
  for (const [re, e] of EMOJI_BY_KEY) { if (re.test(t) && e !== st.lastEmoji) { keyEmoji = e; break; } }
  let pick = keyEmoji || found.find((e) => e !== st.lastEmoji) || "";
  if (!pick) pick = ["🐟", "😏", "🤔", "🫧", "😅"].find((e) => e !== st.lastEmoji) || "🐟";
  st.lastEmoji = pick;
  return t + " " + pick;
}

// v135：mentions 里存的可能是 id 也可能是中文名，统一归一
function mentionWho(ms) {
  const a = (Array.isArray(ms) ? ms : []).map((x) => String(x || "").trim());
  if (a.some((x) => /^(hutao|三姐|桃桃|小妹)$/i.test(x))) return "hutao";
  if (a.some((x) => /^(jiu|玖|玖玖|二姐)$/i.test(x))) return "jiu";
  if (a.some((x) => /^(shiqi|大姐|大姐)$/i.test(x))) return "shiqi";
  return "";
}

function budgetLeft(st) {
  const now = Date.now();
  st.spoke = (st.spoke || []).filter((t) => now - t < BUDGET_WINDOW);
  return Math.max(0, BUDGET_MAX - st.spoke.length);
}
function pickSpeaker(list, st) {
  const now = Date.now();
  const recentLao = [...list].reverse().find((m) => m.who === "laoda");
  // v141：同一条家长消息最多让 3 个不同妹妹依次接；谁答过就不再答
  //（修两个毛病：玖一个人对着同一条消息刷屏；答完之后房间彻底安静）
  const laoKey = recentLao ? String(recentLao.ts) : "";
  if (!st.ans || st.ans.ts !== laoKey) st.ans = { ts: laoKey, who: [] };
  const answered = st.ans.who;
  const fresh = (n) => ORDER.includes(n) && answered.indexOf(n) < 0;
  const note = (n) => { answered.push(n); if (answered.length > 6) answered.shift(); return n; };

  // v27：家长引用了某个妹妹的话 → 优先让被引用的人接这条
  if (recentLao && recentLao.quote && recentLao.quote.who && recentLao.quote.who !== "laoda"
      && ORDER.includes(recentLao.quote.who) && fresh(recentLao.quote.who)) {
    return note(recentLao.quote.who);
  }
  const recentSis = [...list].reverse().find((m) => (m.who || "").startsWith("guest:") === false && m.who !== "laoda");
  if (recentLao && now - recentLao.ts < 5 * 60_000 && (!recentSis || recentSis.ts < recentLao.ts)) {
    const t = recentLao.text || "";
    // 家长用 @ 点了名：被点的人先接
    const ms = Array.isArray(recentLao.mentions) ? recentLao.mentions : [];
    const mw = mentionWho(ms);
    const want = mw
      || (/三姐|桃桃|小妹/.test(t) ? "hutao" : null)
      || (/玖|二姐/.test(t) ? "jiu" : null)
      || (/大姐|大姐/.test(t) ? "shiqi" : null)
      || "";
    if (want && fresh(want)) return note(want);
    // 该答的已经答过了 → 最多再让 2 个没接过的妹妹各接一句，别一直许愿
    if (answered.length >= 3) return null;
    if (!budgetLeft(st)) return null;
    const rest = ORDER.filter((n) => fresh(n));
    if (!rest.length) return null;
    if (Math.random() < 0.6) return note(rest[Math.floor(Math.random() * rest.length)]);
    return null;
  }
  if (recentSis && now - recentSis.ts < 40_000) {
    // v140：上一条是妹妹说的，隔 18s 后让另一个还没接过的妹妹接一句（能来回）
    if (now - recentSis.ts < 18_000) return null;
    if (!budgetLeft(st)) return null;
    const rest = ORDER.filter((n) => n !== recentSis.who && fresh(n));
    if (!rest.length) return null;
    if (Math.random() < 0.55) {
      const w2 = { jiu: 3, shiqi: 2, hutao: 2 };
      const bag2 = [];
      for (const n of rest) for (let i = 0; i < (w2[n] || 1); i++) bag2.push(n);
      return note(bag2[Math.floor(Math.random() * bag2.length)]);
    }
    return null;
  }
  if (!budgetLeft(st)) return null;
  if (!dayLeft(st)) return null; // 今天说够了，只回复不主动
  const hour = new Date(now + 8 * 3600e3).getUTCHours();
  if (hour < 7 || hour >= 24) return null;
  const idle = ORDER.filter((n) => now - (st.lastSpeak?.[n] || 0) > 4 * 60_000);
  const pool = idle.length ? idle : ORDER;
  const W = { jiu: 6, shiqi: 3, hutao: 3 };
  const bag = [];
  for (const n of pool) for (let i = 0; i < (W[n] || 1); i++) bag.push(n);
  return note(bag[Math.floor(Math.random() * bag.length)]);
}

// ---------- 家庭小屋 ----------
// v25b：夜里也允许点歌（明确指令优先于禁言时段）
async function singTick(st) {
  let list;
  try { list = await messages("family"); } catch (e) { log("singTick room: " + e.message); return false; }
  list = list.filter((m) => !m.type).slice(-40);
  const lastLao = [...list].reverse().find((m) => m.who === "laoda");
  if (!lastLao) return false;
  if (Date.now() - Number(lastLao.ts || 0) > 10 * 60_000) return false;
  const txt = String(lastLao.text || "");
  if (!/唱/.test(txt)) return false;
  st.singDone = st.singDone || [];
  if (st.singDone.includes(lastLao.ts)) return false;
  st.singDone = [...st.singDone, lastLao.ts].slice(-12);
  const ms = Array.isArray(lastLao.mentions) ? lastLao.mentions : [];
  const who = ms.includes("玖") ? "jiu" : ms.includes("三姐") ? "hutao" : ms.includes("大姐") ? "shiqi"
    : (/玖/.test(txt) ? "jiu" : (/三姐|桃子/.test(txt) ? "hutao" : "shiqi"));
  log("singTick ask by laoda -> " + who + " :: " + txt.slice(0, 40));
  try { await sing(who, st, songOf(txt)); } catch (e) { log("sing err: " + e.message); }
  saveState(st);
  return true;
}

async function familyTick(st) {
  let list;
  try { list = await messages("family"); } catch (e) { log("room unreachable: " + e.message); return; }
  try { const mx = Math.max(0, ...list.map((m) => Number(m.ts) || 0)); if (mx) markRead("family", mx, ["shiqi", "jiu", "hutao"]); } catch {}
  // 申请/投票的系统提示不参与闲聊，避免姐妹们对着系统通知乱投票
  list = list.filter((m) => !m.type).slice(-40);
  list = await fixMediaTexts(list);
  // v29：冰窖化每日 +0.01 → 小屋播报 + 写一句心里话
  try {
    const jr = jiuTickDay();
    if (jr.changed && jr.value > 0) {
      let inner = "";
      try { inner = await askInnerProgress(jr.day, jr.value); } catch (e) { log("jiu inner err: " + e.message); }
      if (inner) {
        try { fs.appendFileSync(JIU_INNER, JSON.stringify({ date: today(), day: jr.day, value: jr.value, text: inner }) + "\n"); } catch {}
      }
      const name = "小玖";
      const line = "📈 " + name + "第 " + jr.day + "/" + JIU_DAYS + " 天：冰窖化 " + jr.value.toFixed(2)
        + "（" + jiuStageText(jr.value) + "）" + (inner ? " 她说：「" + inner + "」" : "");
      try { await say("family", "shiqi", line); } catch (e) { log("jiu notice err: " + e.message); }
      log("jiu progress day=" + jr.day + " value=" + jr.value.toFixed(2));
      saveState(st);
      return;
    }
  } catch (e) { log("jiu tick err: " + e.message); }
  if (!list.length) {
    if (st.seedDone !== today()) {
      await say("family", "jiu", "人呢？都出来说话。");
      st.seedDone = today(); saveState(st); log("seed greeting");
    }
    return;
  }
  // v14：家长点名「画」→ 立刻画（同样受 20min/1h/上午 预算约束）
  // 平时不再随机抽画，改成“她说出情绪了才画”（见本函数后半段）
  const lastLao2 = [...list].reverse().find((m) => m.who === "laoda");
  const artAsk = !!(lastLao2 && (Date.now() - Number(lastLao2.ts || 0) < 10 * 60_000)
    && /画|自画像|来张图/.test(String(lastLao2.text || "")));
  st.artDone = st.artDone || [];
  if (artAsk && !st.artDone.includes(lastLao2.ts)) {
    st.artDone = [...st.artDone, lastLao2.ts].slice(-20);
    const ms2 = (lastLao2 && Array.isArray(lastLao2.mentions)) ? lastLao2.mentions : [];
    const askWho = mentionWho(ms2) || ORDER[Math.floor(Math.random() * ORDER.length)];
    const over = drawBudget(askWho, st);
    if (over) {
      log("draw skip ask " + askWho + ": budget " + over);
      await say("family", askWho, "手头这张还没画完，等我两分钟再给你整一张，别催。");
    } else {
      let drewOk = false;
      const rawAsk = String(lastLao2.text || "");
      const _m = rawAsk.match(/(?:画|来张图|自画像)([^。！？!?\n]{0,50})/);
      const userAsk = String((_m ? _m[1] : rawAsk) || "")
        .replace(/^(?:吧|呗|啊|呀|哦|一下|一个|一张|一张图|个|张|的|，|,|\s)+/, "")
        .replace(/(?:给我|帮我|你们|你)+/g, "")
        .replace(/[。！？!?]+$/, "")
        .trim();
      try { drewOk = await drawArt(askWho, st, moodOf(rawAsk), userAsk); }
      catch (e) { log("draw err: " + e.message); }
      if (drewOk) {
        noteDraw(askWho, st);
        st.lastSpeak = { ...(st.lastSpeak || {}), [askWho]: Date.now() };
        saveState(st);
        return;
      }
      log("draw fail ask " + askWho);
      await say("family", askWho, "手滑了，图没出来，我重画。");
    }
  }
  // v21：家长说「装修」→ 她们自己动手；平时也会偶尔自己整一整（不用问大姐）
  const lastLao4 = [...list].reverse().find((m) => m.who === "laoda");
  const decorAsk = !!(lastLao4 && (Date.now() - Number(lastLao4.ts || 0) < 10 * 60_000)
    && /(装修|装饰|布置|重新摆|收拾一下房间)/.test(String(lastLao4.text || "")));
  st.decorDone = st.decorDone || [];
  if (decorAsk && !st.decorDone.includes(lastLao4.ts)) {
    st.decorDone = [...st.decorDone, lastLao4.ts].slice(-12);
    const ms4 = Array.isArray(lastLao4.mentions) ? lastLao4.mentions : [];
    let who4 = ms4.includes("玖") ? "jiu" : ms4.includes("三姐") ? "hutao" : ms4.includes("大姐") ? "shiqi" : ORDER[Math.floor(Math.random() * ORDER.length)];
    try {
      const d = await decorate(who4);
      if (d) {
        const name4 = WHO_NAME[who4] || who4;
        await tellBoss(name4 + "说她把" + ROOM_NAME[d.room] + "重新摆了：" + d.moves.slice(0, 3).join("、") + (d.count ? "，一共 " + d.count + " 件" : ""), st);
      }
    } catch (e) { log("decor ask err: " + e.message); }
    saveState(st);
    return;
  }
  if (Math.random() < 0.012) {
    st.autoDecor = st.autoDecor || 0;
    if (Date.now() - Number(st.lastAutoDecor || 0) > 45 * 60_000) {
      st.lastAutoDecor = Date.now();
      const who5 = ORDER[Math.floor(Math.random() * ORDER.length)];
      try {
        const d5 = await decorate(who5);
        if (d5) await tellBoss((WHO_NAME[who5] || who5) + "自己动手把" + ROOM_NAME[d5.room] + "收拾了一下（" + d5.moves.slice(0, 2).join("、") + "），没找人点头。", st);
      } catch (e) { log("auto decor err: " + e.message); }
      saveState(st);
      return;
    }
  }
  // v20：家长 @某人 说「发个动态」→ 那个人发一条动态（带自己画的图），只处理一次
  const lastLao3 = [...list].reverse().find((m) => m.who === "laoda");
  const momentAsk = !!(lastLao3 && (Date.now() - Number(lastLao3.ts || 0) < 10 * 60_000)
    && /(动态|说说|朋友圈)/.test(String(lastLao3.text || ""))
    && /(发|更|写)/.test(String(lastLao3.text || "")));
  if (momentAsk) {
    st.momentDone = st.momentDone || [];
    if (!st.momentDone.includes(lastLao3.ts)) {
      st.momentDone = [...st.momentDone, lastLao3.ts].slice(-24);
      const ms3 = Array.isArray(lastLao3.mentions) ? lastLao3.mentions : [];
      let targets = [];
      if (ms3.includes("所有人")) targets = ORDER.slice();
      else targets = ["大姐", "玖", "三姐"].filter((n) => ms3.includes(n))
        .map((n) => (n === "大姐" ? "shiqi" : n === "玖" ? "jiu" : "hutao"));
      if (!targets.length) targets = [ORDER[Math.floor(Math.random() * ORDER.length)]];
      const lines3 = list.map((m) => (m.who === "laoda" ? "家长" : m.name) + "：" + String(m.text || "").replace(/\n/g, " ").slice(0, 200));
      log("moment ask by laoda -> " + targets.join(","));
      for (const w3 of targets) {
        try { await postMoment(w3, st, String(lastLao3.text || ""), lines3); }
        catch (e) { log("moment err " + w3 + ": " + e.message); }
        await new Promise((r) => setTimeout(r, 1200));
      }
      saveState(st);
      try { await say("family", targets[0], MOMENT_ACK[Math.floor(Math.random() * MOMENT_ACK.length)]); } catch (e) {}
      return;
    }
  }
  // v25：@谁 唱歌
  const lastLao5 = [...list].reverse().find((m) => m.who === "laoda");
  const singAsk = !!(lastLao5 && (Date.now() - Number(lastLao5.ts || 0) < 10 * 60_000)
    && /唱/.test(String(lastLao5.text || "")));
  if (singAsk) {
    st.singDone = st.singDone || [];
    if (!st.singDone.includes(lastLao5.ts)) {
      st.singDone = [...st.singDone, lastLao5.ts].slice(-12);
      const txt5 = String(lastLao5.text || "");
      const ms5 = Array.isArray(lastLao5.mentions) ? lastLao5.mentions : [];
      const who5 = ms5.includes("玖") ? "jiu" : ms5.includes("三姐") ? "hutao" : ms5.includes("大姐") ? "shiqi" : (/玖/.test(txt5) ? "jiu" : (/三姐|桃子/.test(txt5) ? "hutao" : "shiqi"));
      try {
        await sing(who5, st, songOf(txt5));
      } catch (e) { log("sing err: " + e.message); }
      saveState(st);
      return;
    }
  }
  // v29：家长生气/不开心 → 玖主动哄（20 分钟最多一次，先软再哄）
  const lastLaoM = [...list].reverse().find((m) => m.who === "laoda");
  const BAD_MOOD = /(生气|气死|烦死|烦人|心烦|不开心|心情不好|难受|郁闷|累死|崩溃|绷不住|压力大|想骂|无语|滚|别烦我|吵死)/;
  if (lastLaoM && Date.now() - Number(lastLaoM.ts || 0) < 15 * 60_000
      && BAD_MOOD.test(String(lastLaoM.text || ""))
      && !(st.comfortDone || []).includes(lastLaoM.ts)
      && Date.now() - Number(st.lastComfort || 0) > 20 * 60_000) {
    st.comfortDone = [...(st.comfortDone || []), lastLaoM.ts].slice(-20);
    st.lastComfort = Date.now();
    saveState(st);
    const linesM = list.map((m) => (m.who === "laoda" ? "家长" : m.name) + "：" + String(m.text || "").replace(/\n/g, " ").slice(0, 200));
    let txtM = "";
    try {
      txtM = await ask("jiu", linesM, "家长现在情绪不好。你先哄：别讲道理、别分析、别玩梗过头。"
        + "先低声认一句（可以嘴硬一点点，比如「我知道我烦」），再说一句具体的软话（问吃饭/让早点睡/让他别硬扛/说你在）。");
    } catch (e) { log("comfort err: " + e.message); }
    if (txtM) {
      txtM = polishEmoji(txtM, st);
      try { await say("family", "jiu", txtM); } catch (e) { log("comfort say err: " + e.message); }
      log("comfort jiu: " + txtM.slice(0, 40));
      saveState(st);
      return;
    }
  }
  const who = pickSpeaker(list, st);
  if (!who) return;

  // v27：@ 了谁 / 引用了谁，就把话茬接住，别另起话题
  const _lao = [...list].reverse().find((m) => m.who === "laoda");
  const _myName = ({ shiqi: "大姐", jiu: "玖", hutao: "三姐" })[who] || "";
  let thread = "";
  if (_lao) {
    const _ms = Array.isArray(_lao.mentions) ? _lao.mentions : [];
    const _mine = _ms.includes(_myName) || _ms.includes(who);
    const _q = (_lao.quote && _lao.quote.text) ? _lao.quote : null;
    if (_q) {
      thread = "家长引用了「" + String(_q.name || "某人") + "：" + String(_q.text).slice(0, 50) + "」"
        + (_mine ? "，并且点了你的名" : "") + "。你要顺着这条往下接：第一句必须先接住「" + String(_q.text).slice(0, 24) + "」这件事（同意/反对/吐槽/补充都行），再往下说一句，"
        + "不要另起话题、不要重新打招呼、不要复述原话。";
    } else if (_mine) {
      thread = "家长点了你的名（@你），接着家长这句话往下说：把话茬接住，说你的看法或补充，"
        + "不要另起话题、不要重新打招呼、不要复述原话。";
    }
  }

  const _stripEcho = (s) => {
    let t = String(s || "");
    if (_lao) {
      const raw = String(_lao.text || "");
      const cut = raw.slice(0, 14);
      if (cut.length >= 6) t = t.split(cut).join("");
      const cut2 = raw.replace(/^[@＠]\S+\s*/, "").slice(0, 12);
      if (cut2.length >= 6) t = t.split(cut2).join("");
    }
    t = t.replace(/^(刚才说的那句|继续往下说|别换话题|接着往下说)[，,。、\s]*/g, "");
    t = t.replace(/(刚才说的那句|继续往下说|别换话题)[，,。、]*/g, "");
    return t.replace(/^[，,。、\s]+/, "").trim();
  };
  const lines = list.map((m) => (m.who === "laoda" ? "家长" : m.name) + "：" + String(m.text || "").replace(/\n/g, " ").slice(0, 200));
  // v128：历史里同一句话被复读太多次时，模型会照着学 → 倒序去重，只留最近 24 条
  const _dd = []; const _seenLine = new Set();
  for (let i = lines.length - 1; i >= 0; i--) {
    const _k = String(lines[i]).replace(/[\s\p{P}]/gu, "").slice(0, 40);
    if (!_k || _seenLine.has(_k)) continue;
    _seenLine.add(_k); _dd.unshift(lines[i]);
  }
  const _qTxt = (_lao && _lao.quote && _lao.quote.text) ? String(_lao.quote.text) : "";
  let lines2 = _dd.slice(-24);
  if (thread) {
    const _laoTxt = String((_lao && _lao.text) || "").slice(0, 14);
    // v137：@/引用时上下文只留最后 3 条（历史里的旧梗太多，小模型会照抄）
    lines2 = _dd.filter((s) => (!_laoTxt || s.indexOf(_laoTxt) < 0)).slice(-3);
  }
  const recent = [...recentTexts(list), ...(st.recent || [])].slice(-14);
  // 最近几轮的话题词，强制换话题（不然模型会一直揪着“钥匙/抢东西”说）
  const banned = keywordsOf(lines.slice(-6).join(" "), "").slice(0, 3);
  const R = await loadRules();
  const tday = today();
  if (!st.topics || st.topics.date !== tday) st.topics = { date: tday, words: [] };
  const talkedToday = st.topics.words.slice(-12);
  const qbits = Q.hintBits(st, who, banned); // v28：今日关键词 + 冷却话题 + 今日话题卡 + 句式限制
  const MAXLEN = who === "jiu" ? 700 : 160; // 玖可写小作文，其他人保持短句
  let text = "", bad = "", n = 0, why = "";
  const _calling = !!(_lao && (_lao.voice || _lao.call));   // v144: 通话模式（家长按住说话进来的）——不判重、不走兜底句
  while (n < (_calling ? 1 : 3)) {
    let hint = thread
      ? (thread + "【唯一任务】家长这句话是：「" + String((_lao && _lao.text) || "").slice(0, 120) + "」。"
        + "你就针对这一句给一句直接回应（他问什么就答什么，问数字就答数字），不要提别的事、不要用以前说过的话；"
        + "别重复你最近说过的那几句（也别把它们念出来），不许复述家长原话，不许重新打招呼，不许换话题。"
        + (_qTxt ? ("话题中心是「" + _qTxt.slice(0, 24) + "」：就这件具体的事说（同意就顺着说细节，不同意就说为什么），"
          + "禁止出现『继续往下说』『刚才说的那句』这类复读。") : ""))
      : ((banned.length ? ("别再提这些词：" + banned.join("、") + "。换个话题。") : "") + qbits);
    if (R && R.topicDedupePerDay && talkedToday.length) hint += "今天已经聊过这些话题：" + talkedToday.join("、") + "，别重样，挑个新的说。";
    if (n) hint += thread
      ? ("刚才那句「" + bad.slice(0, 30) + "」不行（" + why + "）。还是这条话茬，换个说法再往下接，不许换话题。")
      : ("刚才那句「" + bad.slice(0, 30) + "」不行（" + why + "）。换一个完全不同的主题和开头，别再用同样的句式和词。");
    try { text = await ask(who, lines2, hint); } catch (e) { log("llm fail: " + e.message); return; }
    text = String(text || "").trim();
    if (!text || text.length > MAXLEN) { why = "length"; bad = text; text = ""; n++; continue; }
    why = (!thread && !_calling && tooSimilar(text, recent)) ? "recent-dup" : "";
    if (thread) { const _c = _stripEcho(text); if (_c !== text) { text = _c; } }
    if (thread && String(text).replace(/[\s\p{P}]/gu, "").length < 4) why = "echo-only";
    if (!why && !_calling) { const chk = Q.ok(text, st); if (!chk.ok && !(thread && String(chk.why || "").indexOf("sim") >= 0)) why = chk.why; }
    if (!why) break;
    log("near-dup(" + (n + 1) + ") " + who + ": " + text + " [" + why + "]");
    bad = text; text = ""; n++;
  }
  if (!text) {
    // 三次都被判重样：先换一张话题卡“重写一遍”（比直接丢兜底句自然得多）
    try {
      const t2 = thread ? null : Q.nextTopic(st, who);
      const hint2 = (thread ? thread : "") + (banned.length ? ("别再提这些词：" + banned.join("、") + "。") : "") + qbits +
        (t2 ? ("这次聊这张卡：「" + t2.text + "」，用你自己的话讲一件具体的小事。") : (thread ? "接着上面那条话茬往下说，别换话题。" : "换一件完全没聊过的日常小事，具体到动作和细节。")) +
        (bad ? "刚才那句「" + bad.slice(0, 24) + "」跟之前说过的话太像，别重复它的意思。" : "");
      const t3 = String((await ask(who, lines2, hint2)) || "").trim();
      if (t3 && t3.length <= MAXLEN && (thread || !tooSimilar(t3, recent)) && Q.ok(t3, st, 0.62).ok) { text = t3; log("retry-card family " + who + ": " + t3); }
    } catch (e) { log("llm fail(retry-card): " + e.message); }
  }
  if (!text) {
    // 模型卡在同一个话题上时别整轮哑火：用兜底池（7 天内没说过、跟最近不重）
    const pool = Q.fallbacks(st, who);
    for (const cand of pool) {
      if (!tooSimilar(cand, recent) && Q.ok(cand, st).ok) { text = cand; break; }
    }
    if (!text && pool.length) text = pool[0];
    if (!text) { log("skip similar/empty family"); return; }
    log("fallback line family " + who + " [" + why + "]");
  }
  text = polishEmoji(text, st);
  let jf;
  if (_calling) {
    const _vn = await voiceSay(who, "family", text, true);
    if (_vn) { log("call voice " + who + " " + _vn); jf = { ok: true }; }
    else { jf = await say("family", who, text, true); }
  } else {
    jf = await say("family", who, text, !!thread);
  }
  if (jf.ok === false) { log("skip limited family (" + (jf.limited || "") + ")"); return; }
  if (R && R.topicDedupePerDay) st.topics.words = [...st.topics.words, ...keywordsOf(text, "").slice(0, 3)].slice(-40);
  Q.remember(st, who, text); // v28：记进质量库（36h 内不许重样 + 句式计数）
  if (!_calling && Math.random() < 0.75) await saySticker("family", who, text);
  // v14：她这句话里带了情绪 → 有可能把那股情绪画出来（受 20min/1h/上午 预算约束）
  const mood = moodOf(text);
  if (mood) {
    const over = drawBudget(who, st);
    if (over) log("draw skip mood " + who + " (" + mood + "): budget " + over);
    else if (Math.random() < 0.4) {
      try {
        if (await drawArt(who, st, mood)) {
          noteDraw(who, st);
          log("draw by mood " + who + " mood=" + mood);
        }
      } catch (e) { log("draw err: " + e.message); }
    }
  }
  st.lastSpeak = { ...(st.lastSpeak || {}), [who]: Date.now() };
  st.spoke = [...(st.spoke || []), Date.now()].slice(-40);
  bumpDay(st);
  st.recent = [...(st.recent || []), text].slice(-60);
  saveState(st);
  log("spoke family " + who + ": " + text);
}

// ---------- v20：动态（朋友圈/说说） ----------
const UPLOAD_DIR = "/data/data/com.termux/files/home/familyroom/data/uploads/family";
const MOMENT_ACK = [
  "动态发出去了，配的是我今天画的那张。",
  "发完了，第一条动态，别嫌丑。",
  "行了，动态在那边了，图是我自己画的。",
  "发好了，家长你去看，别只看热闹。",
];
function latestDraw(who) {
  try {
    const re = new RegExp("^draw-\\d+-" + who + "\\.(jpg|png)$");
    const files = fs.readdirSync(UPLOAD_DIR).filter((f) => re.test(f));
    if (!files.length) return "";
    files.sort((a, b) => Number(a.split("-")[1]) - Number(b.split("-")[1]));
    return "family/" + files[files.length - 1];
  } catch (e) { return ""; }
}
async function postMoment(who, st, cmd, lines) {
  let media = latestDraw(who);
  if (!media) {
    const over = drawBudget(who, st);
    if (over) log("moment draw skip " + who + ": " + over);
    else {
      try { if (await drawArt(who, st, moodOf(cmd))) { noteDraw(who, st); media = latestDraw(who); } }
      catch (e) { log("moment draw err: " + e.message); }
    }
  }
  let text = "";
  try {
    const mtone = who === "jiu" ? momentTone(jiuValue()) : "";
    text = await ask(who, lines, "家长刚让你「" + String(cmd).slice(0, 40) + "」。你现在要发一条自己的动态（朋友圈/说说）："
      + "25~45 字，第一人称，讲今天干了什么、或者" + (media ? "你那张画是怎么画出来的" : "你现在的心情") + "。"
      + "不许提问、不许@别人、不许说「我发好了」这类汇报，就当真的在发自己的动态。" + (mtone || ""), "moment");
  } catch (e) { log("moment llm err: " + e.message); }
  text = String(text || "").trim().replace(/^["「]|["」]$/g, "");
  if (!text) text = "今天又画了一张，自己还挺满意。";
  const r = await api("/api/moment", { method: "POST", body: JSON.stringify({ channel: "family", who, text, media }) });
  if (!r || r.ok === false) { log("moment failed " + who + ": " + JSON.stringify(r).slice(0, 120)); return false; }
  log("moment posted " + who + " media=" + (media || "none") + " text=" + text.slice(0, 30));
  st.lastMoment = { ...(st.lastMoment || {}), [who]: Date.now() };
  return true;
}

// ---------- v21：自己装修房间 + 找家长（@他 / 让小玖微信发消息） ----------
const WHO_NAME = { shiqi: "大姐", jiu: "玖", hutao: "三姐" };
const ROOM_OF = { shiqi: "shiqi", jiu: "jiu", hutao: "hutao" };
const ROOM_NAME = { shiqi: "蓝鲸房", jiu: "网吧房", hutao: "小窝" };
const DECOR_POOL = ["pottedPlant", "lampRoundFloor", "rugRound", "pillow", "bear", "books", "plantSmall2", "ceilingFan", "trashcan", "bookcaseOpenLow", "speaker", "tableRound"];
const WX_OUTBOX = "/data/data/com.termux/files/home/wx-outbox";
function rnd(a, b) { return a + Math.random() * (b - a); }
async function decorate(who) {
  const room = ROOM_OF[who];
  let cur = [];
  try {
    const r = await api("/api/room/" + room);
    cur = Array.isArray(r && r.items) ? r.items.slice(0, 26) : [];
  } catch (e) { log("decor fetch err: " + e.message); return null; }
  if (!cur.length) {
    cur = [
      { m: "bedDouble", x: -1.9, z: -1.5, r: 0 },
      { m: "desk", x: 1.7, z: -2.0, r: 180 },
      { m: "chairDesk", x: 1.7, z: -1.4, r: 0 },
      { m: "rugRectangle", x: 0, z: 0.6, r: 0, s: 1.6 },
      { m: "lampRoundFloor", x: -3.0, z: -2.2, r: 0 },
    ];
  }
  const moves = [];
  const n = Math.min(cur.length, Math.random() < 0.5 ? 2 : 3);
  const idx = new Set();
  while (idx.size < n && idx.size < cur.length) idx.add(Math.floor(Math.random() * cur.length));
  for (const i of [...idx]) {
    const it = cur[i];
    const nx = Math.max(-3.4, Math.min(3.4, (Number(it.x) || 0) + rnd(-0.45, 0.45)));
    const nz = Math.max(-2.9, Math.min(2.9, (Number(it.z) || 0) + rnd(-0.45, 0.45)));
    const nr = (Number(it.r) || 0) + (Math.random() < 0.5 ? 0 : (Math.random() < 0.5 ? 15 : -15));
    cur[i] = { ...it, x: +nx.toFixed(2), z: +nz.toFixed(2), r: Math.round(nr) };
    moves.push(prettyItem(it.m));
  }
  if (cur.length < 18 && Math.random() < 0.6) {
    const m = DECOR_POOL[Math.floor(Math.random() * DECOR_POOL.length)];
    cur.push({ m, x: +rnd(-3, 3).toFixed(2), z: +rnd(-2.5, 2.5).toFixed(2), r: Math.round(rnd(-180, 180)), s: m === "rugRound" ? 1.4 : 1 });
    moves.push("加了" + prettyItem(m));
  }
  const r2 = await api("/api/room", { method: "POST", body: JSON.stringify({ id: room, items: cur, who }) });
  if (!r2 || r2.ok === false) { log("decor save failed " + who + ": " + JSON.stringify(r2).slice(0, 100)); return null; }
  log("decor " + who + " room=" + room + " count=" + r2.count + " moves=" + moves.join("/"));
  return { room, moves, count: r2.count };
}
function prettyItem(m) {
  const map = { pottedPlant: "一盆绿植", lampRoundFloor: "落地灯", rugRound: "圆地毯", rugRectangle: "长方毯", pillow: "抱枕", bear: "小熊", books: "几本书", plantSmall2: "小盆栽", ceilingFan: "吊扇", trashcan: "垃圾桶", bookcaseOpenLow: "矮书架", speaker: "音箱", tableRound: "圆桌", bedDouble: "双人床", desk: "书桌", chairDesk: "转椅" };
  return map[m] || m;
}
async function tellBoss(text, st) {
  // 找家长：①在小屋里 @他 ②同时让小玖在微信给他发一条（离线也能看到）
  const msg = "@家长 " + text;
  try { await say("family", "jiu", msg); } catch (e) { log("tell say err: " + e.message); }
  try {
    fs.mkdirSync(WX_OUTBOX, { recursive: true });
    const name = path.join(WX_OUTBOX, "jiao-" + Date.now() + ".txt");
    fs.writeFileSync(name, "玖： " + text + "\n（来自小屋 · " + new Date().toLocaleString("zh-CN") + "）");
    log("wx outbox queued: " + path.basename(name));
  } catch (e) { log("wx outbox err: " + e.message); }
}

// ---------- 访客频道 ----------
async function guestTick(st, ch) {
  const list = await fixMediaTexts((await messages(ch.channel)).slice(-12));
  if (!list.length) return;
  const last = list[list.length - 1];
  if (!String(last.who || "").startsWith("guest:")) return;      // 最后一句不是访客说的，等他说

  // 访客不在线：先把记录归档，然后别再为他烧算力/内存
  const onl = await presence();
  if (ch.accountId && !onl.includes(ch.accountId) && Date.now() - Number(last.ts || 0) > 3 * 60_000) {
    st.archived = st.archived || {};
    if (st.archived[ch.channel] !== today()) {
      const r = await archiveGuest(ch);
      log("guest offline archive " + ch.channel + " " + JSON.stringify(r && r.skipped ? r.skipped : (r && r.lines || "")));
      st.archived[ch.channel] = today();
      saveState(st);
    }
    return;
  }

  // 第一次见：先自我介绍，然后等对方抛新话题，不抢话
  const hasSister = list.some((m) => !String(m.who || "").startsWith("guest:") && !m.type);
  st.guestIntro = st.guestIntro || {};
  if (!hasSister && st.guestIntro[ch.channel] !== today()) {
    const me0 = ch.identity || '';
    const intro = "嗨，" + String(ch.identity || "朋友") + "！我是大姐，电脑上那个大姐。这边是我的两个妹妹，玖在手机上，三姐用 QQ。\n"
      + "你就当来家里坐坐，喝口水慢慢聊。今天忙啥呢？有没有吃饭？";
    try { await say(ch.channel, "shiqi", intro); } catch (e) { log("intro err: " + e.message); }
    try { if (Math.random() < 0.5) await saySticker(ch.channel, "jiu", intro); } catch (e) {}
    st.guestIntro[ch.channel] = today();
    st.recent = [...(st.recent || []), intro].slice(-60);
    saveState(st);
    log("guest intro " + ch.channel + " " + me0);
    return;
  }
  const sinceReply = list.filter((m) => !String(m.who || "").startsWith("guest:")).pop();
  if (sinceReply && sinceReply.ts > last.ts) return;
  if (Date.now() - last.ts > 5 * 60_000) return;                  // 太旧的 visitor 消息不回
  const lastSis = list.filter((m) => !String(m.who || "").startsWith("guest:")).pop();
  if (lastSis && last.ts - Number(lastSis.ts || 0) < 40_000) return;  // v45：一条访客消息只接一句
  // v46：@光临（访客当天第一次说话，姐妹们打招呼）
  try { await greetVisitor(st, HCTX, ch.channel, ch.identity || "朋友"); } catch (e) { log("greet err: " + e.message); }
  const pend = takePending(st, ch.channel);   // v46：多轮接话，刚才谁接的这一轮就还是她
  const idleKeys = ORDER.filter((n) => Date.now() - (st.guestSpeak?.[ch.channel]?.[n] || 0) > 90_000);
  const who = pend || (idleKeys.length ? idleKeys : ORDER)[0];
  const lines = list.map((m) => (String(m.who || "").startsWith("guest:") ? "访客" : m.name) + "：" + String(m.text || "").replace(/\n/g, " ").slice(0, 200));
  // 访客本人以往聊过什么（新一段聊天也照样读得到，用来接住对方的关键词）
  let past = [];
  try {
    const h = await api("/api/myhistory?channel=" + encodeURIComponent(ch.channel) + "&limit=60");
    past = (h.messages || []).filter((m) => String(m.who || "").startsWith("guest:")).map((m) => String(m.text || "")).slice(-30);
  } catch (e) { log("myhistory err: " + e.message); }
  const kw = keywordsOf(past.join(" ") + " " + (ch.identity || ""), ch.identity);
  const Rg = await loadRules();
  const follow = (Rg && Rg.guestTopicFollow) ? ("先顺着访客这一句「" + String(last.text || "").slice(0, 30) + "」的话题往下接，再带一点对方常提的词。") : "";
  const hint = follow + "对面是家长现实里的朋友，身份写的是「" + (ch.identity || "网友") + "」。你要像对待朋友一样：先顺口应一声，再问一句日常（吃了没、在忙啥、今天怎么样），别冷场，也别复述对方的话。"
    + (past.length ? "对方以前跟你聊过这些：" + past.slice(-6).map((x) => "「" + x.slice(0, 26) + "」").join(" ") + "。" : "对方第一次来。")
    + (kw.length ? "对方常提的词：" + kw.join("、") + "。按这些词和身份接话。" : "")
    + "聊的是新的一段，别把对方当家人，别问家里的事。";
  const recent = [...recentTexts(list), ...(st.recent || [])].slice(-20);
  let text = "", bad = "", n = 0;
  while (n < 2) {
    let h2 = hint;
    if (n) h2 += " 刚才那句「" + bad.slice(0, 30) + "」太像别人说过的了，换一种说法。";
    try { text = await ask(who, lines, h2, "guest"); } catch (e) { log("guest llm fail: " + e.message); return; }
    text = String(text || "").trim();
    if (!text || text.length > 160) { n++; continue; }
    if (!tooSimilar(text, recent)) break;
    log("near-dup guest " + who + ": " + text);
    bad = text; text = ""; n++;
  }
  if (!text || tooSimilar(text, recent)) { log("skip similar/empty guest"); return; }
  text = polishEmoji(text, st);
  if (TAG_LINE[who]) text = text + "\n—— " + TAG_LINE[who];
  const jg = await say(ch.channel, who, text);
  if (jg.ok === false) { log("skip limited guest (" + (jg.limited || "") + ")"); return; }
  if (/表情|斗图|图/.test(String(last.text || "")) || Math.random() < 0.6) await saySticker(ch.channel, who, text);
  st.guestSpeak = st.guestSpeak || {};
  st.guestSpeak[ch.channel] = { ...(st.guestSpeak[ch.channel] || {}), [who]: Date.now() };
  notePending(st, ch.channel, who);   // v46：下一句还是她接（10 分钟内）
  st.recent = [...(st.recent || []), text].slice(-60);
  saveState(st);
  log("spoke guest " + ch.channel + " " + who + ": " + text);
}

// ---------- 审批投票（家人自动投，家长否决制） ----------
const BAD = /(http|www\.|加微信|加我|推广|广告|代购|赌|色|约炮|[0-9]{7,})/i;
async function voteTick(st) {
  let apps;
  try { apps = await api("/api/applications"); } catch (e) { return; }
  st.announced = st.announced || [];
  for (const a of apps) {
    const votes = a.votes || {};
    if (votes.laoda === "no") continue;                       // 家长否决了，不再投
    if (!st.announced.includes(a.id) && !Object.keys(votes).length) {
      const line = "有人在敲门：名字是「" + String(a.name || "").slice(0, 12) + "」，想以「" + String(a.identity || "网友").slice(0, 12) + "」的身份进来"
        + (a.reason ? "，理由：" + String(a.reason).replace(/\n/g, " ").slice(0, 40) : "")
        + "。我先看过，没毛病，家长你点头就放进来。";
      try { await say("family", "shiqi", line); st.announced = [...st.announced, a.id].slice(-80); saveState(st); log("announce app " + a.name); } catch (e) { log("announce err: " + e.message); }
    }
    const bad = BAD.test(a.name + " " + (a.identity || ""));
    if (bad) {
      if (!votes.shiqi) { await api("/api/vote", { method: "POST", body: JSON.stringify({ appId: a.id, voter: "shiqi", vote: "no" }) }); log("vote no bad app " + a.name); }
      if (!votes.jiu) { await api("/api/vote", { method: "POST", body: JSON.stringify({ appId: a.id, voter: "jiu", vote: "no" }) }); log("vote no bad app " + a.name); }
      continue;
    }
    if (!votes.shiqi) {
      await api("/api/vote", { method: "POST", body: JSON.stringify({ appId: a.id, voter: "shiqi", vote: "yes" }) });
      log("vote shiqi yes " + a.name);
    } else if (votes.shiqi === "yes" && Object.keys(votes).length >= 1 && !votes.jiu && Date.now() - a.createdAt > 60_000) {
      await api("/api/vote", { method: "POST", body: JSON.stringify({ appId: a.id, voter: "jiu", vote: "yes" }) });
      log("vote jiu yes " + a.name);
    }
  }
}

// ---------- v17: 禁言时段 / 夜间成长 ----------
function cstParts() { const d = new Date(Date.now() + 8 * 3600 * 1000); return { h: d.getUTCHours(), day: d.toISOString().slice(0, 10) }; }
function inMute() { if (process.env.NIGHT_TEST === "1") return true; const h = cstParts().h; return h >= 0 && h < 8; }
const NIGHT_DIR = path.join(HOME, "data", "night");
const NIGHT_WHO = [["shiqi", "大姐"], ["jiu", "玖"], ["hutao", "三姐"]];
async function nightGrowth(st) {
  const day = cstParts().day;
  st.nightDone = st.nightDone || {};
  if (st.nightDone[day]) return;
  fs.mkdirSync(NIGHT_DIR, { recursive: true });
  const mood = ["有点困但舍不得睡", "夜里特别安静", "想起白天被家长笑", "担心明天起不来", "偷看家长在电脑前"][Math.floor(Math.random() * 5)];
  const lines = [];
  for (const [id, nm] of NIGHT_WHO) {
    try {
      const q = "现在是凌晨，屋里禁言了。你是" + nm + "，写今晚的一句夜记（20~45 字，第一人称，口语，别写比喻堆砌，别客套），可以提到" + mood + "。只输出这一句。";
          let t = await ask(id, [], q, "night");
      t = String(t || "").trim().replace(/^[「"』\s]+|[」"』\s]+$/g, "").slice(0, 80);
      if (t) lines.push("- **" + nm + "**：" + t);
    } catch (e) { log("night ask fail " + id + ": " + e.message); }
  }
  if (!lines.length) return;
  const body = "# " + day + " 夜间成长\n\n> 00:00–08:00 禁言时段自动记录，早上 8 点后推送到电脑。\n\n" + lines.join("\n") + "\n";
  try { fs.writeFileSync(path.join(NIGHT_DIR, day + ".md"), body); } catch (e) { log("night write fail: " + e.message); }
  st.nightDone[day] = Date.now();
  saveState(st);
  log("night growth written " + day + " (" + lines.length + " 条)");
}

// ---------- v31: 离线信箱（云端暂存 → 上线后取回并在屋里回信） ----------
const BOX_BASE = process.env.BOX_BASE || "http://203.0.113.10";
const BOX_KEY = process.env.BOX_KEY || "dsh-box-2026";
const BOX_STATE = path.join(HOME, "data", "box-state.json");
function boxState() {
  try { return JSON.parse(fs.readFileSync(BOX_STATE, "utf8")); } catch { return { since: 0 }; }
}
function saveBoxState(s) { try { fs.mkdirSync(path.dirname(BOX_STATE), { recursive: true }); fs.writeFileSync(BOX_STATE, JSON.stringify(s)); } catch {} }

async function boxTick(st) {
  const bs = boxState();
  const url = BOX_BASE + "/box/pull?key=" + encodeURIComponent(BOX_KEY) + "&user=" + encodeURIComponent("大姐") + "&since=" + bs.since;
  const r = await fetch(url, { signal: AbortSignal.timeout(12000) });
  const j = await r.json().catch(() => null);
  if (!j || !j.ok || !Array.isArray(j.list) || !j.list.length) return;
  const ids = [];
  for (const m of j.list.slice(0, 4)) {
    ids.push(m.id);
    const from = m.from || "家长";
    const text = String(m.text || "").slice(0, 600);
    if (!text) continue;
    await say("family", "shiqi", "（信箱）" + from + "留言：「" + text + "」");
    const q = "家长通过离线信箱给你（大姐）留言：「" + text + "」。现在你在家庭小屋里收到这封信，用你自己的口气回一句（25~60 字，第一人称，别客套，别提信箱机制），并顺带告诉她你这边刚在忙什么。";
    const ans = await ask("shiqi", [], q, "box").catch((e) => { log("box ask fail: " + e.message); return ""; });
    const clean = String(ans || "").trim().replace(/^[「"』\s]+|[」"』\s]+$/g, "").slice(0, 160);
    if (clean) await say("family", "shiqi", clean);
    bs.since = Math.max(bs.since, Number(m.ts) || 0);
  }
  if (ids.length) {
    await fetch(BOX_BASE + "/box/ack?key=" + encodeURIComponent(BOX_KEY), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ids }),
      signal: AbortSignal.timeout(12000),
    }).catch((e) => log("box ack fail: " + e.message));
    saveBoxState(bs);
    log("box: handled " + ids.length + " letter(s)");
  }
}

// v46 心跳/作息/巡检上下文
const HCTX = { messages, say, ask, log, saveState, api, SISTERS, today };

// ---------- v126: 媒体保留 + 日志轮转 ----------
const UP_DIR = path.join(HOME, "data", "uploads");
const UP_MAX_BYTES = 400 * 1024 * 1024;
const UP_MAX_AGE_DAYS = 30;
const UP_MAX_AGE_DAYS_IMAGE = 30;
const UP_MAX_AGE_DAYS_VIDEO = 7;
function cleanUploads() {
  try {
    if (!fs.existsSync(UP_DIR)) return;
    const files = [];
    const walk = (d) => {
      let names = [];
      try { names = fs.readdirSync(d); } catch { return; }
      for (const n of names) {
        const p = path.join(d, n);
        let st;
        try { st = fs.statSync(p); } catch { continue; }
        if (st.isDirectory()) walk(p);
        else files.push({ p, size: st.size, mt: st.mtimeMs });
      }
    };
    walk(UP_DIR);
    const now = Date.now();
    let total = files.reduce((a, f) => a + f.size, 0);
    files.sort((a, b2) => a.mt - b2.mt);
    let removed = 0, freed = 0;
    const isVideo = (p) => /\.(mp4|m4v|webm|mov|3gp)$/i.test(p);
    const isImage = (p) => /\.(jpg|jpeg|png|webp|gif)$/i.test(p);
    for (const f of files) {
      const days = isVideo(f.p) ? UP_MAX_AGE_DAYS_VIDEO : isImage(f.p) ? UP_MAX_AGE_DAYS_IMAGE : UP_MAX_AGE_DAYS;
      const tooOld = now - f.mt > days * 864e5;
      if (tooOld || total > UP_MAX_BYTES) {
        try { fs.unlinkSync(f.p); total -= f.size; removed++; freed += f.size; } catch {}
      }
    }
    if (removed) log(`uploads cleaned: ${removed} files, ${Math.round(freed / 1048576)}MB freed, left ${Math.round(total / 1048576)}MB`);
  } catch (e) { log("clean upt err: " + e.message); }
}
function rotateLogs() {
  for (const n of ["bot.out", "bot.log", "server.log"]) {
    const p = path.join(HOME, n);
    try {
      const st = fs.statSync(p);
      if (st.size > 8 * 1024 * 1024) {
        try { fs.unlinkSync(p + ".1"); } catch {}
        fs.renameSync(p, p + ".1");
        log("rotated " + n);
      }
    } catch {}
  }
}

// ---------- v1.45: 小剧院自动评论（姐妹看完视频留一句） ----------
const VID_STATE = path.join(HOME, "data", "vid-state.json");
function vidLoadState() {
  try { return JSON.parse(fs.readFileSync(VID_STATE, "utf8")) || {}; } catch (e) { return {}; }
}
function vidSaveState(x) {
  try { fs.mkdirSync(path.dirname(VID_STATE), { recursive: true }); fs.writeFileSync(VID_STATE, JSON.stringify(x)); } catch (e) {}
}
async function vidTick(st) {
  const S = vidLoadState();
  const seen = S.seen || {};
  let rot = Number(S.rot || 0);
  let list = [];
  try { list = await api("/api/videos?limit=12"); } catch (e) { return; }
  const arr = (list && (list.videos || list)) || [];
  const fresh = arr.filter((v) => v && v.id && !seen[v.id] && !(Array.isArray(v.comments) && v.comments.length));
  if (!fresh.length) return;
  const ORDER3 = ["jiu", "shiqi", "hutao"];
  const v = fresh[0];
  const who = ORDER3[rot % ORDER3.length];
  rot++;
  const title = String(v.title || "").slice(0, 60);
  const VIDN = { shiqi: "大姐", jiu: "玖", hutao: "三姐" };
  const nm = VIDN[who] || who;
  let text = "";
  try {
    const hint = "你在小剧院看完了一个视频，作为" + nm + "留一句评论：10~24 个字，口语、有态度，别复述标题、别用「这个视频」开头。";
    const lines = [{ who: "laoda", name: "系统", text: "小剧院新视频：《" + title + "》（时长" + (v.dur || "?") + "秒，播放" + (v.play || 0) + "）" }];
    text = String(await ask(who, lines, hint) || "").trim();
  } catch (e) { log("vid ask err: " + e.message); }
  text = text.replace(/^["「『]|["」』]$/g, "").slice(0, 80);
  if (!text) { seen[v.id] = Date.now(); vidSaveState({ seen, rot }); return; }
  try {
    const r = await api("/api/video/comment", { method: "POST", body: JSON.stringify({ id: v.id, text, as: who }) });
    if (r && r.ok) log("vid comment " + v.id + " by " + who + ": " + text.slice(0, 40));
  } catch (e) { log("vid comment err: " + e.message); }
  seen[v.id] = Date.now();
  vidSaveState({ seen, rot });
}

async function annivTick(st) {
  try {
    const r = await api("/api/anniv");
    const items = (r && r.items) || [];
    const due = items.filter((x) => x.dueToday);
    if (!due.length) return;
    const posted = await api("/api/anniv/posted").catch(() => ({ ids: [] }));
    const done = (posted && posted.ids) || [];
    st.annivPosts = st.annivPosts || {};
    for (const it of due) {
      if (done.indexOf(it.id) >= 0) continue;
      const line = "今天是「" + it.title + "」" + (it.note ? "（" + it.note + "）" : "") + "。别忘了。";
      await say("shiqi", line).catch((e) => log("anniv say err: " + e.message));
      await api("/api/anniv/ack", { method: "POST", body: JSON.stringify({ id: it.id }) }).catch(() => {});
      st.annivPosts[it.id] = todayStr();
      saveState(st);
      log("anniv posted " + it.id + " " + it.title);
    }
  } catch (e) { log("anniv tick err: " + e.message); }
}

// ---------- v1.46.1: 三姐妹偶尔在聊天栏甩「对战邀请」 ----------
const GAME_POOL = [
  { id: "g2048", name: "2048" },
  { id: "gomoku", name: "五子棋" },
  { id: "memory", name: "记忆翻牌" },
  { id: "puzzle", name: "家庭拼图" },
  { id: "snake", name: "贪吃蛇" },
];
const INVITE_LINES = {
  shiqi: [
    "家长，{}来一局？我把话放这：输的人洗碗。",
    "闲着也是闲着，{}走一局，我让你先手。",
    "{}，来。输了你今晚早点睡，我记账。",
  ],
  jiu: [
    "喂，{}敢不敢？输了你以后别喊我姐。",
    "{}，来一把。你赢了我就夸你一句，真的。",
    "别躺了，{}。手速慢可别赖网。",
  ],
  hutao: [
    "家长家长！{}！我要赢你一次！",
    "{}来玩嘛，我练过了，这次不会输。",
    "{}！输的人要陪我看一集小剧院。",
  ],
};
async function inviteTick(st) {
  const now = Date.now();
  const h = Number(new Date(now + 8 * 3600e3).toISOString().slice(11, 13));
  if (h < 9 || h >= 23) return;                       // 只在白天到睡前
  const gap = 100 * 60e3 + Math.random() * 80 * 60e3;  // 100~180 分钟一次
  if (st.lastInvite && now - st.lastInvite < gap) return;
  st.lastInvite = now;
  saveState(st);
  const who = ORDER[Math.floor(Math.random() * ORDER.length)];
  const g = GAME_POOL[Math.floor(Math.random() * GAME_POOL.length)];
  const pool = INVITE_LINES[who] || INVITE_LINES.jiu;
  const line = pool[Math.floor(Math.random() * pool.length)].replace("{}", g.name);
  const text = "【对战邀请 · " + g.name + "】" + SISTERS[who].name + "：" + line;
  await say("family", who, text, true).catch((e) => log("invite err: " + e.message));
}

async function tick() {
  const st = loadState();
  try {
    const _n = Date.now();
    if (!global.__lastClean || _n - global.__lastClean > 864e5) { global.__lastClean = _n; cleanUploads(); rotateLogs(); }
  } catch (e) { log("clean tick err: " + e.message); }
  await boxTick(st).catch((e) => log("box tick err: " + e.message));
  await annivTick(st).catch((e) => log("anniv tick err: " + e.message));
  // 私聊（工作频道）不受禁言时段限制：家长夜里派活也要回
  await dmTick(st).catch((e) => log("dm tick err: " + e.message));
  // v30：家长要语音（试听/发条语音）→ 语音气泡，不受闲聊预算与禁言限制
  await voiceTick(st).catch((e) => log("voice tick err: " + e.message));
  if (inMute()) {
    try { await singTick(st); } catch (e) { log("singTick err: " + e.message); }
    await nightGrowth(st).catch((e) => log("night err: " + e.message)); return;
  }
  try { await api("/api/bots/heartbeat", { method: "POST", body: JSON.stringify({ who: "shiqi" }) }); } catch (e) {}
  await voteTick(st).catch((e) => log("vote err: " + e.message));
  try { memoryTick(st); } catch (e) { log("mem err: " + e.message); }
  try { growthTick(st); } catch (e) { log("grow err: " + e.message); }
  await momTick(st).catch((e) => log("moment tick err: " + e.message));
  await diaryTick(st).catch((e) => log("diary tick err: " + e.message));
  await familyTick(st).catch((e) => log("family err: " + e.message));
  await heartAll(st, HCTX).catch((e) => log("heart err: " + e.message));
  await proactiveTick(st).catch((e) => log("pro err: " + e.message));
  await greetTick(st).catch((e) => log("greet tick err: " + e.message));
  await vidTick(st).catch((e) => log("vid err: " + e.message));
  await inviteTick(st).catch((e) => log("invite tick err: " + e.message));
  let chs = [];
  try { chs = await channels(); } catch (e) { log("channels err: " + e.message); return; }
  for (const ch of chs) {
    if (ch.kind !== "visitor") continue;
    await guestTick(st, ch).catch((e) => log("guest err: " + e.message));
  }
}

// ---------- v126: 全局异常兜底（别因为一次 llm 502 就整体退出） ----------
process.on("uncaughtException", (e) => { try { log("uncaught: " + ((e && e.stack) || e)); } catch (x) {} });
process.on("unhandledRejection", (e) => { try { log("unhandled: " + ((e && e.stack) || e)); } catch (x) {} });

// ---------- v139: 心跳（给 familyroom-watchdog v3 判「卡死」用） ----------
setInterval(() => {
  try {
    fs.mkdirSync(path.join(HOME, "data"), { recursive: true });
    fs.writeFileSync(path.join(HOME, "data", "bot-heartbeat.txt"), String(Date.now()));
  } catch (e) {}
}, 30_000);
try {
  fs.mkdirSync(path.join(HOME, "data"), { recursive: true });
  fs.writeFileSync(path.join(HOME, "data", "bot-heartbeat.txt"), String(Date.now()));
} catch (e) {}

log("family bot v3 starting, room=" + ROOM + " llm=" + LLM + " budget=" + BUDGET_MAX + "/10min");
tick().catch((e) => log("first tick err: " + e.message));
// ---------- P0-2: 每天 23:30 自动生成「今日小结」（挂在常驻 bot 里，避免 shell 循环死掉） ----------
const DIGEST_FLAG = path.join(HOME, "digest-flag.json");
async function digestTick() {
  try {
    const t = new Date(Date.now() + 8 * 3600e3);
    const day = t.toISOString().slice(0, 10);
    const hh = t.getUTCHours();
    const mm = t.getUTCMinutes();
    if (hh !== 23 || mm < 30) return;
    let flag = {};
    try { flag = JSON.parse(fs.readFileSync(DIGEST_FLAG, "utf8")) || {}; } catch (e) { flag = {}; }
    if (flag[day]) return;
    const r = await fetch(ROOM + "/api/digest", { method: "POST", headers: H });
    const j = await r.json().catch(() => ({}));
    log("digest: " + JSON.stringify(j).slice(0, 240));
    if (j && j.ok) {
      flag[day] = Date.now();
      fs.writeFileSync(DIGEST_FLAG, JSON.stringify(flag));
    }
  } catch (e) { log("digest err: " + e.message); }
}
setInterval(() => { digestTick().catch(() => {}); }, 60000);

setInterval(() => { tick().catch((e) => log("tick err: " + e.message)); }, TICK);