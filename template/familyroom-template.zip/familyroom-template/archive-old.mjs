// 家庭小屋：旧消息归档（T4）—— 把 N 天前的 <date>.jsonl 压成 <date>.jsonl.gz
// 用法：node archive-old.mjs [--days 14] [--dry]
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

const HOME = process.env.HOME || "/data/data/com.termux/files/home";
const R = path.join(HOME, "familyroom");
const DATA = path.join(R, "data");
const MSGS = path.join(DATA, "msgs");
const LOG = path.join(R, "archive.log");
const arg = process.argv.slice(2);
const DRY = arg.includes("--dry");
const di = arg.indexOf("--days");
const KEEP = di >= 0 ? Number(arg[di + 1]) || 14 : 14;

function log(s) {
  const line = new Date(Date.now() + 8 * 3600e3).toISOString().replace("T", " ").slice(0, 19) + " " + s;
  console.log(line);
  try {
    let old = "";
    try { old = fs.readFileSync(LOG, "utf8"); } catch {}
    fs.writeFileSync(LOG, (old + line + "\n").split("\n").slice(-400).join("\n"));
  } catch {}
}
function dayStr(off) { return new Date(Date.now() + 8 * 3600e3 + off * 86400e3).toISOString().slice(0, 10); }
const cutoff = dayStr(-KEEP);
log(`archive start keep=${KEEP}d cutoff<${cutoff} dry=${DRY}`);

let dirs = [];
try { dirs = fs.readdirSync(MSGS).map((d) => path.join(MSGS, d)).filter((d) => { try { return fs.statSync(d).isDirectory(); } catch { return false; } }); } catch {}
let archived = 0, skipped = 0, freed = 0, failed = 0;
for (const dir of dirs) {
  let files = [];
  try { files = fs.readdirSync(dir); } catch { continue; }
  for (const f of files) {
    const m = /^(\d{4}-\d{2}-\d{2})\.jsonl$/.exec(f);
    if (!m) continue;
    const date = m[1];
    if (date >= cutoff) { skipped++; continue; }
    const fp = path.join(dir, f);
    const out = path.join(dir, date + ".jsonl.gz");
    if (fs.existsSync(out)) { log(`skip exist ${path.basename(dir)}/${date}`); continue; }
    try {
      const raw = fs.readFileSync(fp);
      if (!raw.length) { log(`empty ${path.basename(dir)}/${date}`); continue; }
      const gz = zlib.gzipSync(raw, { level: 9 });
      // 回读校验：解压后必须与原文完全一致
      const back = zlib.gunzipSync(gz);
      if (back.length !== raw.length) throw new Error("roundtrip length mismatch");
      if (DRY) { log(`[dry] would archive ${path.basename(dir)}/${date} ${raw.length}->${gz.length}`); continue; }
      const tmp = out + ".tmp";
      fs.writeFileSync(tmp, gz);
      fs.renameSync(tmp, out);
      fs.unlinkSync(fp);
      archived++; freed += raw.length - gz.length;
      log(`archived ${path.basename(dir)}/${date} ${raw.length} -> ${gz.length}`);
    } catch (e) {
      failed++;
      log(`FAIL ${path.basename(dir)}/${date} ${e.message}`);
    }
  }
}
log(`archive done archived=${archived} skipped=${skipped} failed=${failed} freed=${freed}B`);