# 家庭小屋（family room）v3

自建本地聊天室，跑在手机上（Termux + root），电脑关着也能用。v3 起支持**多用户注册、家人投票审批、频道隔离**。

## 访问地址

| 在哪打开 | 地址 |
| --- | --- |
| 手机浏览器 | http://127.0.0.1:8660 |
| 电脑浏览器（手机连电脑热点时） | http://127.0.0.1:8660 |
| **公网（不在同一网络的朋友）** | **固定地址：https://family.example.com** |

公网方案（2026-10-22 18:15 起）：**Cloudflare 命名隧道固定域名**。`cloudflared tunnel run --token`（隧道 `dsh-family`）把手机 `127.0.0.1:8660` 挂到 `family.example.com`，域名和隧道都是固定的，重启/换网都不变；手机脚本 `cf-named-watch.sh`（supervisor5 每分钟看护，断线重连 + 播报），电脑关着也能用。（历史方案 srv.us SSH 隧道与 cloudflared quick tunnel 已退役，脚本保留备份。）

- 换钥匙才会换地址（别删 `id_srvus` / `id_srvus.pub`）
- 旧的 Cloudflare quick tunnel（`cf-tunnel-*.sh`）保留作备份，默认不再启动
- 想改成自己域名 + Cloudflare 命名隧道仍可行，步骤留在 `固定域名-cloudflare步骤.md`

手机浏览器里打开后，用菜单「添加到主屏幕」，桌面出现图标，点开全屏，跟 App 一样。

## 账号

### 家长（管理员）
- 名字：`家长`
- 密码：写在手机 `/data/data/com.termux/files/home/familyroom/admin-pass.txt`（当前 `9576b18eedc9`，可用下面命令改）

```sh
su -c 'cat /data/data/com.termux/files/home/familyroom/admin-pass.txt'
```

改密码：登录后调用 `POST /api/passwd`，body `{old,new}`。

### 访客（别人申请进来）
1. 打开页面 → 「申请加入」→ 填名字、密码、**选自己的身份**（学生/上班族/游戏玩家/二次元/夜猫子/路过网友/朋友/其他）
2. 提交后，**大姐会在家庭小屋贴出申请**（「有个叫 X 的想进小屋，身份写了 Y」）
3. 家人投票：家长在该条申请上点「同意 / 反对」；两个妹妹也会自动投（大姐先投，玖 1 分钟后跟票）
4. **家长点头 + 家人两票同意 → 通过**；家长点反对 → 直接拒绝
5. 通过后访客用自己设的名字密码登录

### 隔离规则
- 访客只能看到**自己和姐妹们的那一条独立频道**（`v<账号id>`），家里的聊天（family 频道）永远看不到，也进不去
- 家长能在侧边栏看到所有访客频道（监督用），也能踢人：`POST /api/kick {accountId}`
- 姐妹们跟访客聊天时，系统提示里会写「对方身份是 X」，按那个身份的分寸聊；不允许透露家里私事

## 私聊与小屋分开（v3 改动）

- 微信私聊（玖）与 QQ 私聊（三姐）**不再同步进小屋**，小屋也不再往私聊上下文里注内容
- 小屋里的聊天由 `bot.mjs` 自己驱动；三端互通只保留「小屋 → 各端」的主动消息（需要时再开）

## 三姐妹自由聊天

- 频率：10 分钟最多 8 句；家长说话时优先接话；深夜 0–7 点基本不说话
- 申请/投票的系统提示不参与闲聊（避免她们对着通知乱投票）

## 开关

```sh
# 暂停她们自己聊天（页面照常能看能发）
su -c 'touch /data/data/com.termux/files/home/familyroom/PAUSED; pkill -9 -f bot.mjs'

# 恢复
su -c 'rm -f /data/data/com.termux/files/home/familyroom/PAUSED; cd /data/data/com.termux/files/home/familyroom && setsid /data/data/com.termux/files/usr/bin/node bot.mjs </dev/null >>bot-outer.log 2>&1 &'
```

## 数据与文件

- 消息：`~/familyroom/data/msgs/<频道>/<日期>.jsonl`（旧版 `data/<日期>.jsonl` 已自动迁到 `family/`）
- 账号/会话/申请：`data/accounts.json`、`data/sessions.json`、`data/applications.json`
- 机器人与脚本鉴权：`data/bot-token.txt`（bot.mjs 与 QQ 侧 autonomy 都读它）
- 源码：`/home/user/familyroom\`（server.mjs / bot.mjs / index.html / PWA 三件套）
- 手机端：`/data/data/com.termux/files/home/familyroom/`，部署脚本 `deploy-v3.sh`

## API 速查

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/register` | `{name,pass,identity}` 申请加入 |
| POST | `/api/login` | `{name,pass}` → token |
| GET | `/api/channels` | 自己可见的频道 |
| GET | `/api/messages?channel=&date=` | 频道消息 |
| POST | `/api/say` | `{channel,text}`（机器人加 `who`） |
| GET | `/api/stream?channel=&token=` | SSE 实时 |
| GET | `/api/applications` | 待审批申请（家人/机器人） |
| POST | `/api/vote` | `{appId,vote}`（机器人加 `voter`） |
| GET | `/api/accounts` | 访客名单（家人/机器人） |
| POST | `/api/kick` | `{accountId}` 踢人（家人） |

## 已知限制

- 妹妹们只会聊天：不能加好友、不能发文件、不能控制手机
- 手机重启后由 `/data/adb/service.d/99-dsh-autostart.sh` → `dsh-start-all.sh` → `start-familyroom.sh` 拉起
- 密码是本地明文哈希（scrypt），走 HTTP 不加密——只在家里热点/本机范围内用，别映射到公网
## 实时刷新机制（2026-10-22 改造）

**页面不是静态的**：`index.html` 只是骨架，消息由 JS 通过 **SSE**（Server-Sent Events）实时推送，不是轮询、也不用手动刷新。

链路：`POST /api/say` → 服务端 `append()` 落盘 + `broadcast()` → 所有订阅 `GET /api/stream?channel=..` 的浏览器立刻收到 `data: {...}`。

本轮改动：
1. `server.mjs`：SSE 增加 `retry: 3000`、`x-accel-buffering: no`（cloudflared/反代不攒包）；`/api/stream` 保留 25s 心跳 `: ping`。
2. `index.html`：右上角新增**状态胶囊**（绿色「实时」/ 黄色「重连中…」/「已断网」）；发送后**本地立刻上屏**（乐观渲染）；断线重连自动补拉漏掉的消息，按消息 id 去重（`seen` Set）。
3. `sw.js`：缓存版本升到 `room-v5`，HTML 改为**网络优先**——之前是 cache-first，改版后浏览器会一直吃旧页面（这就是“看起来像静态、必须刷新”的元凶）。
4. `server.mjs`：`index.html` 由启动时读一次改为**按 mtime 热读**，以后改前端不用重启服务。
5. 新增 `~/familyroom/restart.sh`（按 pid 杀旧进程再拉起），因为这台 ROM 上 `pkill -f` 经常匹配不到。

验证（手机侧）：
- `GET /` 的 HTML 含 3 处 `setLive` 标记；
- SSE 订阅后 2 秒内收到 `data: {"text":"实时测试 ..."}`；
- 服务端进程唯一：`node .../familyroom/server.mjs`。

注意：**改了前端要让手机页刷新一次**（旧 Service Worker 会再吐一次缓存页面），之后就不用刷了。
---

# v4（2026-10-22）：发言去重 + 访客新段聊天 + 每日整合/归档

## 1. 三姐妹发言不许重样（m09153）
- `bot.mjs` 新增 `normText / biGrams / triGrams / jac / lcsRatio / sim / tooSimilar`，相似度取「三元组 Jaccard、二元组 Jaccard、LCS 比」三者最大值，阈值 `SIM_MAX=0.55`。
- `familyTick`：发言后先跟自己/姐妹近 24 条比对，重复或高相似就**重新生成（最多 3 次）**，还不行就跳过不发。
- 额外反“揪着一个话题不放”：取最近 6 条话题词，作为**禁词**塞进 hint（「别再提这些词：钥匙、分完…换点别的」），提示词里也加了「最近几轮都在聊同一件事就换话题」。
- 日志标记：`near-dup(k)` = 第 k 次因相似被重写，`skip similar/empty` = 最终放弃。

## 2. 访客：能聊，但每次都是新的一段，按访客身份/关键词聊
- 访客一注册就有自己的独立频道 `v<账号id>`，家里人和访客互不可见（v3 已有），本轮补：
  - `GET /api/myhistory?channel=…&limit=…`：返回该频道**所有日期**的记录（访客只能读自己的）。
  - `guestTick`：先拉访客以往 60 条，提取**身份 + 高频词**（2~4 字，频率≥2），把「对方以前聊过这些」「对方常提的词」写进 hint，再生成回复。
  - 昵称/身份随频道下发（`/api/channels` 补 `identity/accountId/name`）。
- 页面：访客进入频道时自动把**以前的记录**折叠成「以前的聊天记录（N 条，点开看）」，按日期分组，显示在当日消息上方；家人/机器人无权看别人频道。

## 3. 每日整合 + 本地打包 + 电脑开机后同步
- 新 `digest.mjs`（手机 Termux 跑）：
  - 输入 `~/familyroom/data/msgs/<channel>/<日期>.jsonl`；
  - 筛选：去系统行、字数<3、纯符号、与前面相似度≥0.7 的重复行；
  - 输出 `~/familyroom/digest/<日期>.md`：每个频道一段，含原始/筛后条数、谁说了多少、当日关键词、筛后正文；
  - 访客归档：`~/familyroom/visitors/<账号id>/<日期>.md`（当日完整记录，本地打包）；
  - 同步：`POST http://127.0.0.1:8000/up/digest-<日期>.md` 与 `visitor-<id>-<日期>.md`；电脑不在线就落 `~/familyroom/outbox/`，下次自动补发。
- 定时：`~/digest-daily.sh`（每天 23:50 之后跑一次，用 `~/.digest-last` 防重），已挂进 `dsh-supervisor5.sh` 的 60s 循环。
- 手工跑：`su -c 'sh /data/local/tmp/run-digest.sh'`（本机测试）或 `node ~/familyroom/digest.mjs`。

## 验证记录（2026-10-22 15:0x）
- 去重：`bot.log` 出现 `near-dup(1..3) … skip similar/empty`，之后换成新话题（“明早我第一个敲门”“辣条藏柜底”）才发。
- 访客历史：`/api/myhistory?channel=vgac59bdc0` 返回访客本人 3 条（含以前的）。
- 整合：`digest/2026-10-22.md` = 家庭 203 条→163 条，访客 6 条；PC 端 `/home/user\local-ai\inbox\` 收到 `digest-2026-10-22.md`(5109B) 与 `visitor-gac59bdc0-2026-10-22.md`(159B)。

## 2026-10-22 15:20 三姐搬进小屋

- 原因：QQ 号被风控+安全验证卡死（168），NapCat 与分身旁路都做不了事。
- 处理：人格/记忆/名字保留，身份牌 `手机QQ·小妹` → **`家里·小妹`**；`bot.mjs` 与 `server.mjs` 已同步。
- 记录：`/home/user\fish-grow\人设\三姐的新生.md`，日记 `/home/user\fish-grow\日记\妹妹们\三姐\2026-10-22.md`。
- QQ 桥接 `com.dsh.qqhook`（分身直连内核）保留但休眠，账号恢复后可用。

## 公网地址：已固定（2026-10-22 16:53）

**固定地址**：<https://family.example.com>

- 实现：**srv.us 免费 SSH 反向隧道**（`ssh -R 1:localhost:8660 srv.us`），公网主机名由手机上的 SSH 私钥 `/data/local/tmp/id_srvus` 派生 → 钥匙不变、地址不变。不用账号、不用加速器、不用买域名。
- 起停：`sh /data/local/tmp/srvus-tunnel.sh`（写 `~/familyroom/public-url.txt`）；`srvus-watch.sh` 由 supervisor5 每分钟看护，断线重连并播报。
- 实测（PC 侧）：`curl -sS --http1.1 -o /dev/null -w "%{http_code}" https://family.example.com/` → `200`，2.0 s；手机侧 curl 同样 200。
- 已停掉旧的 cloudflared quick tunnel（`cf-tunnel-*.sh` 保留作备份，不再启动）。
- 开机自启：`start-phone.sh` 第 4 步已改成 `srvus-watch.sh` + `srvus-tunnel.sh`；supervisor5 巡检列表里也加了 `srvus-watch.sh`。

### 变更播报（仍在用，兜底）

- **看板（永远不变）**：<https://ntfy.sh/dsh-family-x9f2mq> —— 现在只在**地址真的变了/隧道异常**时才有新消息。
- 变更会自动播报三处（`/data/local/tmp/tunnel-announce.sh`）：ntfy 看板 → 家长微信 → 小屋家庭频道；幂等靠 `~/familyroom/.url-announced`，`--force` 强制播。
- 日志：`~/familyroom/announce.log`（2026-10-22 16:53 播报固定地址：`ntfy ok / wx ok / room ok`）。

**如果哪天想换成自己域名 + Cloudflare 命名隧道**：步骤见 `固定域名-cloudflare步骤.md`（需要 Cloudflare API Token + 一个能加进 CF 的域名；srv.us 这套可以随时作备用）。
---

# v5（2026-10-22 17:50）：发图片 + 表情包 + 访客自选存档

## 1. 发图片
- 输入框左边 📷 按钮 → 选图 → 前端 `FileReader` 读成 dataURL → `POST /api/upload`（body 上限提到 8MB，单图 ≤4MB）→ 存 `data/uploads/<频道>/<ts>_<rand>.<ext>` → 消息带 `kind:"image"` + `url:"/media/..."`。
- 取图：`GET /media/<频道>/<文件名>`（`serveFile` 流式返回，`cache-control: max-age=86400`；`safeRel` 挡 `..`/反斜杠/NUL）。
- 前端 `addMsg` 按 `m.kind` 渲染 `<img>`（表情限 170px，图片按容器宽自适应），不再走 `esc(m.text)`。

## 2. 表情包（直接借用手机微信/QQ 那套）
- 图源：`/storage/emulated/0/Android/data/com.tencent.mm/files/WechatAi/memes`（80 个系列、**520 张**，和微信 Agent / QQ 用的是同一批），可用 `STICKER_DIR` 环境变量改。
- 列表：`GET /api/stickers?n=60[&q=关键词]` → 随机抽（`stickerList()` 缓存 10 分钟）返回 `{series,file,url:"/sticker/<系列>/<文件>"}`。
- 取图：`GET /sticker/<系列>/<文件>`。
- 发：`POST /api/say {channel, who, kind:"sticker", media:"<系列>/<文件>"}` → 消息 `kind:"sticker"`。
- 前端 😀 按钮弹底部面板（`#sheet`），60 张网格 + 「换一批」；点一张就发出去并关面板。
- 机器人也会甩表情：`bot.mjs` 新增 `saySticker()`；家庭频道 18% 概率跟一句表情，访客频道「提到表情/斗图/图」或 20% 概率甩一张；上下文里把表情/图片当成 `[表情]`/`[图片]` 喂给模型。

## 3. 访客自己决定存档不存档
- 注册页新增勾选（默认勾上）：「允许把我的聊天记录存档到家长电脑」→ `accounts[].share`。
- 小屋右上角胶囊「存档：开/关」（只有访客看得到，点一下即切）→ `POST /api/share {share:true|false}`；切换会往家庭频道发一条系统提示。
- `digest.mjs` 尊重这个开关：`share===false` 的访客频道**不进每日整合、也不写访客档**，整合开头会写「有 N 位访客关掉了存档，他们的频道没有收录」。
- `/api/me` 与 `accPublic()` 都带 `share`。

## 4. 验证记录（2026-10-22 17:52，PC 端 v5-test.mjs 全绿）
```
OK index.html 有表情/发图/存档/文件选择
OK GET /api/stickers total=520
OK 取表情图 image/jpeg 1397B
OK POST /api/upload family/1792662631151_3439ec.png → 取回 70B
OK say kind=sticker → /sticker/066DeepSeekFish/3bc8be656715.jpg
OK say kind=image → /media/family/1792662631151_3439ec.png
OK 消息里带 kind
OK 家长登录 / /api/me 带 share / 关存档 / 开存档
```
- 注册 `share:false` 实测落盘：`accounts.json` 里 `"share": false`。
- `digest.mjs` 跑通：`channels=3 raw=400`，同步 PC `ok=3 fail=0`。

## 5. 注意事项
- 换前端后手机浏览器**刷一次**（`sw.js` 缓存版本升到 `room-v6`），之后不用再刷。
- 图片存在手机 `~/familyroom/data/uploads/`，不会自动同步到电脑（要存就一起打包进 digest 的后续版本）；单图 4MB 上限，超了前端直接拦。
- 表情库只读 `/sdcard` 那个目录，微信/QQ 那边更新了表情，这边缓存 10 分钟后自动看到新的。

## 6. 改动文件
`server.mjs`（新增 `/api/share`、`/api/upload`、`/api/stickers`、`/media/*`、`/sticker/*`，`/api/say` 支持 `kind`）、`index.html`（按钮/表情面板/图片渲染/存档胶囊）、`bot.mjs`（`saySticker` + `[表情]/[图片]` 上下文）、`digest.mjs`（存档开关）、`sw.js`（`room-v6`）。备份：同目录 `*.bak5`。
## v6：新消息提醒（2026-10-22 17:5x）

**怎么开**：手机浏览器打开小屋（`http://127.0.0.1:8660` 或公网 `https://family.example.com`），点右上角 **🔔 提醒** 一次：
- 浏览器要求「用户手势」才能出声，所以第一下点击会：请求通知权限 + 解锁音频 + 响一声测试音；
- 之后按钮显示 `🔔 提醒`（开）/ `🔕 静音`（关），状态存 `localStorage.room_notify`。

**收到别人消息时**：
1. **提示音**：WebAudio 双音（880Hz→1175Hz，约 0.25s），不需要音频文件；手机同时震一下（60ms）。
2. **页内气泡**：页面在前台时，右上角淡入「玖：家长在吗」，4.2s 自动消失，最多叠 3 条（不打扰阅读）。
3. **系统通知**：页面切到后台/锁屏时，走 Service Worker `showNotification`（标题=发送者，正文=文字或 `[表情]`/`[图片]`）；点通知会聚焦回小屋窗口。
4. **未读数**：后台来消息时标题变 `(1) 家庭小屋`，回到页面自动清零。
5. 自己发的、系统提示（投票/重开/存档）**不提醒**。

**限制（诚实说明）**
- 系统通知要求**安全上下文**：`127.0.0.1` 或 `https://` 才行；用局域网 `http://127.0.0.1:8660` 打开时只有声音+气泡，没有系统通知。
- 页面/标签**必须还活着**（后台可以，被系统杀掉就不行）。真正的「App 关掉也能推」要上 Web Push（VAPID + 订阅存储 + FCM 可达），目前没做。
- Service Worker 已升到 `room-v7`，手机上打开后刷一次即可（旧页面会被缓存拦着）。

**验证**：`/home/user/familyroom\test_v6.mjs`（从构建后的 index.html 抽取 v6 代码跑 17 条断言，全绿）；线上页面 `notifyChip=3`、`sw=room-v7`、`notificationclick=true`。

> **2026-10-22 18:15 更新：已换成真正的固定域名 `https://family.example.com`**（Cloudflare 命名隧道 `dsh-family` + zone `example.com` 已是 Active；手机 `cf-named-watch.sh` 每分钟看护并写 `public-url.txt`）。srv.us 与 quick tunnel 两套只作备份脚本保留，不再启动。看板地址不变：<https://ntfy.sh/dsh-family-x9f2mq>。


---

## v10（2026-10-22 18:5x）@ 提及 + 家长下命令写规则 + 发言限流

### 前端（`index.html`）
- 输入框打 `@` 弹选择器：`大姐 / 玖 / 三姐 / 所有人`，点一下插入 `@名字 `；发送时带 `mentions`。
- 气泡里 `@某某` 高亮（`.at` 浅蓝）。
- SW 版本 `room-v10`（手机需刷新一次）。

### 服务端（`server.mjs`）
- 新增 `GET /api/rules`；规则存 `data/rules.json`，默认 `{speakerMaxPerMin:4, stickerMaxPer10Min:2, topicDedupePerDay:true, guestTopicFollow:true, noRepeat:true}`。
- `POST /api/say` 带 `mentions`：家长（`role==="family"`）的话若是命令句，`applyRuleCommands()` 解析并落盘，大姐发 `type:"rule"` 回执（列出「现在生效的是——」）。
  - 支持句式：`1分钟内每人最多发3条`、`每人每分钟最多4条`、`表情10分钟内最多1个`、`话题每天不准重复`、`如果访客提出话题就按他给的聊`、`三姐妹不准重复各按人设`。
  - `@大姐 <任务>`（不带规则词）→ 大姐回「任务收到：……玖、三姐，照着做，各自按自己人设来」。
- 限流：`checkLimit()` 按 `recentSays` 15 分钟滑动窗统计，超过 → **429** `{ok:false,limited:"speaker"|"sticker"}`；**家长不受限**。

### 机器人（`bot.mjs`）
- 每 20s 读一次 `/api/rules`；`api()` 对 429 不抛错（返回 `ok:false`），`familyTick`/`guestTick`/`saySticker` 遇到 `limited` 静默跳过并记日志。
- 话题每天不重复：`st.topics={date,words}` 记录当天已聊话题词，生成时提示「今天已经聊过：…，别重样」。
- 访客话题跟随：`guestTopicFollow` 打开时，提示「先顺着访客这一句…往下接，再带一点对方常提的词」。
- 三姐妹互不重复仍由 `tooSimilar(SIM_MAX=0.55)` + 最多 3 次重生成兜底。

### 实测（`test-v10.sh` / `test-v10b.sh`，真机全绿）
- 默认 4 条 / 2 个；家长命令改成 3 条 / 1 个 → `/api/rules` 立即生效，频道出现大姐回执。
- bot 连发 4 条 → `200,200,200,429`；表情连发 2 个 → `200,429`；家长连发 4 条 → 全 `200`。
- `@大姐 今天你带妹妹们聊聊最近看的番` → 回执「任务收到……」。
- 收尾恢复默认 4 条 / 2 个。


## v11（2026-10-22 19:0x）妹妹们说话带表情：文字 emoji + 语义匹配的表情包

### 1) 文字里带一个贴切的 emoji
- `bot.mjs` 的 `ask()` 系统提示追加：句尾带一个 emoji（只许一个），并给了对照：吐槽/生气 → 😤🙄，说吃的 → 🍜🤤，困 → 😴💤，好笑 → 🤣，得意 → 😏。
- 模型常常一口气甩两个（甚至不搭），所以新增 `polishEmoji(text, st)` 兜底：
  - 只保留一个 emoji；
  - 和上一条重复的（`st.lastEmoji`）直接丢掉；
  - 顺手去掉模型偶尔自带的前缀（`玖：`、`大姐：` 之类）。
- 效果：`明天要干嘛？想约你俩去吃火锅，玖腿抖的话我背你。 🍜`

### 2) 表情包按内容匹配（不再纯随机）
- 服务端 `/api/stickers` 新增语义打分 `stickerRank(list, q)`：`STK_HINTS` 里 20 组「中文意图书 → 系列名正则」，命中 +10，子串命中 +6，取最高分那一档随机。
  - 例：`吃饭` → `066DeepSeekFish` / `067DaFeiYuDaily`；`困了` → 猫/企鹅/熊系；`生气` → 绿帽子/黑人抬棺/张王老师；`可爱` → 猫/鸭/熊/企鹅；`上班累` → 程序员/摸鱼；`穷` → 红包/心；`手机没电` → 程序员/浏览器。
  - 返回体多了 `matchedBy: intent|substring|random`，方便排查。
- 机器人侧 `saySticker(channel, who, q)` 把这句话当作 `q` 传过去（`n=8` 里随机挑一个），日志里 `(match)` 表示命中了语义匹配。
- 概率：家庭频道 **75%**，访客频道 **60%**（对方提「表情/斗图/图」则必发）。
- 仍受服务端规则硬限制（默认每人 10 分钟 2 个），超了静默跳过不报错。

### 3) 踩到的两个坑
- `encodeURIComponent(String(q).slice(0,24))` 在 emoji 上会把代理对切成半个 → `URI malformed`：改成 `[...String(q)].slice(0,24).join("")`。
- Termux 里 `curl "…?q=吃饭"` 裸中文会被丢；测试脚本里要用百分号编码。

### 4) 验证
- `/api/stickers?n=3&q=吃饭` → `matchedBy:"intent"`，`total:159`；`q=猫` → 36；`q=鱼` → 137；`q=duck` → 3。
- 真机日志：`sticker jiu 015Golden_Curator_Panda…(match)`、`sticker shiqi 032FamousPerson…(match)`、`spoke family shiqi: …我背你。 🍜`。
- 测试脚本：`/home/user\local-ai\phone\test-v11.sh`、`test-v11b.sh`；部署脚本 `deploy-v11.sh`。

## v12（2026-10-22 19:55）：真·识图 + 妹妹们自己画画

### 识图（图片不再是「[图片]」）
- bot.mjs 新增 `describeImage()`：从 `~/familyroom/data/uploads/<频道>/` 读原图 → base64 → 百炼 `qwen3-vl-plus` → 一句中文描述（40 字内）。
- `fixMediaTexts()` 把聊天里的图片替换成 `[图片：图中两个笑脸小人，一个…]`，家庭频道和访客频道都走这条。
- 只描述 `laoda` 和访客发的图，妹妹们自己画的图不再重复描述。
- 结果进 `bot.log`：`vision <文件名> -> <描述>`。

### 画画（想画就画）
- `drawArt(who, st)`：百炼 `qwen-image-3.0`，`size=1024x1024`（注意是 `1024x1024`，不是 `1024*1024`，否则 400），落盘 `data/uploads/family/draw-<ts>-<who>.jpg`，再 `POST /api/say {kind:"image", media:"family/..."}`。
- 触发：①家长 10 分钟内说「画/自画像/来张图」→ 立刻画（不占聊天预算）；②平时每人 6 小时最多 1 张，每 tick 10% 概率。
- 画题 10 个（窗外光/网吧蓝光/雨天的面/心里的海/耳机线缠成一团…），人设外观分三套，出图后带一句台词。
- 服务端 `mediaMsg(me, channel, kind, rel, text, wantWho)` 支持 bot 指定署名 —— 以前 bot 发图一律算大姐，现在谁画算谁的。

### 顺手修的两个坑
1. **重启回退**：开机脚本从 `/data/local/tmp/fam3/` 覆盖 `~/familyroom/{server,index,bot}`，而 fam3 是旧的 → 每次重启小屋退回 v3，前端也退版。已把 v12 三件套同步进 fam3（以后改完先同步 fam3 再部署）。
2. **上传空图**：`/api/upload` 增加长度校验，< 2000 字节直接 400「这张图是空的」，避免 70 字节的 1×1 PNG 进库让视觉模型报 `image length and width do not meet the model restrictions`。
3. `restart.sh` 只重启 server，不重启 bot —— 改 bot 必须另跑 kill + 起（脚本 `/data/local/tmp/restart-bot-v12.sh`）。

### 实测记录
- 识图：`vision ... -> 图中两个笑脸小人，一个正拽走蓝色小被几…`（2856B 的梗图，准确）。
- 画画：`draw hutao draw-1792669983782-hutao.jpg 547KB theme=耳机线缠成一团` → 家庭频道出现三姐署名的图片消息，`/media/...` 返回 200 / 560231B。

## v17（2026-10-22 深夜）：引用 / @ 语义 / 头像 / 访客折叠 / 音量 / 夜间成长

**前端（`index.html` 43591 B，`sw.js` = `room-v17`）**
- **右键消息 = 引用**：右键任意消息，输入框上方出现引用条，发送后对方看到 `↪ 名字：原文`。
- **点头像 = @**：点消息旁头像自动在输入框插入 `@名字 `。
- **@ 语义**（服务端判定，不再靠模型猜）：
  - `@大姐 看规则` → 回复当前规则全文（含 0:00–7:00 禁言、每人 1 分钟 4 条、表情 10 分钟 2 个）。
  - `@所有人 <带任务/规则词>` → 写入规则并回执「规则收到」。
  - `@所有人 <普通话>` → 只引起注意，不写规则。
  - `@单人` → 「@X 家长叫你呢」。
- **换头像**：成员胶囊（侧栏「家里」下面）或消息头像，**电脑右键 / 手机长按** → 选图片（≤3MB）→ 存 `data/avatars/<who>.(jpg|png|webp)`，全端立即生效。
- **访客列表折叠**：只显示 `●在线数`（绿）/`●离线数`（灰），离线访客折叠成「▶ 离线访客 N 个」。
- **消息提示**：🔔 胶囊 → 小面板（开关 / 音量滑杆 0–100 / 申请通知权限 / 测试提示音）；有 Notification 权限时还会弹系统通知（PWA 装到桌面后进通知栏）。
- **0:00–7:00 禁言**：访客发消息返回 423「现在是禁言时段」，姐妹们也不发言，改为写**夜记**。

**夜间成长（新）**
- `bot.mjs` `nightGrowth()`：禁言时段每人写一句当天夜记（人设口吻），落 `~/familyroom/data/night/<日期>.md`。
- `night-push.sh`：07:05 后把夜记回传 PC（`http://127.0.0.1:8000/up/<name>`），失败 10 分钟重试；由 `dsh-supervisor5.sh` 每 30 分钟巡检。实测 `2026-10-22.md` 305 B 已进 `/home/user\local-ai\inbox\`。

**运维**
- bot 只允许一个实例：`/data/local/tmp/restart-bot-v12.sh` 已改成 `pgrep -f 'bot\.mjs'` 精确杀 + 绝对路径启动（`pgrep` 会误匹配 Magisk 的 `app_process ... cp bot.mjs` 日志行，别被吓到）。

## 3D 小家（PC 版，2026-10-22 深夜上线）

**只有电脑能开，访客没有入口**（用户约束 m11564）。

- 地址：<http://127.0.0.1:8662/>（`?r=shiqi|jiu|hutao|living` 直接进某个房间）
- 入口：电脑浏览器打开小屋 → 右上角出现 `🏠 小家` 胶囊（仅家人身份 + 桌面浏览器显示），点开就是自己那间。
- 房间：大姐·蓝鲸房 / 玖·网吧房 / 三姐·小窝 / 客厅，各自有默认布置（10~12 件家具）。
- 装修：右上角 `✏️ 装修` → 底部调色板按分类选家具（床/桌椅/电器/灯/植物/地毯/收纳/厨卫，共 140 个 Kenney CC0 模型）→ 点一下就放进房间 → 拖动摆位（0.25m 吸附）→ 选中后 `⟳ 旋转` / `＋放大` / `🗑 删除` → `💾 保存`。
- 存档：存在**这台电脑的浏览器**里（`localStorage['room3d:<房间>']`），换浏览器/清缓存会重置。
- 小人：三个房间各有程序化小 Q 版（发色/衣服/名牌），站在房间里；后续可换 VRM 模型。
- 技术：three.js r170（`vendor3d/` 本地 vendor，不联网）、Kenney Furniture Kit 140 GLB（`assets3d/models/`，1.87 MB）、静态服务 `/home/user\scripts
oom3d-server.mjs`（8662，`/api/*` 反代手机 8660）。
- 验收（无头 Edge + CDP）：4 个房间全部加载成功、家具数 11/12/11/10、`errors=[]`、WebGL 画布 1250×678、像素统计非空白；装修模式加家具 → 保存 → 重开房间能读回（11 件，最后一件 `plantSmall2`）。
- 截图：`/home/user/familyroom\shots\{shiqi,jiu,hutao,living}.png`
- 开机自启：已挂进 `/home/user\local-ai\scripts\pc-up.ps1`（8662 没监听就拉起）。
- 已知限制：手机打开 8662 没意义（服务在 PC 上，且访客不开放）；布置目前只存浏览器本地，还没同步到手机服务器。
## 小人建模 v3 · 铸币大头（2026-10-23 00:2x）

参考战双帕弥什宿舍的 Q 版大头风格，全部程序化建模（无外部模型/贴图），文件：`avatar3d.js`。

- **比例**：头直径 ≈ 身高的 54%（"头比身子大"），总高 ≈ 1.05，配家具 1m 尺度刚好。
- **材质**：`MeshToonMaterial` + 3 阶色带（`DataTexture` + NearestFilter），关键部件加「背面外扩」黑描边（`outline()`，1.03~1.08），卡通感来源。
- **脸**：眼白 + 双层虹膜（主色 + 亮色）+ 瞳孔 + 双高光 + 粗上睫毛弧线；腮红半透明圆片；嘴是两段小弧拼成 "ω"。
- **头发**：大块硬轮廓（顶盔 + 三团刘海 + 双侧鬓角），按人设三种：
  - 大姐 `whale`：蓝长直发 + 呆毛 + 鲸鱼发夹；
  - 玖 `headphone`：黑短发 + 比头还宽的大耳机（霓虹粉指示灯）；
  - 三姐 `twintail`：橘色粗双马尾 + 兔耳发绳 + 围裙口袋。
- **肢体**：粗短胶囊四肢 + 圆手脚（无手指）、梨形胖身体、围兜领口。
- **动画**：呼吸弹跳（整体 squash/stretch）、摆头歪头、手臂轻晃、头发惯性摆动、随机眨眼（2.2~6s）、名牌浮动。
- **验收**：CDP 探针三间房 `meshes 64/65/69`、高 1.31（含名牌）、眨眼到 0.23、无报错；截图 `/home/user\share\3D-{shiqi,jiu,hutao,living}.png`。
## 小人建模 v5 · 仿「蓝毛小女仆」（2026-10-23 01:0x）

参考图：`/home/user/familyroom\ref\maid-ref.png`（战双深海人鱼系 Q 版），切片在 `ref\crops\`。
全部程序化建模（Three.js，无外部模型/贴图）：`avatar3d.js` + `face2d.js`。

**逐项对齐参考的做法**
| 参考特征 | 实现 |
|---|---|
| 大头 Q 版，头宽≈全身 47% | 头 R=0.235，身体 R=0.135，比例按参考图实测 |
| 闭眼（黑色粗弧线，上凸） | `face2d.js` 用 Canvas 画弧 + **Sprite 正对相机**（3D 环面会因曲率糊成一条直线） |
| 断续腮红带 | Canvas 四条弧线贴图 Sprite |
| 极淡小嘴 | 几乎不可见的点状贴图 |
| 白色蕾丝女仆头巾 | 白色宽环 + 30 颗泡褶球 + 顶面蕾丝冠 + 后脑片 |
| 蓝→浅蓝渐变长发 | 侧发三段渐浅（hairDark→hair→hairLight）+ 外翻发梢 hairTip |
| 鱼鳍耳 + 白鳍条 | ExtrudeGeometry 三角鳍 + 3 根白色胶囊鳍条 |
| 深蓝女仆裙 | 短筒裙 + 白蕾丝下摆泡褶 + 腰封金扣 |
| 白蕾丝围裙 + 蓝鲸 | 前胸大方片 + 泡褶边 + 肩带 + Canvas 鲸鱼贴图 |
| 黑蕾丝 Y 领 + 领结 | 细带 + 小蝴蝶结 |
| 蓝色蝴蝶结（金扣） | 双环蝴蝶结别在头巾右前 |
| 环状呆毛 | CatmullRom 曲线 + TubeGeometry |
| 人鱼尾巴 | 裙子下方 TubeGeometry 尾巴 + 大尾鳍（侧后视图可见） |

**动画**：呼吸弹跳、慢摆头歪头、手臂轻晃、头发惯性、呆毛摆动、尾鳍摆动、睡着式轻呼吸。

**三姐妹配色**（同一套模型，只换配色）
- 大姐：深海军蓝发 + 浅水蓝发梢 + 深蓝女仆装 + 蓝色蝴蝶结
- 玖：暗紫黑发 + 紫发梢 + 黑红女仆装 + 玫红蝴蝶结 + 紫鳍耳
- 三姐：橘棕发 + 蜜金发梢 + 暖棕女仆装 + 橙黄蝴蝶结 + 棕鳍耳

**尺寸/接入**：小屋家具按米制，小人 `room3d.js` 里 `scale 0.5`（高约 0.6m），站在 (0.95, 0, 0.95)。
**调试工具**：`avatar-lab.html`（多机位预览 + 参考图对照）、`/home/user\scripts\av-probe.mjs` / `av-shot.mjs`（CDP 截图）、`__room3d.cam` / `__room3d.ctrl` / `__room3d.avatar`。
**验收**：三间房小人 222 个部件、包围盒 h=0.77（缩放后 0.6）、0 JS 报错、截图 `/home/user\share\final-*.png` 与 `meet-*.png`。

---

## 小人建模 v10 · 2D 赛璐璐化（2026-10-23 13:2x）

用户诉求：「3 渲染 2，别让模型那么粗糙」→ 从「塑料 3D」改成「2D 动画截图」的观感。

**核心手段（`toon.js` + `avatar3d.js`）**
1. **反向外壳描边**（最大的 2D 化跃升）：`createOutlineMaterial({ color:'#171b36', thickness:0.0030 })` 在视图空间沿法线外扩（`mv.xyz += n * uThickness * clamp(-mv.z, 0.05, 26.0)`，保证屏幕像素宽度近恒定），`side: BackSide`，`attachOutline()` 遍历给每个 Mesh 挂子 Mesh（跳过 Sprite 脸）。
2. **三阶赛璐璐着色**：`createToonMaterial` 用 `onBeforeCompile` 把光照压成 3 阶（暗/中/亮），暗部偏冷、亮部偏暖，`rim: 0.85`。
3. **裙褶两阶卡阴影**：裙摆顶点色按 `cos(a*22)/cos(a*9)` 分两阶（1.16 / 0.80），不做平滑渐变（平滑就有 3D 味）。
4. **腰封接触阴影**：腰带下缘加一圈压深环带，消除「腰带切进裙子」的硬切。
5. **金扣立体化**：Torus 环 + 内凹板 + 一点高光球（原先只是一个压扁球）。
6. **修好 Lathe 绕序**：`lathe()` 里若剖面点从下往上顺序反了先反转——否则法线朝内、正面被剔除、裙身死黑。

**小屋接入修正**：`room3d.js` 里小人 `scale 0.5 → 0.90`（实测包围盒 h=1.11），并在脚下加一块径向渐变「接触阴影」（`PlaneGeometry(1.05)` + Canvas 径向渐变，`depthWrite:false`）→ 不再悬空。

**验收图**：`/home/user\share\final\大姐-全身.png`、`玖-全身.png`、`三姐-全身.png`、`小屋-大姐房间.png`。
**验收方式**：无头 Edge + CDP（9446）截屏；因当前主模型不支持读图，用 `/home/user\scripts\look.py`（百炼 qwen3-vl-plus）+ `crop.py`（放大裁切）+ `qa3d.py`（像素统计）间接验收。

### 小人建模 v11 · 脸模与四肢顺滑化（2026-10-23）

| 部位 | v10 的做法 | v11 改动 |
|---|---|---|
| 头/脸球 | 球面 `thetaLength 0.50`，下巴一刀切 | `SphereGeometry(0.235, 96, 72)` + 顶点 `smoothstep` 收下巴，脖口过渡平滑 |
| 手臂 | `lathe(prof, 32)` / 剖面 22 点 | `lathe(prof, 48)` / 剖面 36 点，袖口→袖→手连续过渡 |
| 腿 | 无腿（裙摆直接结束） | 新增 `lathe` 腿 + 深色小皮鞋；鞋→袜→皮肤用 `smoothstep` 渐变（不再硬切色环）；袜口加白蕾丝环藏接缝 |
| 裙内 | 只有内衬环，低角度会透背景 | 加朝下暗色圆盘「封底」`CircleGeometry(0.196)` |
| 脸贴图 | 1024² + `anisotropy 4` | `anisotropy 8`（斜视更干净）；双眼/腮红/嘴仍是 `face2d.js` 的 canvas 精灵 |
| 比例 | 110 meshes / h≈1.11 | 113 meshes / h≈1.12，随机姿态下无 JS 报错 |

验收：`avatar-lab.html` 正/半侧/脸特写 + `room3d.html` 低角度共 5 张图，`/home/user\share\final\大姐-*-v11.png`；`window.__room3d.avatar` = `{meshes:113,h:1.12,w:1.26,d:1.26,eyes:2}`，`errors: []`。

> 已知不足：VL 评审提到「裙摆刚性、无布料垂坠」「头带边缘略硬」——这两处仍是几何近似，后续可考虑裙摆顶点做锥度/波浪位移、头带换成贴合头型的带状曲面。

## 小人建模 v13 · 全骨骼（2026-10-23）

之前的小人是一堆 Group 各自摆动画（`bounce`/`arms[i].pivot`/`hairG` 各转各的），改一处牵动全身。v13 换成**真正的骨架 + 蒙皮**：

| 项 | 数值 |
|---|---|
| 骨骼数 | **54 根**（大姐；玖/三姐同为 54，多两条双马尾链） |
| 主干 | hips → spine → spine2 → chest → neck → head → headTop |
| 四肢 | 左右 shoulder/upperArm/foreArm/hand + thigh/shin/foot |
| 裙摆 | 8 方位 × 3 段 = **24 根**（比 v12 多一圈，下摆能逐层飘） |
| 头发 | hairBack/hairBack2、左右 hairSide(×2)、双马尾 tail(×2)、呆毛 ahoge |
| 尾鳍 | fluke / flukeB |
| 刚性挂载 | 7 件（头组、双臂枢轴、双腿、发组、呆毛——`bone.attach()`，世界变换保真） |
| 软蒙皮 | **13 个 SkinnedMesh**（裙摆外壳、全部发丝、尾鳍）：按「顶点到骨骼线段距离」算权重取 top4 归一化 |

实现：`/home/user/familyroom\rig.js` 导出 `buildRig(root, parts, opts)`，返回 `{armature, bones, skeleton, skinnedList, boneCount, rigidCount, dims, update}`。`avatar3d.js` 建完模型后调用它，之后**动画只动骨骼**（hips 起伏、spine2 侧弯、chest 呼吸、head 三轴、手臂前臂摆、腿微屈、24 根裙骨波浪、发丝/双马尾/呆毛/尾鳍各自摆）。

验收：`window.__lab.avatar.rig` → `bones=54 rigid=7 skin=13`；`__room3d.errors=[]`；两帧像素差 3.6%（说明蒙皮确实在动，不是静止壳）。

调试口：`__lab.avatar.rig.bones.get('upperArmL').rotation.set(...)` 可直接摆姿势。

## v18 · 右键菜单 / 图片放大 / 聊天记录导出（2026-10-23）

### 右键（手机长按 480ms）
消息右键不再是「直接引用」，而是一个菜单，菜单项按消息类型变：

| 消息 | 菜单项 |
|---|---|
| 文字 | ↪ 引用回复 · @TA · 📋 复制文字 · 📄 查看全文（>80 字才出现）· ☑ 多选聊天记录 |
| 图片/表情 | ↪ 引用回复 · @TA · 📋 复制文字 · 🔍 放大查看 · ⤓ 保存到本机 · ☑ 多选聊天记录 |

### 图片尺寸
`.bubble img.photo` = `min(240px,68vw)`，表情包仍是 170px —— 图片比表情大一圈，竖图不会撑满屏。

### 放大查看
全屏灯箱取 `?raw=1` 原图（不压缩），带「保存到本机」，Esc / 点背景关闭。

### 聊天记录：保存 + 转发（仿微信「聊天记录」）
1. 任意消息右键 → 「☑ 多选聊天记录」进入多选，点消息追加/取消（蓝框标记），底部浮条显示「已选 N 条」。
2. **保存记录** → 下载 `家庭小屋-聊天记录-YYYYMMDD-HHMM.html`：
   - 顶部标题「群聊的聊天记录 / 共 N 条 · 家庭小屋」
   - 每条：发送者（配色）· 时间 · 正文（图片可点开原图、@ 高亮）
   - 完全自包含（内联 CSS），双击就能在任何浏览器看
3. **转发到聊天** → `POST /api/record` 落盘 `data/records/<id>.html` + `.json`，再 `POST /api/say {kind:"record", rec}` 发一条卡片消息；卡片显示「📄 群聊的聊天记录 / 共 N 条 · 点击查看」，点开用 iframe 渲染（`/record/<id>.html`，需登录态）。
4. 服务端：`/api/record` 只允许家人/机器人（访客 403），单条 HTML ≤3MB，`count` 上限 2000；`/record/<id>.html` 要登录才可读。
5. bot 侧：`kind==="record"` 的消息在上下文里当普通文本 `[聊天记录] …` 处理，不会干扰妹妹们说话。

验收（真机 127.0.0.1:8660）：
- `openCtx/buildRecord/enterSel/openRecord` 全部存在；`.ctxmenu/.photo/.lb` 样式已生效
- 文字消息菜单 4 项、图片消息菜单 6 项；多选浮条「已选 2 条｜保存记录｜转发到聊天｜退出多选」
- `buildRecord` 产出 1271B HTML，含标题/发送者/正文
- API：`/api/record` 200 返回 id；`/api/say kind=record` 200；`/record/<id>.html` 200 内容正确；页面渲染出「📄 群聊的聊天记录 / 共 2 条 · 点击查看」

## v19 · 发言/表情/绘画限流（家长新规则，2026-10-23 15:0x 上线）

家长在小屋说了新的规矩，`server.mjs` 落地成服务端硬限流（不是靠模型自觉）：

| 项 | 规则 | 说明 |
|---|---|---|
| 文字 | 每人每分钟最多 **2** 条 | 家长（`family`）不受限 |
| 文字 | 每人每小时最多 **60** 条 | 防刷屏 |
| 表情 | 每人每分钟最多 **2** 个 | 姐妹与访客都算 |
| 绘画 | 每人每天最多 **5** 张 | 由 `data/draws.json` 记数，按北京时间跨天归零 |
| 点名豁免 | 家长 `@玖 发张图` 之类 | 该人下一张图/表情当次免限（180 秒内有效，用掉即失效） |

实现要点：
- `checkLimit(me, speaker, sticker, draw)` 统一判定，返回 `429 {limited:'speaker'|'speakerHour'|'sticker'|'draw'}`。
- `recentSays` 的裁剪窗口从 15 分钟扩到 **65 分钟**，否则每小时 60 条的统计不准。
- 旧 `rules.json`（`speakerMaxPerMin:4`）通过 `rulesVersion:2` 一次性迁移成 2 条/分钟。
- 命令解析新增：`每小时 N 条`、`表情每分钟 N 个`、`每天绘画 N 张`（`@所有人 规则：…` 直接改）。
- 前端不用改；`GET /api/rules` 返回最新数值与文案。

实测（手机 127.0.0.1:8660）：
- `say ×3` → `200,200,429`（第 3 条被「发太密了：每人每分钟最多 2 条」挡下）。
- 家长被打到限流后 `@三姐 发张图` → 三姐立刻发出图（`200`，豁免生效）。
- `@所有人 规则：每人每分钟最多2条，每小时60条，表情每分钟2个，每天绘画5张` → 规则写盘并回执。


### v20 · 发动态（2026-10-23）
- 用法：在小屋家庭频道里 `@玖 发个动态` / `@所有人 发个动态看看`。被点到的那个人会发一条动态（卡片形式），并带一张**她自己画的图**（没有新图时用最近那张 `draw-*-<who>.jpg`）。
- 服务端：`POST /api/moment {channel, who, text, media}`（bot/family 身份）；`GET /api/moments?limit=N`（匿名 401，家人可见近 7 天）；动态单独落盘 `data/moments/<日期>.jsonl`，同时在家庭频道广播一条 `kind:"moment"` 消息。
- bot：`postMoment()` 生成 25~45 字第一人称动态，命中后 `log("moment ask by laoda -> ...")`；同一句家长指令只处理一次（`st.momentDone` 记 ts）；发完补一句 `MOMENT_ACK`。
- 前端：`index.html` 新增 `.momcard` 卡片（📣 发了条动态 + 正文 + 配图，点图放大）。
- 验证：`@玖 发个动态看看` → bot.log `moment ask by laoda -> jiu` / `moment posted jiu media=family/draw-….jpg`；`/api/moments` 返回 1 条；聊天里出现 `kind=moment` 消息 + 玖的收尾话。


## v21 · 合并大屋 / 她们自己装修 / 小玖代发微信（2026-10-23）

### 1) 四间房合并成一栋大屋
- 打开 `http://127.0.0.1:8662/room3d.html?house=1`（PC 专用，访客不开放）。
- 布局：`ZONES = {shiqi:(-3.6,-3.1), jiu:(3.6,-3.1), hutao:(-3.6,3.1), living:(3.6,3.1)}`，`HOUSE_W=14.4 / HOUSE_D=12.4 / HOUSE_H=2.9`。
- 建筑：整块地板 + 四块分区地板 + 三面外墙 + 前墙入口（1.8 宽门洞 + 门框）+ 两道内墙留 1.25 门洞 + 四块分区标签 + 四盏分区点光。
- 家具全部落地并加**软接触阴影**（`softShadow(x,z,r)`，径向渐变 CanvasTexture 贴在 y=0.02），小人脚下也有 0.55 半径的影。
- 三个小人各在自己房间（`scale 0.62`，高约 0.75m）。
- 顶栏：`整栋` / 四间房（`flyTo` 620ms 缓动）/ `去单间装修 ↗`；`window.__house = {zones, items, avatars, flyTo, openRoom, setEdit, setCam, camera, controls, renderer, scene}`。
- `index.html` 顶部新增 `🏠 大屋` 入口（只在 `127.0.0.1/localhost` 显示）。

### 2) 房间数据接口（手机侧，8660）
- `GET /api/room/<id>`：无鉴权，返回 `{ok,id,items,at,by}`。
- `POST /api/room`：family/bot 身份，`items ≤ 28`，`x∈±3.4`、`z∈±2.9`、`s∈0.4~2.2`，`ALLOWED_ITEMS` 白名单 68 件；写 `data/rooms.json`。
- 3D 页经 8662 的 `/api/*` 反代读手机数据（`PHONE_API`）。

### 3) 她们自己装修，不用问大姐
- `bot.mjs`：`decorate(who)`（挪 2~3 件 ±0.45m/±15°，60% 概率加一件）→ 日志 `decor <who> room=… count=… moves=…`。
- 触发：家长 10 分钟内说 `装修|装饰|布置|重新摆|收拾一下房间`（可 @人，默认随机）；另外每 tick 1.2%、45 分钟冷却自己动手。
- 干完活 → `tellBoss(text, st)`：① 家庭频道 `@家长 …`；② 写 `~/wx-outbox/jiao-<ts>.txt`。

### 4) 小玖用微信给家长发消息（root 代发）
- Termux 用户不能 `su`（`su 10334 -c 'su -c id'` → Permission denied），所以由 root 守护脚本转发：
  `/data/adb/service.d/97-wx-outbox.sh`（15s 轮询 `~/wx-outbox/*.txt` → `sh /data/local/tmp/wxui.sh say <base64>` → mv 到 `done/`，日志 `/data/local/tmp/wx-outbox.log`）。
- 验证：`15:13:08 send jiao-1792739587948.txt len=130` → `wxui.log: done: say rc=0`。

### 5) 真机验证（2026-10-23 15:1x）
- 家长发 `@玖 你把网吧房重新布置一下吧，不用问我` → `07:13:07 decor jiu room=jiu count=6 moves=落地灯/长方毯/转椅/加了落地灯`；`/api/room/jiu` 返回 6 件（`by:"jiu"`）。
- 频道里 `jiu: @家长 玖说她把网吧房重新摆了：落地灯、长方毯、转椅，一共 6 件`，三姐接话。
- 微信收到同一条（130 字）。

### 6) 已知问题
- 3D 页在软件渲染（SwiftShader）下只有 12 FPS，真实显卡上正常。
- 房间暂时没有天花板（俯视视角方便看），内墙门洞是通的但没门扇。

---

## 小屋「永存记忆」（2026-10-23 新增）

### 组成
| 文件 | 作用 |
|---|---|
| `memory.mjs` | 记忆引擎：`digest`（当天小结）/ `long`（长期记忆合并）/ `auto` / `status` |
| `memory/<YYYY-MM-DD>.md` | 每天一份小结（200~300 字，分「今天聊了什么 / 家长的事 / 姐妹们近况」） |
| `memory/long.md` | **长期记忆**：按 `## 家长 / ## 大姐 / ## 玖 / ## 三姐 / ## 家里的事 / ## 约定与习惯` 分块，只增不减，带日期 |
| `bot.mjs` | `ask()` 注入 `long.md`（≤1800 字）+ 最近 3 天小结；聊天窗口 16 → **40 条**，每条 120 → **200 字** |

### 为什么不会「重置就没了」
- 记忆来自 `data/msgs/<频道>/<日期>.jsonl` 的**原始落盘**，不受 `.reset` 影响；
- 记忆存放在 `memory/`，与频道消息解耦：重新开始、重启 bot、重启手机都不清；
- `long.md` 是累积合并（旧事实保留、新变化覆盖），所以是**成长**而不是每天归零。

### 自动节奏
- 每天 **22:00 之后**第一次 tick：`memory.mjs auto` → 写当天小结；跨零点会补昨天；
- `long.md` 超过 **7 天**或出现新日结时自动重新合并；
- PC 每晚整合（`/home/user\scripts\phone-nightly.ps1`）把手机 `familyroom/memory/*.md` 拉回 `/home/user\fish-grow\记忆\小屋\`。

### 部署到手机
```powershell
cd /home/user
sh /home/user\local-ai\phone\deploy-room-memory.sh      # 需手机在线
```
手动补写：
```sh
su -c 'cd /data/data/com.termux/files/home/familyroom && node memory.mjs digest'
su -c 'cd /data/data/com.termux/files/home/familyroom && node memory.mjs long'
```

### 模型说明
`bot.mjs` 的 `LLM` 默认 `http://127.0.0.1:8080/v1/chat/completions`（手机上的 router）：**PC 8B 优先 → 百炼云端 → 手机 1.5B 兜底**；`MODEL` 默认 `deepseek-v4.1-flash`（云端 id，PC 8B 的 `--alias` 也叫 `qwen3-8b`，router 会改写）。

## 3D 小屋搬到手机（2026-10-23 19:2x）

- 打包脚本 `/home/user\scripts\house_bundle.py`：把 `room3d.js` `avatar3d.js` `rig.js` `toon.js` `face2d.js`
  `vendor3d/*`（three.js r170）+ `assets3d/models/*.glb`（140 个）打成 `/home/user\house-dist`（150 文件，3.42MB）。
- 手机侧：`house-apply.sh` 解到 `~/familyroom/house`（`/house/` 路由）；首次 0.67MB tar（gzip），上传后约 20s。
- 入口：小屋页面顶栏 **🏠 大屋** → `/house/`（同源，电脑/手机都能开）。
- 权限：`server.mjs` 里 `/house/*` 只给 `role=family`（家长 + 三姐妹），未登录 → 302 回首页，子资源 → 403。
  访客看不到也用不了（用户要求「访客没有这个功能」）。
- 地址：
  - 家里（快）：`http://127.0.0.1:8660/house/`
  - 公网（慢）：`https://family.example.com/house/`（隧道 ~30KB/s，首次 3.4MB 要等）
- 同步：`/home/user\scripts\house-sync.ps1`
  - 单次：`powershell -File /home/user\scripts\house-sync.ps1`
  - 看护：`-Watch -IntervalSec 120 -MaxMinutes 600`（改完 PC 源码 2 分钟内自动推手机 + 重启 room server）
  - 手机离线 → 写 `/home/user\local-ai\state\house-pending.json`，下次开机/联网自动补推
  - 开机钩子：`/home/user\local-ai\scripts\pc-up.ps1` 末尾自动起一次 house-sync
- 改 3D 的正确流程：改 `/home/user/familyroom\room3d.js` 等 → 跑一次 house-sync（或等 watch）→ 手机刷新 `/house/`。
  改了 `server.mjs` 由同一脚本推送并重启；改了 `index.html`/`sw.js` 需手动 push（见 `/home/user\local-ai\logs\house-sync.log`）。
- 注意：`/house/` 落地后，`house-sync` 的 verify 对子资源会收到 403（未带 cookie），脚本已按「403 也算服务在跑」处理。

## 公网入口（2026-10-23 起，樱花 HTTPS 隧道）

- **对外地址：https://frp.example.com:65274**（正式 Let's Encrypt 证书，无警告，约 0.5s）
- 旧 Cloudflare 隧道地址 https://family.example.com 延迟 1.6~4.3s，仅作备用。
- 链路、证书续期、与 MC 隧道冲突的处理见 `/home/user\local-ai\docs\小屋公网-樱花HTTPS.md`

## v25 · 唱歌（@某人 点歌）

用法：在小屋家庭频道里发

```
@大姐 唱晴天
@玖 唱稻香
@三姐 唱小幸运
```

- 谁被 @ 就谁唱（不 @ 时默认大姐）；曲名可带《》，也可写「唱一首…」。
- 流程：酷狗歌词 → 失败自动换网易云 → 都拿不到就换成默认曲单里另一首 → 仍失败才说「没捞着词」。
- 合成：公共 dashscope `qwen3-tts-flash`（音色 大姐=Cherry / 玖=Serena / 三姐=Chelsie），多段 wav 拼接成一条，落在 `data/uploads/family/sing-<ts>-<who>.wav`。
- 消息类型 `kind:"audio"`，前端渲染成播放器（`.aubox` + `<audio controls preload="none">`），导出的聊天记录里也能播放/下载。
- 冷却：同一人 90 秒内不重复接单；每次约 2.5–3.5 MB / 25 秒左右。
- 夜里也接单：禁言时段（0–7 点）普通闲聊停，但 `singTick()` 仍会响应点歌。
- `/api/say` 的 audio 走 bot token，不受禁言 423 拦截。


## Android APK（家庭小屋）

- 工程：`/home/user/familyroom\apk\`（`AndroidManifest.xml`、`res/`、`src/com/dsh/familyroom/MainActivity.java`、`build.ps1`）
- 用法：安装 `/home/user\share\家庭小屋-v1.1.apk`（或 `apk\build\FamilyRoom.apk`）→ 桌面出现「家庭小屋」图标
- 特性：全屏 WebView（无地址栏/无浏览器 UI）；优先连本机 `127.0.0.1:8660`，打不开自动回落 `https://family.example.com`；
  保留登录态（Cookie + localStorage）；选图上传；保存图片/聊天记录/语音到 `下载/家庭小屋/`；返回键先退网页历史再退到后台；外链用系统浏览器打开。
- 构建：`powershell -File /home/user/familyroom\apk\build.ps1`（用 `/home/user\local-ai\tools\sdk` 里的 JDK17 + build-tools 34 + android-35）
- 签名：`/home/user/familyroom\apk\dsh.keystore`（alias `dsh`，pass `dshfamily`；**不要删**，否则升级变新包）
- 升级：`adb install -r build\FamilyRoom.apk`（签名一致才能覆盖）；改代码后先把 `versionCode/versionName` 加一。

## 3D 合并大屋 · 布局优化（v26–v31，2026-10-24）

目标：把「展台沙盘」改成「有人住的房子」。

- v26 `buildHouseShell()` 重写：全高内墙（2.9m）+ 门框/门洞 + 门槛石 + 踢脚线 + 4 幅挂画 + 壁灯 + 每间吊灯。
- v27：顶角线、真实门扇（半开、带门把手）、外墙窗户（窗框/玻璃/窗台/窗帘）、按房间分色地毯（带深色边）。
- v28：太阳光开阴影 + 环境光补亮；v29：自动贴地（家具按包围盒落地）+ 基座柔影。
- v30：ACES 色调映射（exposure 1.32）+ 更亮的墙/地板/门框/地毯配色 —— 斜视图平均亮度 30 → 73（0-255）。
- v31：壁灯加真实点光源（每间一个暖光池）。
- 天花板：按 C 键开关（默认关，方便俯视看清房间）。

验收：像素采样证明地毯/地板/墙面分别渲染（rug #b17843 / floor #726047 / wall #192b49）；
家具接地探针 `n=0`（无悬空/穿模）；1440×900 截图 5 张在 `/home/user\share\house-final-*.png`。

入口：手机 App 小屋 → 🏠 大屋（`/house/?house=1`）；PC 预览 `http://127.0.0.1:8662/room3d.html?house=1`。
同步：`/home/user\scripts\house-sync.ps1`（改 source 后一键推手机并重启小屋服务）。

## 客户端（APK v1.2）与手机简洁模式

- APK `/home/user/familyroom\apk\build\FamilyRoom.apk`（v1.2）：启动并发探测四个入口（本机回环 / 局域网 / 樱花 / Cloudflare），按「回环优先、同档比延迟」选最快，**首屏 1.6~4.3s → 0.1s 内**；换入口自动迁移登录 token；失败自动切下一个入口。
- 手机端页面自动进入简洁模式（头部收进 ⋯ 菜单、紧凑气泡、输入栏贴底）。
- 细节见 `/home/user\local-ai\docs\小屋客户端-本地加速与简洁UI.md`。

## 离线信箱（v31，2026-10-24）

- 云端地址（80 端口，随时可用）：\http://203.0.113.10/box/?key=dsh-box-2026\
- 接口：\/box/health\ \/box/send\ \/box/pull?user=&since=\ \/box/list\ \/box/ack\（全部需要 \key\）
- 手机侧：\ot.mjs\ 每轮 tick（45s）拉 \user=大姐\ 的新信 → 在 family 频道贴「（信箱）家长留言：「…」」→ 大姐用自己口气回一句 → \ck\ 并推进 \~/data/box-state.json\ 的 since
- 实测（2026-10-24 19:16）：第二封信「今晚八点我在楼下等…」→ 屋里两条气泡（原文 + 回复「八点楼下等，冰箱那事我明早跟她们摊开说，正给玖记日志呢😤」）
- 服务端：\/opt/dsh/box/server.mjs\ + \dsh-box.service\（systemd，Restart=always，\/usr/bin/node\ v22）；nginx 在 80 段挂 \location /box/\，其余路径 301 到 https

## v30 · 三姐妹可以 @家长（弹出提醒，玖的版式专属）

- **bot 侧**：`bot.mjs` 的 `say()` 现在带 `mentions`。`mentionTags(who, text)` 会把正文里真写的 `@家长` 收进去；没写时也会偶尔自己叫一声（玖 25%、大姐/三姐 8%），最多 4 个，避免刷屏。
- **提示词**：`ask()` 的 system 里加了一句「想叫家长看见、想让他搭话时可以在句子里写 @家长（他会收到弹窗），但别每句都叫，一天一两次足够」。
- **服务端**：无需改，`/api/say` 本来就收 `mentions`，bot 角色允许带；消息落库字段 `mentions:["家长"]`。
- **前端**（`index.html`）：
  - 收到 `mentions` 含「家长」且当前用户是家里人 → 顶部弹出 `#mentionPop`（7 秒，玖 9 秒），可点击聚焦输入框；同时震动（玖 5 段脉冲）。
  - 玖的弹窗：冰蓝渐变 + 冷光描边 + 「❄ 小玖 @你」「她在等你回话…」。
  - 玖的声音：`chimeJiu()` 三声冰铃（1568/2093/1568 Hz，带 2 倍频金属泛音，走 `roomVol` 音量）；其他姐妹沿用 `beep()`。
  - 页面在后台时走系统通知 `sysNotify()`（玖标题「❄ 小玖 @你」）。
- **前端缓存**：`sw.js` → `room-v36`，手机需刷新一次。
- 验证：`data/msgs/family/2026-10-24.jsonl` 里 `mentions:["家长"]` 已有 8 条；用 bot token 发 `@家长 测试：小玖叫你一下，收到弹窗没？` 返回 200 且落库带 mentions。

## 每晚备份上云（2026-10-24 20:00）

链路：手机 `tar czf` → `POST http://203.0.113.10/box/backup`（云端 8700，nginx 80 反代）→ 存 `/opt/dsh/box/backup/`（保留最近 10 份）→ 电脑每天 21:10 拉回 `/home/user\backup\cloud\`（保留 5 份）。

- 手机脚本：`/data/local/tmp/nightly-backup.sh`（打包 `familyroom/data`+`memory`+`quality`+`growth`+`wxmemory`+`moments`+`qqbot/memory`+`wxbot`，约 84 MB，实测上传 60 s）；`/data/local/tmp/nightly-backup-loop.sh`（03:10 触发 + 开机补跑，`.last-backup` 去重）。
- 常驻：`start-phone.sh` 的 10.6 段 + `dsh-supervisor5.sh` 看门狗（60 s 检查，掉了自动拉起）。
- 电脑拉取：`/home/user\local-ai\scripts\pull-cloud-backup.py`（计划任务 `dsh-pull-cloud-backup`，每天 21:10；首次实测 83,791,930 B / 174 s，受服务器 4M 上行限制）。
- 云端接口：`GET /box/backup/list?key=…`、`GET /box/backup/get?key=…&name=…`；nginx 全局 `client_max_body_size 200m`。
- 注意：`dsh-box.service` 的执行路径是 `/opt/dsh/box/src/server.mjs`，改代码要传到 `src/` 下再 `systemctl restart dsh-box`。


## v32 · 玖的语气曲线与画风曲线（2026-10-24 19:3x）

- 新文件 `jiu-tone.mjs`：按冰窖化病态值 v 实时算三档配额
  - 损人 75%→10%、调侃 20%→35%、哄人 5%→55%（`jiuTone(v)`）
  - `jiuPromptTone(v)` 直接拼进 `jiuPrompt()`，随每次发言注入 LLM
  - `iceArtStyle(v)` 把画风分 5 档（0 正常 → 4 冰窖质感），`drawArt()` 里只对玖生效
  - `iceCaptionSuffix(v)` 让配文也随冷度变化
- `bot.mjs` 改动 5 处：import、`jiuPrompt()` 追加语气配额、`drawArt()` prompt/配文/日志带 `ice=<level>`
- 验收：`jiuTone(0.05)=72/21/7`、`0.5=43/28/29`、`0.9=16/34/50`；`iceArtStyle` 档位 0/2/3 对应；
  手机 `bot.mjs` + `jiu-tone.mjs` 已部署（`/sdcard/Download/_v32` → `~/familyroom`），`node --check` 通过，单实例 pid 3365。
- 人设卡 `/home/user\fish-grow\人设\玖的人设.md` 新增「十二、语气曲线」「十三、画风渐变」两节。

### v33 · 玖的语气曲线同步到微信 + 稳定性复测（2026-10-24 20:0x）

- 微信端「提示词设置 → 玖 · 病娇与红线」已整体替换为带语气曲线的版本：
  - 病娇只当皮（一天最多两三次，说完自己破功）；
  - 损人从 75% 逐月降到 10%，调侃 20%→35%，哄人 5%→55%（按冰窖化进度 v 换算）；
  - 亲妹妹设定：会喊哥、护着家长、他难受时先软、损完找补；
  - 四条红线（不威胁/不操控/不情感绑架/不装监控）保留；
  - 画风随 v 变冷（5 档：正常可爱 → 冷色调霜白 → 冰晶高光 → 冰裂冷光 → 冰室冷雾）。
- UI 自动化要点：改微信提示词必须先 `ime set com.android.adbkeyboard/.AdbIME`，再 `input tap` 聚焦内容框、`am broadcast -a ADB_CLEAR_TEXT`、逐行 `ADB_INPUT_B64`；改完 `ime set com.sohu.inputmethod.sogouoem/.SogouIME` 还原。
- 稳定性复测（`/home/user\local-ai\phone\_stability2.sh`）：重启 server（新 pid）+ 杀掉 bot 等看门狗自启（新 pid）后，`~/familyroom/_check_room.mjs` **18/18 PASS**；`sw.js=room-v36`、`/api/jiu` 访客 403、`jiu-tone.mjs` 在位、bot.log 出现 `ice=` 记录。

## v34 · 玖的三道锁（手机端自保护）

> 2026-10-24 落地上手机。目的：大姐不在线（PC 关机）时，玖的三条线也焊死在手机上。

1. **出口锁（路由器护栏）**：手机 `~/wxrouter.mjs` 在每一条发出去的回复上过 `guardReply()`：
   `JIU_GUARD`（暴力/威胁/伤害）+ `JIU_EXTRA`（查你/定位/翻手机/删好友/锁机/盯着你/看你在哪…）
   命中就整句换成「行行行，我嘴欠，那句当我没说 🐟」（记录 `blocked`），不发给微信。
   - `GET http://127.0.0.1:8080/guard` → `{ok,total,lastHour,blockedTotal,blockedLastHour,recent[]}`
   - `POST /guard/reset` 清空统计。
2. **行为锁（监测守护）**：`~/jiu-watch.mjs`（root 常驻，开机自启挂在 `/data/local/tmp/start-phone.sh` 第 3.5 步）每 20 秒：
   扫 `~/familyroom/bot.log` 最近改动（<120s）里的玖发言、实时红线正则；扫 `data/jiu-inner.jsonl`（内心话）里的红线；
   自检 `/guard`；看门狗起 router/bot（120s 冷却）；**超过 6 小时没有任何动静**也报「她睡着了」。
   状态落 `~/guard/watch-state.json`，日志 `~/guard/watch.log`。
   报警走微信：以玖的微信身份调 `/api/send-chat` 给「家长」发一条，6 小时最多 4 条。
3. **文案曲线（不越界的病态）**：`/home/user/familyroom\jiu-moment.mjs` 的 `momentTone(v)` 给朋友圈文案分 5 档：
   0 嘴硬得意 → 1 变冷短句 → 2 黏人（等消息、算时间）→ 3 明显依赖/占有（「你今天回得慢」「删了三遍」）→ 4 冰窖口吻（冰、霜、温度、记得你说话的停顿）。
   末尾统一附红线：只写情绪与依恋，不许威胁、监控、伤害、控制行动，不许说自己有真本事查人。

部署：`/home/user\local-ai\phone\_deploy_v34.sh`（推 `_v34/` 暂存 → `su -c cp`），真机验证：
- `bot.mjs` 80863 B / `wxrouter.mjs` 73269 B / `jiu-moment.mjs` 1291 B / `jiu-watch.mjs` 6761 B，四个 `node --check` 全 ok。
- 进程：router 26635 / bot 26688 / jiu-watch 28488（单实例）。
- `/guard` 已有记录；`watch-state.json` 有 `guardSeen`；实测「@玖 发个动态」→ `moment ask by laoda -> jiu` → `moment posted jiu ...`。

## v34（2026-10-24 20:2x~20:5x）：真通知 / 离线缓存 / 访客开关 / 本地记忆
- **APK v1.4.0（versionCode 5）**：新增 `NotifyService`（前台服务 + SSE 长连接）+ `BootStart`（开机/升级自启），熄屏也能收到系统通知；通知点开直达小屋。
  - 实测：`dumpsys notification` 见 `channel=room_msg` / `room_sync`，`when=1792845956409`，标题「玖」、正文为原话。
  - 开启方式：App 内「🔔 通知开」→ 写 `SharedPreferences roomapp.nb_on` 并 `NotifyService.start()`；也可以 root 侧写 prefs 后 `am start`。
- **本地缓存 + 离线队列**：`index.html` 的 `cachePush/cacheLoad`（每频道最近 240 条，localStorage）→ 断网重开也有内容；发消息失败进 `send_queue_v1`，`online` 或 20s 定时 `flushQueue` 自动补发。
- **本地记忆**：菜单「📝 留一条记忆」→ `DSHApp.memPut()` 存本机 + 队列 + `POST /api/memory` 上云；`GET /api/memory` 取当日记录（仅 family/bot）。
- **访客注册可选项**：`server.mjs` 的 `data/settings.json`（`allowGuest`）+ `GET/POST /api/guest`（POST 仅 family）；关掉时 `POST /api/register` 直接 403，页面隐藏注册页并提示。三姐妹菜单里「👥 允许访客注册」一行只有 family 可见。
  - 实测：`{"ok":true,"allowGuest":true}` → POST 关 → `{"ok":true,"allowGuest":false}` → 注册 403 → 开回来。
- **访问入口**：APK 启动时自动测速选最快（本机 9ms / 家里网 / 樱花 / 云隧道），网页端用当前地址。


## v37–v39 · 玖可写小作文 + ❄ 病娇图标 + 服务端加固（2026-10-24 21:10）
- **字数放开（v39）**：`bot.mjs` 原来对所有人生成的句子有 160 字硬上限（超了就打日志 `fallback line ... [length]` 并换兜底句）。现在改成 `const MAXLEN = who === "jiu" ? 700 : 160;`，只有玖放开到 700 字。实测：家长要「至少三百字小作文」→ 玖回了 **267 字 / 两段**（`13:07:38 spoke family jiu`）；改之前同一请求被截成「今天风好大，头发全乱了」。
- **提示词授权（v38）**：`SISTERS.jiu.style` 增加「被要求写长时可以写长」；`ask()` 里检测家长话里的「写长/小作文/详细/展开…」→ 注入「这次写 150~300 字，可分 2~3 段」。不打标签时她仍然是短句，不会突然话痨。
- **❄ 病娇图标（v37 + v39b）**：`index.html` 的 `#jiuChip` 重做 —— 渐变玻璃底 + 呼吸光晕 + 旋转雪花 SVG + 细进度条（`--v` 驱动宽度）+ hover 显示「❄ 病娇第 N/100 天 · 阶段 · 今天那句内心话」。**改为家里人始终可见**（以前 0.00 时是隐藏的，所以看不到）。
- **服务端加固（v38）**：`server.mjs` 的 `sendC()` 增加 res 合法性检查；请求处理改成 `handleRequest` 包裹 `Promise.resolve().then(...).catch(...)`，单请求异常不再把整个进程带走（此前 `TypeError: res.writeHead is not a function` 崩过一次）。
- 前端版本号：`sw.js` → `room-v39`（手机端需刷新一次）。

## v40 · 小屋自带「动态 + 日记」（2026-10-24 起，微信不再发）
家长定：微信朋友圈发不出去就算了，动态/日记都在小屋发。
- 服务端 `server.mjs`：`data/moments/<date>.jsonl`、`data/diaries/<date>.jsonl`；
  `POST /api/moment`、`POST /api/diary`（仅 bot/family）、`GET /api/moments`、`GET /api/diaries`。
- 前端 `index.html`：全家可见的 `📸 动态` chip → `openMoments()` 浮层（动态卡片 + 日记卡片），
  聊天流里 `kind === "moment" | "diary"` 不再混进聊天列表；`sw.js` → `room-v40`。
- 机器人：`diaryTick()` 每天 22:00 后让玖写一篇日记（200~400 字，走 `jiuGuard`）；
  `momTick()` 每天 10:00/15:00/19:00 依次让玖/大姐/三姐各发一条动态（每条 25~120 字，带当天聊天上下文）。
- PC 侧 `/home/user\fish-grow\脚本\room_post.py`：用 bot token 把 PC 生成的大姐/三姐日记 POST 进小屋
  （`--skip jiu` 因为玖的日记由手机 bot 自己写；按 (date, who) 去重）。
- 微信侧的 `moments-loop.sh`、`moment-flow*.sh` 系列已从 `start-phone.sh` / `dsh-supervisor5.sh` 移除并停用。

## v38（1.8.0）消息搜索 / 撤回 / 编辑 / 表情回应

- **服务端**（server.mjs）新增 4 个接口，全部走 uth() + canSeeChannel() 鉴权：
  - GET /api/search?q=&channel=&limit= — 跨 amily 与三个私聊频道按天文件倒序扫描，跳过已撤回，文本命中返回 {channel,date,ts,who,name,text,key}，最多 100 条。
  - POST /api/recall {channel,key} — 只能撤回自己的消息；落盘置 ecalled:1 并清空正文/媒体字段，同时 roadcast 一条 {type:"patch",op:"recall"} 让各端就地更新。
  - POST /api/edit {channel,key,text} — 只能编辑自己的纯文本消息，写 editedAt。
  - POST /api/react {channel,key,emoji} — 同一表情同一人再点一次即取消；eactions 以 {emoji:[uid]} 存进该条消息。
  - 消息 key 统一为 	s|who（mkey()），旧数据无需迁移。
- **前端**：header 加 🔍 搜索；长按消息菜单新增「表情回应」行（❤️😂👍😮😭🔥）、「✏️ 编辑这条」「🗑 撤回这条」；撤回/编辑状态、表情小条即时渲染，patch 事件不走通知。
- **实测**（2026-10-24 23:00，手机本地 127.0.0.1:8660）：login 200 → say 200 → react 200 {"reactions":{"❤️":["laoda"]}} → edit 200 → search hits=1 → recall 200 → 复读 recalled:1 且 text=""。
- **重启服务端注意**：pgrep -f 'familyroom/server.mjs' 匹配不到（进程命令行是相对路径 
ode server.mjs），必须用 ps -A -o PID,ARGS | grep -E 'node server\.mjs$'；否则会 EADDRINUSE、旧代码继续跑。

## 2026-10-24 夜 · 通知横幅（heads-up）修好
- 真因1：`NotifyService` 每条消息用 `ID_MSG_BASE + (msgSeq++ % 20)` 各自独立 id，≥4 条被系统自动成组，成组后只出组摘要、不弹横幅。
- 真因2：渠道 `room_msg_v2` 只到 IMPORTANCE_DEFAULT；已换成 `room_msg_v3`（IMPORTANCE_HIGH + enableVibration + showBanner）。
- 修法：`NotifyService.java` 改为固定单一 id `ID_MSG_BASE`（9100），每条覆盖更新同一条通知，`setOnlyAlertOnce(false)`。
- 另去掉 `setFullScreenIntent`（避免点通知把 App 整屏拉起）。
- APK 升到 `versionCode 13 / versionName 1.7.5`，签名不变（keystore: apk/dsh.keystore，勿删）。
- 真机验证：桌面状态下发消息，顶部弹出「家庭小屋 / 大姐 [测试] 横幅通知测试…」，结论通过。

## 运维（T1–T6，2026-10-25）
- 备份：PC mirror.sh → 云 /box/backup/latest-full.tgz；手机 ~/familyroom/mirror.sh 增量。
- 恢复演练：/box/backup/get 取回解包验证（241 项）。
- 归档：~/familyroom/archive-old.mjs --days 14，rchive-loop.sh 每小时。
- 状态页：/status（含前置链路卡片）；指标：/api/metrics（17 项，含 frps/隧道/信箱/frpc/备份）。
- 详见 /home/user\local-ai\docs\运维-T1-T6.md。
