# 家庭小屋 · 模板

一套可自建的家庭聊天小屋：**手机（Termux + root）跑服务端**，浏览器 / Android 壳做客户端。
三姐妹（大姐/二姐/三姐）由大模型驱动，可聊天、斗图、唱歌、发语音。

## 文件
| 文件 | 作用 |
|---|---|
| `server.mjs` | 服务端（Node 18+，零第三方依赖，默认 :8660） |
| `bot.mjs` | 姐妹们的自动聊天 / 唱歌 / 定时播报机器人 |
| `index.html` | 前端单页（聊天、游戏厅、小剧院、音色、相册） |
| `quality.mjs` | 去重与「每日成长」机制 |
| `singify.mjs` | 唱歌合成（TD-PSOLA 变调） |
| `memory.mjs` | 每日记忆摘要 |
| `call-ws.mjs` | 语音通话 WebSocket 服务 |
| `apk/` | Android 壳（WebView + 前台通知 + 原生录音） |

## 起步
1. 装 Node 18+（手机：Termux `pkg install nodejs`）
2. 本目录放进 `~/familyroom/`
3. `node server.mjs`，浏览器开 `http://127.0.0.1:8660`
4. 首次运行自动生成 `data/`（账号库、口令文件）
5. 需要大模型时，配 OpenAI 兼容的 baseURL / key 环境变量

## 已脱敏
- 所有真实 IP / 域名 / 路径 / 账号名 / 口令 / API key → 占位符（`sk-xxxx`、`change-me-box-key`、`your-admin-pass`）
- **不含**任何聊天记录、账号库、图片、视频、日志
- 代码里的 `shiqi / jiu / hutao` 是三位角色的内部 id，仅作示例

## 许可
MIT。个人 / 家庭自用学习，勿用于商业分发。
