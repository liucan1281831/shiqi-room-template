// call-ws.mjs —— 小屋实时语音通话（全双工，极简 RFC6455 实现，无第三方依赖）
// 客户端：APK 原生流式录音 DSHApp.startStream()/takeChunk() → 二进制 PCM16 16k/单声道
// 服务端：VAD 断句 → ASR(本地 whisper :8083) → LLM → TTS(百炼 qwen3-tts-flash) → 回送 PCM16
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

// v1.40.1：TTS key 与 bot 一致，从 ~/.router.json 取（服务端进程环境里没有 BAILIAN_API_KEY）
// 注意：server 可能被 root 直接拉起，HOME 不一定是 Termux 家目录 → 显式兜底
const HM = process.env.HOME && process.env.HOME !== "/" ? process.env.HOME : "/data/data/com.termux/files/home";
let CLOUD = {};
for (const p of [path.join(HM, ".router.json"), "/data/data/com.termux/files/home/.router.json"]) {
  try { CLOUD = JSON.parse(fs.readFileSync(p, "utf8")); break; } catch (e) { }
}

const GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
const SR = 16000;

const ASR_CANDS = [process.env.ROOM_ASR_URL, "http://127.0.0.1:8083/asr",
  "http://127.0.0.1:8083/asr", "http://10.0.0.2:8083/asr"].filter(Boolean);
const LLM_URL = process.env.ROOM_LLM_URL || "http://127.0.0.1:8080/v1/chat/completions";
const LLM_KEY = process.env.ROOM_LLM_KEY || "sk-local-change-me";
const LLM_MODEL = process.env.ROOM_LLM_MODEL || "qwen3-4b";
const TTS_URL = process.env.ROOM_TTS_URL || (CLOUD && CLOUD.ttsUrl) || "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation";
const TTS_KEY = process.env.BAILIAN_API_KEY || (CLOUD && (CLOUD.key || CLOUD.apiKey)) || "";
const TTS_VOICE = { shiqi: "Cherry", jiu: "Serena", hutao: "Chelsie", laoda: "Cherry" };

// ---------------- WAV ----------------
function wavFromPcm(pcm) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + pcm.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}
function pcmFromWav(buf) {
  if (!buf || buf.length < 44) return null;
  let i = 12;
  while (i + 8 <= buf.length) {
    const id = buf.toString("ascii", i, i + 4);
    const sz = buf.readUInt32LE(i + 4);
    if (id === "data") return buf.subarray(i + 8, Math.min(buf.length, i + 8 + sz));
    i += 8 + sz + (sz % 2);
  }
  return null;
}

// ---------------- WS 帧 ----------------
function frame(op, payload) {
  const len = payload.length;
  let head;
  if (len < 126) { head = Buffer.from([0x80 | op, len]); }
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}

// ---------------- ASR / LLM / TTS ----------------
async function asrOf(wav) {
  for (const u of ASR_CANDS) {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 20000);
      const r = await fetch(u, { method: "POST", headers: { "content-type": "audio/wav" }, body: wav, signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) continue;
      const j = await r.json();
      const text = String(j.text || j.result || j.transcript || "").trim();
      if (j && j.ok !== false && text) return text;
      if (j && j.ok !== false && text === "") return "";
    } catch (e) { /* 换下一个 */ }
  }
  return "";
}

async function llmOf(who, persona, lines, userText) {
  const sys = persona || "你是家里的一员，说话短、口语化，1~2 句。";
  const msgs = [{ role: "system", content: sys + "\n现在是语音通话，回答必须极短（1~2 句，不超过 40 字），不要 emoji。" }];
  for (const m of (lines || []).slice(-6)) msgs.push({ role: m.who === "laoda" ? "user" : "assistant", content: String(m.text || "").slice(0, 120) });
  msgs.push({ role: "user", content: userText });
  try {
    const r = await fetch(LLM_URL, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer " + LLM_KEY },
      body: JSON.stringify({ model: LLM_MODEL, messages: msgs, max_tokens: 120, temperature: 0.8 }),
    });
    const j = await r.json();
    return String((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || "").trim();
  } catch (e) { return ""; }
}

async function ttsOf(text, who) {
  if (!TTS_KEY) return null;
  try {
    const r = await fetch(TTS_URL, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer " + TTS_KEY,
        "user-agent": "Mozilla/5.0 (Linux; Android 13; RMX3708) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36" },
      body: JSON.stringify({ model: "qwen3-tts-flash", input: { text: String(text).slice(0, 300), voice: TTS_VOICE[who] || "Cherry" } }),
    });
    const j = await r.json();
    const url = j?.output?.audio?.url || j?.output?.url || j?.audio?.url || j?.data?.url || j?.url;
    const b64 = j?.output?.audio?.data || j?.audio?.data;
    if (url) {
      const rr = await fetch(url);
      const buf = Buffer.from(await rr.arrayBuffer());
      return pcmFromWav(buf);
    }
    if (b64) return pcmFromWav(Buffer.from(b64, "base64"));
  } catch (e) { }
  return null;
}

// ---------------- 会话 ----------------
const VAD_RMS = 320;      // 客户端已 20x 增益，人声通常 >1500
const START_FRAMES = 3;   // 连续 60ms 有音 → 开始
const END_SIL_MS = 650;   // 静音 650ms → 断句
const MAX_UTTER_MS = 20000;

export function handleCallUpgrade(req, socket, head, ctx) {
  let u;
  try { u = new URL(req.url, "http://x"); } catch (e) { socket.destroy(); return; }
  if (u.pathname !== "/ws/call" && u.pathname !== "/call-ws") { socket.destroy(); return; }
  const me = ctx.whoOf ? ctx.whoOf(req, u) : null;
  if (!me) { try { socket.write("HTTP/1.1 401 Unauthorized\r\nContent-Length: 0\r\n\r\n"); } catch (e) { } socket.destroy(); return; }
  const key = req.headers["sec-websocket-key"];
  if (!key) { socket.destroy(); return; }
  const acc = crypto.createHash("sha1").update(String(key) + GUID).digest("base64");
  socket.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n");
  socket.setNoDelay(true);

  // v1.40.2：家长通话时指定「跟哪个姐妹说话」；她自己（shiqi/jiu/hutao）身份则沿用
  let _sister = "jiu";
  try {
    const _q = new URL(String(req.url || "/"), "http://x");
    const _v = String(_q.searchParams.get("sister") || "").trim();
    if (_v === "shiqi" || _v === "jiu" || _v === "hutao") _sister = _v;
  } catch (e) { }
  const who = (me.who && me.who !== "laoda") ? me.who : _sister;
  const st = { rx: Buffer.alloc(0), pcm: [], speaking: false, hi: 0, sil: 0, utter: 0, busy: false, closed: false, gen: 0 };

  const sendJSON = (o) => { try { socket.write(frame(1, Buffer.from(JSON.stringify(o)))); } catch (e) { } };
  const sendPCM = (buf) => { try { socket.write(frame(2, buf)); } catch (e) { } };
  sendJSON({ t: "ready", who, sampleRate: SR });

  async function handleUtter(pcm) {
    if (st.busy || st.closed) return;
    st.busy = true;
    const myGen = ++st.gen;
    try {
      sendJSON({ t: "state", s: "asr" });
      const text = await asrOf(wavFromPcm(pcm));
      if (st.closed) return;
      if (!text) { sendJSON({ t: "state", s: "listen" }); return; }
      sendJSON({ t: "asr", text });
      sendJSON({ t: "state", s: "think" });
      const persona = ctx.persona ? ctx.persona(who) : "";
      const lines = ctx.recent ? ctx.recent(who) : [];
      const reply = await llmOf(who, persona, lines, text);
      if (st.closed || myGen !== st.gen) return;
      if (!reply) { sendJSON({ t: "state", s: "listen" }); return; }
      sendJSON({ t: "reply", text: reply });
      sendJSON({ t: "state", s: "speak" });
      const pcmOut = await ttsOf(reply, who);
      if (st.closed || myGen !== st.gen) return;
      if (!pcmOut || !pcmOut.length) sendJSON({ t: "err", msg: "tts:" + (TTS_KEY ? "empty" : "nokey") });
      if (pcmOut && pcmOut.length) {
        const CH = SR * 2 * 0.25; // 250ms
        for (let i = 0; i < pcmOut.length; i += CH) {
          if (st.closed || myGen !== st.gen) return;
          sendPCM(pcmOut.subarray(i, Math.min(pcmOut.length, i + CH)));
          await new Promise((r) => setTimeout(r, 40));
        }
      }
      sendJSON({ t: "state", s: "listen" });
    } catch (e) {
      sendJSON({ t: "err", msg: String(e && e.message || e) });
    } finally {
      st.busy = false;
    }
  }

  function feedPCM(chunk) {
    st.pcm.push(chunk);
    const FR = SR * 2 * 0.02; // 20ms = 640B
    let total = 0;
    for (const b of st.pcm) total += b.length;
    while (total >= FR) {
      const buf = Buffer.concat(st.pcm);
      const f = buf.subarray(0, FR);
      st.pcm = buf.length > FR ? [buf.subarray(FR)] : [];
      total = buf.length - FR;
      let sum = 0;
      for (let i = 0; i + 1 < f.length; i += 2) { const v = f.readInt16LE(i); sum += v * v; }
      const rms = Math.sqrt(sum / (f.length / 2));
      if (rms > VAD_RMS) {
        st.hi++;
        st.sil = 0;
        if (!st.speaking && st.hi >= START_FRAMES) { st.speaking = true; st.utter = 0; }
      } else {
        st.hi = 0;
        if (st.speaking) st.sil += 20;
      }
      if (st.speaking) {
        st.utter += 20;
        if (!st.silBuf) st.silBuf = [];
        st.silBuf.push(f);
        if (st.utter >= MAX_UTTER_MS || st.sil >= END_SIL_MS) {
          const all = Buffer.concat(st.silBuf);
          st.silBuf = [];
          st.speaking = false; st.sil = 0; st.utter = 0;
          handleUtter(all);
        }
      }
    }
  }

  socket.on("data", (d) => {
    st.rx = Buffer.concat([st.rx, d]);
    while (st.rx.length >= 2) {
      const b0 = st.rx[0], b1 = st.rx[1];
      const op = b0 & 0x0f, masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f, off = 2;
      if (len === 126) { if (st.rx.length < 4) return; len = st.rx.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (st.rx.length < 10) return; len = Number(st.rx.readBigUInt64BE(2)); off = 10; }
      const need = off + (masked ? 4 : 0) + len;
      if (st.rx.length < need) return;
      let payload = st.rx.subarray(off + (masked ? 4 : 0), need);
      if (masked) {
        const mk = st.rx.subarray(off, off + 4);
        const cp = Buffer.allocUnsafe(len);
        for (let i = 0; i < len; i++) cp[i] = payload[i] ^ mk[i & 3];
        payload = cp;
      }
      st.rx = st.rx.subarray(need);
      if (op === 8) { try { socket.end(); } catch (e) { } st.closed = true; return; }
      if (op === 9) { try { socket.write(frame(10, payload)); } catch (e) { } continue; }
      if (op === 1) {
        let j = null;
        try { j = JSON.parse(payload.toString("utf8")); } catch (e) { }
        if (j && j.t === "barge") { st.gen++; sendJSON({ t: "state", s: "listen" }); }
        if (j && j.t === "ping") sendJSON({ t: "pong", ts: Date.now() });
        if (j && j.t === "bye") { try { socket.end(); } catch (e) { } st.closed = true; return; }
        continue;
      }
      if (op === 2) feedPCM(payload);
    }
  });
  socket.on("close", () => { st.closed = true; });
  socket.on("error", () => { st.closed = true; });
}